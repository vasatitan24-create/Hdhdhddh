<?php

require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: error.php");
    exit();
}

// Получаем имя текущего пользователя из сессии
$currentUser = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Игротека</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root{
            --bg: #f4f7fb;
            --card: #ffffff;
            --border: #e7edf5;
            --primary: #2AABEE;
            --text: #1f2937;
            --muted: #6b7280;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            overflow-x: hidden;
        }

        .container {
            max-width: 920px;
            margin: 0 auto;
            padding: 0;
            background: #ffffff;
            min-height: 100vh;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 14px 16px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .menu-btn-inline {
            border: none;
            border-radius: 50%;
            background: transparent;
            color: #2AABEE;
            font-size: 20px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.15s ease-in-out;
        }

        .menu-btn-inline:hover {
            background: #f1f5f9;
        }

        .title {
            font-size: 22px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .games-content-wrapper {
            padding: 24px 16px;
        }

        .subtitle {
            color: var(--muted);
            font-size: 15px;
            margin-bottom: 30px;
            text-align: center;
            font-weight: 500;
        }

        .games-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            max-width: 700px;
            margin: 0 auto;
        }

        .game-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            background: #ffffff;
            border: 1px solid var(--border);
            border-radius: 24px;
            text-decoration: none;
            color: var(--text);
            transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        }

        .game-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.06);
            border-color: var(--primary);
        }

        .game-card i {
            font-size: 40px;
            margin-bottom: 16px;
            transition: transform 0.2s ease;
        }

        .game-card:hover i {
            transform: scale(1.1);
        }

        .game-card span {
            font-size: 16px;
            font-weight: 700;
            letter-spacing: 0.3px;
        }

        .card-match3 i { color: #a855f7; }
        .card-clicker i { color: #22c55e; }

        @media (max-width: 576px) {
            .games-grid {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            .game-card {
                padding: 30px 16px;
            }
            .title {
                font-size: 18px;
            }
            .header {
                padding: 12px 12px;
            }
        }
    </style>
</head>
<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="container">

    <div class="header">
        <div class="header-left">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="title">Игротека</h1>
        </div>
    </div>

    <div class="games-content-wrapper">
        <p class="subtitle">Выберите способ скоротать время</p>

        <div class="games-grid">
            <a href="game_match3.php" class="game-card card-match3">
                <i class="fas fa-shapes"></i>
                <span>Три в ряд</span>
            </a>
            
            <a href="game_clicker.php" class="game-card card-clicker">
                <i class="fas fa-mouse-pointer"></i>
                <span>Кликер</span>
            </a>
        </div>
    </div>

</div>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

document.getElementById('menuBtn').onclick = () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
};

document.getElementById('closeBtn').onclick = closeSidebar;
overlay.onclick = closeSidebar;

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
}
</script>

</body>
</html>