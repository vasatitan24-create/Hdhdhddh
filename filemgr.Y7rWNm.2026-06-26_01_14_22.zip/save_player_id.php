<?php

session_start();

require_once 'db.php';

header('Content-Type: application/json; charset=utf-8');

// ЛОГ
file_put_contents(
    __DIR__ . '/onesignal_log.txt',
    date('Y-m-d H:i:s') . " REQUEST:\n" .
    print_r($_POST, true) .
    print_r($_SESSION, true) .
    "\n\n",
    FILE_APPEND
);

if (!isset($_SESSION['username'])) {

    echo json_encode([
        'status' => 'error',
        'message' => 'Нет сессии'
    ]);

    exit;
}

$playerId = trim($_POST['player_id'] ?? '');

if ($playerId === '') {

    echo json_encode([
        'status' => 'error',
        'message' => 'Пустой player_id'
    ]);

    exit;
}

$stmt = $pdo->prepare("
    UPDATE users
    SET onesignal_player_id = :player_id
    WHERE username = :username
");

$ok = $stmt->execute([
    'player_id' => $playerId,
    'username' => $_SESSION['username']
]);

echo json_encode([
    'status' => $ok ? 'success' : 'error',
    'player_id' => $playerId,
    'username' => $_SESSION['username']
]);