const E2EE = (() => {
    const PBKDF2_ITERATIONS = 250000;
    const SALT_LEN = 16;
    const IV_LEN = 12;

    function bufToB64(buf) {
    let binary = '';
    const bytes = new Uint8Array(buf);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

    function b64ToBuf(b64) {
        const binary = atob(b64);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
        return bytes.buffer;
    }

    function randomBytes(len) {
        const arr = new Uint8Array(len);
        crypto.getRandomValues(arr);
        return arr;
    }

    async function deriveKey(secret, saltBytes) {
        const enc = new TextEncoder();
        const keyMaterial = await crypto.subtle.importKey(
            'raw',
            enc.encode(secret),
            'PBKDF2',
            false,
            ['deriveKey']
        );

        return crypto.subtle.deriveKey(
            {
                name: 'PBKDF2',
                salt: saltBytes,
                iterations: PBKDF2_ITERATIONS,
                hash: 'SHA-256'
            },
            keyMaterial,
            {
                name: 'AES-GCM',
                length: 256
            },
            false,
            ['encrypt', 'decrypt']
        );
    }

    async function encryptText(plainText, secret) {
        const enc = new TextEncoder();
        const salt = randomBytes(SALT_LEN);
        const iv = randomBytes(IV_LEN);
        const key = await deriveKey(secret, salt);

        const cipher = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv },
            key,
            enc.encode(plainText)
        );

        return {
            encrypted: true,
            salt_b64: bufToB64(salt.buffer),
            iv_b64: bufToB64(iv.buffer),
            ciphertext_b64: bufToB64(cipher)
        };
    }

    async function decryptText(payload, secret) {
        const salt = new Uint8Array(b64ToBuf(payload.salt_b64));
        const iv = new Uint8Array(b64ToBuf(payload.iv_b64));
        const data = b64ToBuf(payload.ciphertext_b64);
        const key = await deriveKey(secret, salt);

        const plain = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv },
            key,
            data
        );

        return new TextDecoder().decode(plain);
    }

    async function encryptFile(file, secret) {
        const salt = randomBytes(SALT_LEN);
        const iv = randomBytes(IV_LEN);
        const key = await deriveKey(secret, salt);
        const fileBuf = await file.arrayBuffer();

        const cipher = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv },
            key,
            fileBuf
        );

        const encryptedBlob = new Blob([cipher], { type: 'application/octet-stream' });

        return {
            blob: encryptedBlob,
            meta: {
                encrypted: true,
                salt_b64: bufToB64(salt.buffer),
                iv_b64: bufToB64(iv.buffer),
                original_mime: file.type || 'application/octet-stream',
                original_name: file.name || 'file'
            }
        };
    }

    async function decryptFile(arrayBuffer, meta, secret) {
        const salt = new Uint8Array(b64ToBuf(meta.salt_b64));
        const iv = new Uint8Array(b64ToBuf(meta.iv_b64));
        const key = await deriveKey(secret, salt);

        const plain = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv },
            key,
            arrayBuffer
        );

        return new Blob([plain], { type: meta.original_mime || 'application/octet-stream' });
    }

    function getSecretKey(chatId) {
        return localStorage.getItem('e2ee_secret_' + chatId) || '';
    }

    function setSecretKey(chatId, value) {
        localStorage.setItem('e2ee_secret_' + chatId, value);
    }

    return {
        encryptText,
        decryptText,
        encryptFile,
        decryptFile,
        getSecretKey,
        setSecretKey
    };
})();