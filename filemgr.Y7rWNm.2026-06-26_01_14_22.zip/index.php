<?php
// Подключаем единую базу данных и конфигурацию безопасных сессий
require_once 'db.php';

// AJAX обработчик проверки занятости ника (отрабатывает в фоне без перезагрузки)
if (isset($_GET['check_username'])) {
    header('Content-Type: application/json; charset=utf-8');
    $usernameToCheck = trim($_GET['check_username'] ?? '');
    
    if ($usernameToCheck === '') {
        echo json_encode(['available' => false, 'message' => 'Имя пользователя не может быть пустым.']);
        exit();
    }
    
    if (!preg_match('/^[a-zA-Z0-9]{3,20}$/', $usernameToCheck)) {
        echo json_encode(['available' => false, 'message' => 'Имя должно содержать только английские буквы и цифры.']);
        exit();
    }

    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$usernameToCheck]);
        $exists = $stmt->fetch();
        echo json_encode(['available' => !$exists]);
    } catch (PDOException $e) {
        echo json_encode(['available' => false, 'message' => 'Ошибка базы данных при проверке.']);
    }
    exit();
}

// Перенаправление на чаты, если сессия уже активна
if (isset($_SESSION['user_id'])) {
    header("Location: messages.php");
    exit();
}

// Генерация CSRF-токена для защиты форм
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Получение сообщений об ошибках или успехе из GET-параметров
$error = $_GET['error'] ?? null;
$success = $_GET['success'] ?? null;
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Вход и Регистрация</title>
    
    <!-- Подключение шрифта Inter из Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root{
            --bg:#f4f7fb;
            --card:#ffffff;
            --border:#e7edf5;
            --primary:#2AABEE;
            --primary-hover:#229ED9;
            --text:#1f2937;
            --muted:#6b7280;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
            --radius:24px;
        }

        * { 
            box-sizing: border-box; 
            font-family: 'Inter', system-ui, -apple-system, sans-serif; 
            margin: 0;
            padding: 0;
        }
        
        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 22px;
            color: var(--text);
            background: var(--bg);
            overflow-x: hidden;
        }

        .auth-container {
            width: 100%;
            max-width: 420px;
            padding: 40px 30px;
            border-radius: var(--radius);
            background: var(--card);
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }

        .form-toggle {
            display: flex;
            background: #f1f5f9;
            padding: 6px;
            border-radius: 16px;
            margin-bottom: 28px;
            border: 1px solid var(--border);
        }

        .form-toggle button {
            flex: 1;
            padding: 12px;
            border: none;
            background: transparent;
            color: var(--muted);
            font-weight: 600;
            cursor: pointer;
            border-radius: 11px;
            transition: 0.2s ease-in-out;
            font-size: 14px;
            letter-spacing: 0.5px;
        }

        .form-toggle button.active {
            background: #ffffff;
            color: var(--primary);
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }

        h2 {
            margin: 0 0 24px 0;
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.5px;
            text-align: center;
            color: var(--text);
        }

        /* УВЕДОМЛЕНИЯ / ОШИБКИ */
        .alert {
            padding: 14px 16px;
            border-radius: 14px;
            font-size: 14px;
            margin-bottom: 24px;
            text-align: center;
            font-weight: 500;
        }
        .alert-error {
            background: #fef2f2;
            border: 1px solid #fee2e2;
            color: #b91c1c;
        }
        .alert-success {
            background: #f0fdf4;
            border: 1px solid #dcfce7;
            color: #15803d;
        }

        .input-group {
            margin-bottom: 16px;
            text-align: left;
        }

        .input-group input {
            width: 100%;
            padding: 16px 20px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            color: var(--text);
            font-size: 15px;
            transition: 0.2s ease-in-out;
            outline: none;
        }

        .input-group input:focus {
            background: #ffffff;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(42, 171, 238, 0.12);
        }

        .input-group input::placeholder {
            color: #94a3b8;
        }

        /* Стиль вывода мгновенных предупреждений под полями */
        .input-feedback {
            font-size: 11px;
            margin-top: 5px;
            display: none;
            font-weight: 600;
            line-height: 1.35;
            padding: 0 6px;
        }
        .input-feedback.error {
            color: #ef4444;
            display: block;
        }
        .input-feedback.success {
            color: #22c55e;
            display: block;
        }

        .main-btn {
            width: 100%;
            padding: 16px;
            margin-top: 10px;
            border: none;
            border-radius: 14px;
            background: linear-gradient(135deg, #2AABEE, #229ED9);
            color: white;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s ease-in-out;
            box-shadow: 0 6px 20px rgba(42, 171, 238, 0.15);
        }

        .main-btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.05);
            box-shadow: 0 8px 25px rgba(42, 171, 238, 0.22);
        }

        .main-btn:active {
            transform: translateY(1px);
        }

        .main-btn:disabled {
            background: #cbd5e1;
            box-shadow: none;
            cursor: not-allowed;
            filter: none;
        }

        .forgot-pass {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: var(--muted);
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
            font-weight: 500;
        }

        .forgot-pass:hover {
            color: var(--primary);
        }

        .hidden {
            display: none;
        }

        @media (max-width: 480px) {
            .auth-container {
                padding: 30px 20px;
            }
            h2 { font-size: 24px; }
        }
    </style>
</head>
<body>

    <div class="auth-container">
        <div class="form-toggle">
            <button id="toggleLogin" class="active">Вход</button>
            <button id="toggleRegister">Регистрация</button>
        </div>

        <!-- Вывод ошибок/успешных действий -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <!-- Форма авторизации -->
        <form id="loginForm" class="auth-form" action="login.php" method="POST">
            <!-- Скрытый CSRF-токен безопасности -->
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <h2>С возвращением</h2>
            <div class="input-group">
                <input type="email" name="email" placeholder="Email" required autocomplete="email">
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Пароль" required autocomplete="current-password">
            </div>

            <!-- Блок ввода капчи для входа -->
            <div class="input-group" style="display: flex; gap: 10px; align-items: center; margin-bottom: 18px;">
                <input type="text" name="captcha" placeholder="Код с картинки" required style="flex: 1; margin-bottom: 0;">
                <img src="captcha.php?type=login" id="captchaImgLogin" style="border-radius: 12px; height: 48px; cursor: pointer; border: 1px solid #e2e8f0;" onclick="this.src='captcha.php?type=login&r='+Math.random();" title="Кликните, чтобы обновить картинку">
            </div>

            <button type="submit" class="main-btn">Войти</button>
            <a href="forgot_password.php" class="forgot-pass">Забыли пароль?</a>
        </form>

        <!-- Форма регистрации -->
        <form id="registerForm" class="auth-form hidden" action="register.php" method="POST">
            <!-- Скрытый CSRF-токен безопасности -->
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <h2>Создать аккаунт</h2>
            <div class="input-group">
                <input type="text" name="username" id="regUsername" placeholder="Имя пользователя (Ник)" required autocomplete="username">
                <div class="input-feedback" id="usernameFeedback"></div>
            </div>
            <div class="input-group">
                <input type="email" name="email" id="regEmail" placeholder="Email" required autocomplete="email">
                <div class="input-feedback" id="emailFeedback"></div>
            </div>
            <div class="input-group">
                <input type="password" name="password" id="regPassword" placeholder="Пароль" required autocomplete="new-password">
                <div class="input-feedback" id="passwordFeedback"></div>
            </div>

            <!-- Блок ввода капчи для регистрации -->
            <div class="input-group" style="display: flex; gap: 10px; align-items: center; margin-bottom: 18px;">
                <input type="text" name="captcha" placeholder="Код с картинки" required style="flex: 1; margin-bottom: 0;">
                <img src="captcha.php?type=register" id="captchaImgRegister" style="border-radius: 12px; height: 48px; cursor: pointer; border: 1px solid #e2e8f0;" onclick="this.src='captcha.php?type=register&r='+Math.random();" title="Кликните, чтобы обновить картинку">
            </div>

            <button type="submit" class="main-btn" id="regSubmitBtn" disabled>Зарегистрироваться</button>
        </form>
    </div>

    <script>
        const loginBtn = document.getElementById('toggleLogin');
        const registerBtn = document.getElementById('toggleRegister');
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');

        function showLoginForm() {
            loginBtn.classList.add('active');
            registerBtn.classList.remove('active');
            loginForm.classList.remove('hidden');
            registerForm.classList.add('hidden');
            // Обновляем картинку капчи входа при переключении вкладки
            document.getElementById('captchaImgLogin').src = 'captcha.php?type=login&r=' + Math.random();
        }

        function showRegisterForm() {
            registerBtn.classList.add('active');
            loginBtn.classList.remove('active');
            registerForm.classList.remove('hidden');
            loginForm.classList.add('hidden');
            // Обновляем картинку капчи регистрации при переключении вкладки
            document.getElementById('captchaImgRegister').src = 'captcha.php?type=register&r=' + Math.random();
        }

        loginBtn.addEventListener('click', showLoginForm);
        registerBtn.addEventListener('click', showRegisterForm);

        // Умное переключение вкладок при наличии ошибок/параметров в URL.
        const urlParams = new URLSearchParams(window.location.search);
        const currentTab = urlParams.get('tab');
        const errorText = urlParams.get('error') || '';

        if (currentTab === 'register' || errorText.toLowerCase().includes('регистрац') || errorText.toLowerCase().includes('username')) {
            showRegisterForm();
        }

        // === ИНТЕРАКТИВНАЯ КЛИЕНТСКАЯ ВАЛИДАЦИЯ ФОРМЫ РЕГИСТРАЦИИ ===
        const regUsername = document.getElementById('regUsername');
        const regEmail = document.getElementById('regEmail');
        const regPassword = document.getElementById('regPassword');
        const regSubmitBtn = document.getElementById('regSubmitBtn');

        const usernameFeedback = document.getElementById('usernameFeedback');
        const emailFeedback = document.getElementById('emailFeedback');
        const passwordFeedback = document.getElementById('passwordFeedback');

        let isUsernameValid = false;
        let isEmailValid = false;
        let isPasswordValid = false;

        function checkFormValidity() {
            if (isUsernameValid && isEmailValid && isPasswordValid) {
                regSubmitBtn.removeAttribute('disabled');
            } else {
                regSubmitBtn.setAttribute('disabled', 'true');
            }
        }

        function showFeedback(element, text, status) {
            element.textContent = text;
            element.className = "input-feedback";
            if (status === "error") {
                element.classList.add("error");
            } else if (status === "success") {
                element.classList.add("success");
            }
        }

        // Проверка логина
        regUsername.addEventListener('input', () => {
            const value = regUsername.value.trim();
            const usernameRegex = /^[a-zA-Z0-9]{3,20}$/;

            if (value === "") {
                showFeedback(usernameFeedback, "", "hide");
                isUsernameValid = false;
                checkFormValidity();
                return;
            }

            if (!usernameRegex.test(value)) {
                showFeedback(usernameFeedback, "Ник должен состоять только из английских букв и цифр (от 3 до 20 символов).", "error");
                isUsernameValid = false;
                checkFormValidity();
                return;
            }

            fetch('index.php?check_username=' + encodeURIComponent(value))
                .then(res => res.json())
                .then(data => {
                    if (data.available) {
                        showFeedback(usernameFeedback, "✓ Логин свободен!", "success");
                        isUsernameValid = true;
                    } else {
                        showFeedback(usernameFeedback, data.message || "✗ Этот логин уже занят.", "error");
                        isUsernameValid = false;
                    }
                    checkFormValidity();
                })
                .catch(() => {
                    showFeedback(usernameFeedback, "Ошибка соединения при проверке логина.", "error");
                    isUsernameValid = false;
                    checkFormValidity();
                });
        });

        // Проверка Email
        regEmail.addEventListener('input', () => {
            const value = regEmail.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (value === "") {
                showFeedback(emailFeedback, "", "hide");
                isEmailValid = false;
                checkFormValidity();
                return;
            }

            if (!emailRegex.test(value)) {
                showFeedback(emailFeedback, "Пожалуйста, введите корректный адрес почты.", "error");
                isEmailValid = false;
            } else {
                showFeedback(emailFeedback, "✓ Адрес почты указан верно", "success");
                isEmailValid = true;
            }
            checkFormValidity();
        });

        // Проверка сложности пароля
        regPassword.addEventListener('input', () => {
            const value = regPassword.value;
            
            if (value === "") {
                showFeedback(passwordFeedback, "", "hide");
                isPasswordValid = false;
                checkFormValidity();
                return;
            }

            const hasLowercase = /[a-z]/.test(value);
            const hasUppercase = /[A-Z]/.test(value);
            const onlyEnglish = /^[a-zA-Z0-9_!@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?]+$/.test(value);

            if (value.length < 8) {
                showFeedback(passwordFeedback, "Пароль должен содержать не менее 8 символов.", "error");
                isPasswordValid = false;
            } else if (!hasLowercase || !hasUppercase) {
                showFeedback(passwordFeedback, "Пароль должен содержать как строчные (a-z), так и заглавные (A-Z) английские буквы.", "error");
                isPasswordValid = false;
            } else if (!onlyEnglish) {
                showFeedback(passwordFeedback, "Пароль должен состоять исключительно из английских букв, цифр и спецсимволов.", "error");
                isPasswordValid = false;
            } else {
                showFeedback(passwordFeedback, "✓ Пароль соответствует всем требованиям безопасности", "success");
                isPasswordValid = true;
            }
            checkFormValidity();
        });

        // === ГАРАНТИРОВАННЫЙ СБРОС СТАРЫХ УВЕДОМЛЕНИЙ ПРИ РАЗЛОГИНЕ И НА СТРАНИЦЕ ВХОДА ===
        function runOneSignalLogout() {
            var bridge = window.Median || window.median || window.gonative;
            if (!bridge) return;
            try {
                // Новая модель (User-Centric SDK v5+)
                if (bridge.onesignal && typeof bridge.onesignal.logout === 'function') {
                    bridge.onesignal.logout();
                } else if (window.Median && window.Median.onesignal && typeof window.Median.onesignal.logout === 'function') {
                    window.Median.onesignal.logout();
                }
                
                // Устаревшая модель (Legacy / External User ID)
                if (bridge.onesignal && bridge.onesignal.externalUserId && typeof bridge.onesignal.externalUserId.remove === 'function') {
                    bridge.onesignal.externalUserId.remove();
                }
            } catch (e) {
                console.error("[OneSignal Logout Exception]", e);
            }
        }

        // Регистрируем вызовы при готовности библиотек нативного приложения
        window.median_library_ready = runOneSignalLogout;
        window.gonative_library_ready = runOneSignalLogout;

        if (window.Median && typeof window.Median.onReady === 'function') {
            window.Median.onReady(runOneSignalLogout);
        }
        if (window.Median || window.median || window.gonative) {
            runOneSignalLogout();
        }

        // Регулярные попытки на случай задержки инициализации моста в приложении
        var osLogoutAttempts = 0;
        var osLogoutInterval = setInterval(function() {
            osLogoutAttempts++;
            var bridge = window.Median || window.median || window.gonative;
            if (bridge) {
                clearInterval(osLogoutInterval);
                runOneSignalLogout();
            } else if (osLogoutAttempts > 15) {
                clearInterval(osLogoutInterval);
                try {
                    // Страховочная попытка сброса через прямую схему вызова native-функций
                    var iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = "gonative://onesignal/logout";
                    document.body.appendChild(iframe);
                    setTimeout(function() { iframe.remove(); }, 1000);
                } catch (e) {}
            }
        }, 200);
    </script>
</body>
</html>