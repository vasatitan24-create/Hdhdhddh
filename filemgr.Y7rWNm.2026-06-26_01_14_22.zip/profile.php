<?php


require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit;
}

$currentUser = $_SESSION['username'];
$profileUser = $_GET['user'] ?? $currentUser;
$isOwnProfile = ($profileUser === $currentUser);

$avatars = getAvatarList();

$stmtUser = $pdo->prepare("
    SELECT role, avatar_type, gender, last_seen
    FROM users
    WHERE username = ?
    LIMIT 1
");

$stmtUser->execute([$profileUser]);

$userData = $stmtUser->fetch();

$profileRole = $userData['role'] ?? 'user';
$profileAvatarIdx = (int)($userData['avatar_type'] ?? 0);
$profileGender = $userData['gender'] ?? 'male';
$lastSeen = $userData['last_seen'] ?? null;

$profileAvatar = getAvatarByType($profileAvatarIdx);

$genderText = [
    'male' => 'Мужской',
    'female' => 'Женский'
][$profileGender] ?? 'Не указан';

$genderIcon = [
    'male' => 'fa-mars',
    'female' => 'fa-venus'
][$profileGender] ?? 'fa-user';

$isOnline = $lastSeen && (time() - strtotime($lastSeen)) <= 60;

$lastSeenText = $lastSeen
    ? date('d.m.Y H:i', strtotime($lastSeen))
    : 'Неизвестно';

$stmtRole = $pdo->prepare("
    SELECT role
    FROM users
    WHERE username = ?
");

$stmtRole->execute([$currentUser]);

$isAdmin = ($stmtRole->fetchColumn() === 'admin');

$pdo->prepare("
    UPDATE users
    SET last_seen = NOW()
    WHERE username = ?
")->execute([$currentUser]);

if ($isOwnProfile) {

    $stmtUnread = $pdo->prepare("
        SELECT COUNT(*)
        FROM private_messages
        WHERE receiver = ?
        AND is_read = 0
    ");

    $stmtUnread->execute([$currentUser]);

} else {

    $stmtUnread = $pdo->prepare("
        SELECT COUNT(*)
        FROM private_messages
        WHERE sender = ?
        AND receiver = ?
        AND is_read = 0
    ");

    $stmtUnread->execute([
        $profileUser,
        $currentUser
    ]);
}

$unreadCount = (int)$stmtUnread->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ru">
<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
Профиль <?= htmlspecialchars($profileUser) ?>
</title>

<link rel="preconnect"
href="https://fonts.googleapis.com">

<link rel="preconnect"
href="https://fonts.gstatic.com"
crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

:root{
    --sidebar-width:320px;
    --primary:#2AABEE;
    --bg:#f5f7fb;
    --surface:#ffffff;
    --text:#222;
    --text-secondary:#666;
    --overlay:rgba(0,0,0,.45);
    --radius:28px;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
}

body{
    background:var(--bg);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
    overflow-x:hidden;
}

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:var(--sidebar-width);
    height:100%;
    background:#fff;
    box-shadow:2px 0 18px rgba(0,0,0,.08);
    transform:translateX(-100%);
    transition:.3s;
    z-index:1000;
    display:flex;
    flex-direction:column;
}

.sidebar.active{
    transform:translateX(0);
}

.sidebar-header{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:20px;
    border-bottom:1px solid #edf1f5;
}

.sidebar-header h2{
    font-size:20px;
}

.sidebar-profile{
    display:flex;
    align-items:center;
    gap:14px;
    padding:20px;
    border-bottom:1px solid #edf1f5;
}

.sidebar-avatar{
    width:50px;
    height:50px;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-size:20px;
}

.sidebar-user{
    font-weight:700;
    margin-bottom:3px;
}

.sidebar-gender{
    font-size:13px;
    color:#666;
}

.sidebar-menu{
    list-style:none;
    padding:10px 0;
}

.sidebar-menu a{
    display:flex;
    align-items:center;
    gap:14px;
    padding:16px 22px;
    text-decoration:none;
    color:#222;
    transition:.2s;
    font-weight:500;
}

.sidebar-menu a:hover{
    background:#f4f7fb;
}

.overlay{
    position:fixed;
    inset:0;
    background:var(--overlay);
    opacity:0;
    visibility:hidden;
    transition:.3s;
    z-index:900;
}

.overlay.active{
    opacity:1;
    visibility:visible;
}

.menu-toggle{
    position:fixed;
    top:16px;
    left:16px;
    width:46px;
    height:46px;
    border:none;
    border-radius:50%;
    background:var(--primary);
    color:white;
    font-size:20px;
    cursor:pointer;
    z-index:800;
    box-shadow:0 6px 18px rgba(42,171,238,.35);
}

.profile-container{
    width:100%;
    max-width:430px;
    background:white;
    border-radius:var(--radius);
    padding:34px 24px 24px;
    box-shadow:0 10px 40px rgba(0,0,0,.08);
    position:relative;
}

.top-right-actions{
    position:absolute;
    top:18px;
    right:18px;
}

.round-btn{
    width:46px;
    height:46px;
    border-radius:14px;
    background:#f4f7fb;
    border:1px solid #e5e7eb;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#333;
    text-decoration:none;
    font-size:18px;
    position:relative;
}

.mail-badge{
    position:absolute;
    top:-5px;
    right:-5px;
    min-width:20px;
    height:20px;
    border-radius:999px;
    background:#ef4444;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:11px;
    font-weight:700;
}

.online-tag{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    margin-bottom:20px;
    color:#666;
    font-size:12px;
    font-weight:700;
}

.dot{
    width:8px;
    height:8px;
    border-radius:50%;
}

.online{
    background:#22c55e;
}

.offline{
    background:#94a3b8;
}

.avatar-wrapper{
    width:120px;
    height:120px;
    margin:0 auto 18px;
}

.name-row{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    margin-bottom:12px;
}

.name-row h2{
    font-size:28px;
}

.gender-icon-btn{
    width:30px;
    height:30px;
    border-radius:50%;
    background:#f4f7fb;
    display:flex;
    align-items:center;
    justify-content:center;
}

.status{
    text-align:center;
    color:#666;
    margin-bottom:14px;
}

.role-badge{
    width:fit-content;
    margin:auto;
    padding:8px 18px;
    border-radius:999px;
    background:#eef6ff;
    color:#2AABEE;
    font-size:12px;
    font-weight:700;
}

.divider{
    height:1px;
    background:#edf1f5;
    margin:20px 0;
}

.bottom-nav{
    display:flex;
    gap:10px;
}

.nav-icon{
    flex:1;
    height:54px;
    border-radius:16px;
    background:#f4f7fb;
    border:1px solid #e5e7eb;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#333;
    text-decoration:none;
    font-size:20px;
}

.last-seen{
    text-align:center;
    color:#777;
    margin-top:18px;
    font-size:13px;
}

@media(max-width:480px){

    :root{
        --sidebar-width:100%;
    }

    .profile-container{
        padding:30px 18px 20px;
    }

}

</style>
</head>

<body>

<button class="menu-toggle"
id="toggleBtn">
☰
</button>

<div class="overlay"
id="overlay"></div>

<nav class="sidebar"
id="sidebar">

    <div class="sidebar-header">

        <h2>Меню</h2>

        <button class="round-btn"
        id="closeBtn">
            ✕
        </button>

    </div>

    <div class="sidebar-profile">

        <div class="sidebar-avatar"
        style="
            background:
            <?= htmlspecialchars($profileAvatar['bg']) ?>;
        ">

            <i class="fas
            <?= htmlspecialchars($profileAvatar['icon']) ?>">
            </i>

        </div>

        <div>

            <div class="sidebar-user">
                <?= htmlspecialchars($currentUser) ?>
            </div>

            <div class="sidebar-gender">
                Пол:
                <?= htmlspecialchars($genderText) ?>
            </div>

        </div>

    </div>

    <ul class="sidebar-menu">

        <li>
            <a href="messages.php">
                <span>💬</span>
                Чаты
            </a>
        </li>

        <li>
            <a href="users.php">
                <span>👥</span>
                Пользователи
            </a>
        </li>

        <li>
            <a href="games.php">
                <span>🎮</span>
                Игры
            </a>
        </li>

        <li>
            <a href="ai/ai.php">
                <span>🤖</span>
                AI Помощник
            </a>
        </li>

        <li>
            <a href="settings.php">
                <span>⚙️</span>
                Настройки
            </a>
        </li>

        <?php if ($isAdmin): ?>

        <li>
            <a href="admin.php">
                <span>🛡️</span>
                Админка
            </a>
        </li>

        <?php endif; ?>

        <li>
            <a href="logout.php">
                <span>⎋</span>
                Выход
            </a>
        </li>

    </ul>

</nav>

<div class="profile-container">

    <div class="top-right-actions">

        <a href="<?= $isOwnProfile
            ? 'messages.php'
            : 'dialog.php?user=' . urlencode($profileUser) ?>"
           class="round-btn">

            <i class="fas fa-paper-plane"></i>

            <?php if ($unreadCount > 0): ?>

            <span class="mail-badge"
            id="unreadBadge">

                <?= $unreadCount ?>

            </span>

            <?php endif; ?>

        </a>

    </div>

    <div class="online-tag">

        <span class="dot
        <?= $isOnline ? 'online' : 'offline' ?>">
        </span>

        <span>
            <?= $isOnline ? 'ONLINE' : 'OFFLINE' ?>
        </span>

    </div>

    <div class="avatar-wrapper">

        <?= renderAvatar($profileAvatarIdx) ?>

    </div>

    <div class="name-row">

        <h2>
            <?= htmlspecialchars($profileUser) ?>
        </h2>

        <div class="gender-icon-btn">

            <i class="fas
            <?= $genderIcon ?>">
            </i>

        </div>

    </div>

    <div class="status">

        <?= $isOwnProfile
            ? 'Личный кабинет'
            : 'Профиль пользователя' ?>

    </div>

    <div class="role-badge">

        <?= htmlspecialchars($profileRole) ?>

    </div>

    <div class="divider"></div>

    <div class="bottom-nav">

        <?php if ($isAdmin): ?>

        <a href="admin.php"
        class="nav-icon">
            🛡️
        </a>

        <?php endif; ?>

        <a href="games.php"
        class="nav-icon">

            <i class="fas fa-gamepad"></i>

        </a>

        <a href="users.php"
        class="nav-icon">
            👥
        </a>

        <a href="ai/ai.php"
        class="nav-icon">

            <i class="fas fa-robot"></i>

        </a>

    </div>

    <?php if (!$isOnline): ?>

    <div class="last-seen">

        Визит:
        <?= htmlspecialchars($lastSeenText) ?>

    </div>

    <?php endif; ?>

</div>

<script>

const sidebar =
document.getElementById('sidebar');

const overlay =
document.getElementById('overlay');

document.getElementById('toggleBtn')
.onclick = () => {

    sidebar.classList.add('active');
    overlay.classList.add('active');

};

document.getElementById('closeBtn')
.onclick = closeSidebar;

overlay.onclick = closeSidebar;

function closeSidebar(){

    sidebar.classList.remove('active');
    overlay.classList.remove('active');

}

let currentUnread =
<?= $unreadCount ?>;

setInterval(() => {

    fetch('unread_count.php')

    .then(r => r.text())

    .then(countStr => {

        const count =
        parseInt(countStr) || 0;

        let badge =
        document.getElementById('unreadBadge');

        currentUnread = count;

        if(count > 0){

            if(!badge){

                location.reload();

            }else{

                badge.textContent = count;

            }

        }else if(badge){

            badge.remove();

        }

    });

},5000);

</script>

</body>
</html>