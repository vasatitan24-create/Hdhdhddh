<?php
// === НАСТРОЙКА БЕЗОПАСНЫХ И ДОЛГОВЕЧНЫХ СЕССИЙ (30 ДНЕЙ) ===
if (session_status() === PHP_SESSION_NONE) {
    // Создаем локальную директорию для хранения сессий внутри проекта,
    // чтобы предотвратить их удаление системным сборщиком мусора хостинга.
    $session_dir = __DIR__ . '/sessions';
    if (!is_dir($session_dir)) {
        mkdir($session_dir, 0700, true);
    }
    ini_set('session.save_path', $session_dir);

    // Автоматически создаем .htaccess для защиты файлов сессий от веб-доступа
    $htaccess_file = $session_dir . '/.htaccess';
    if (!is_file($htaccess_file)) {
        file_put_contents($htaccess_file, "Require all denied\nDeny from all");
    }

    // Время жизни сессии и куки в браузере — 30 дней (в секундах)
    $lifetime = 2592000; 
    ini_set('session.cookie_lifetime', $lifetime);
    ini_set('session.gc_maxlifetime', $lifetime);

    // Защита передаваемых параметров сессии
    ini_set('session.cookie_httponly', 1); // Запрещает чтение куки через JS (защита от XSS)
    
    // Проверка HTTPS соединения для безопасной передачи куки
    if (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] === 1 || $_SERVER['SERVER_PORT'] == 443)) {
        ini_set('session.cookie_secure', 1);
    }
    ini_set('session.cookie_samesite', 'Lax');

    session_start();
}

// === ПОДКЛЮЧЕНИЕ К БАЗЕ ДАННЫХ ===
$host = "localhost";
$dbname = "mez526_igra";
$username = "mez526_igra";
$password = "bX4eI7xL5t";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}