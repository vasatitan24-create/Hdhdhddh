<?php

require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location:error.php");
    exit();
}

$currentUser = $_SESSION['username'];

$stmtRole = $pdo->prepare("
    SELECT role, avatar_type, gender
    FROM users
    WHERE username = :username
    LIMIT 1
");

$stmtRole->execute([
    'username' => $currentUser
]);

$user = $stmtRole->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['role'] !== 'admin') {
    die("Доступ запрещен.");
}

// Генерация CSRF-токена для защиты панели управления
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Фоновые миграции структуры БД
try {
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS settings (
        setting_key VARCHAR(50) PRIMARY KEY,
        setting_value TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (PDOException $e) {}

try {
    // Расширяем поле настроек до TEXT, чтобы длинные промпты не обрезались
    $pdo->exec("ALTER TABLE settings MODIFY COLUMN setting_value TEXT NULL");
} catch (PDOException $e) {}

try {
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS private_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender VARCHAR(50) NOT NULL,
        receiver VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        is_system TINYINT(1) DEFAULT 0,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (PDOException $e) {}

try {
    // Создаем унифицированную таблицу ai_cache, используемую всей остальной системой
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_cache (
            id INT AUTO_INCREMENT PRIMARY KEY,
            question_hash VARCHAR(64) UNIQUE NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            is_custom TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (PDOException $e) {}

// Проверка CSRF на все POST-запросы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        http_response_code(403);
        die("Ошибка безопасности: неверный или отсутствующий CSRF-токен.");
    }
}

// Вспомогательная функция очистки и конвертации HTML-тегов для совместимости с диалогом
function cleanBroadcastMessage($html) {
    $html = preg_replace('/<br\s*\/?>/i', "\n", $html);
    $html = str_ireplace(['<strong>', '</strong>'], ['<b>', '</b>'], $html);
    $html = str_ireplace(['<p>', '</p>'], ['<div>', '</div>'], $html);

    $html = preg_replace_callback('/<span\s+style="color:\s*([^";]+);?"[^>]*>(.*?)<\/span>/i', function($matches) {
        $colorInput = trim($matches[1]);
        $content = $matches[2];
        $color = '#2aabee';
        
        if (strpos($colorInput, 'rgb') !== false) {
            preg_match_all('/\d+/', $colorInput, $digits);
            if (isset($digits[0]) && count($digits[0]) >= 3) {
                $r = (int)$digits[0][0];
                $g = (int)$digits[0][1];
                $b = (int)$digits[0][2];
                $hex = sprintf("#%02x%02x%02x", $r, $g, $b);
                $colorInput = $hex;
            }
        }
        
        $colorInput = strtolower($colorInput);
        if ($colorInput === '#ef4444' || $colorInput === 'rgb(239, 68, 68)') {
            $color = '#ef4444';
        } elseif ($colorInput === '#22c55e' || $colorInput === 'rgb(34, 197, 94)') {
            $color = '#22c55e';
        } elseif ($colorInput === '#5aa7ff' || $colorInput === 'rgb(90, 167, 255)') {
            $color = '#5aa7ff';
        } elseif ($colorInput === '#ffffff' || $colorInput === 'rgb(255, 255, 255)') {
            $color = '#ffffff';
        } elseif ($colorInput === '#2aabee' || $colorInput === 'rgb(42, 171, 238)') {
            $color = '#2AABEE';
        }
        
        return '<font color="' . $color . '">' . $content . '</font>';
    }, $html);

    $html = str_ireplace(['&nbsp;', '&nbsp', '&#160;'], ' ', $html);
    $html = str_replace("\xC2\xA0", ' ', $html);
    $html = strip_tags($html, '<b><div><font>');
    $html = preg_replace('/<div>\s*<\/div>/i', '', $html);
    return trim($html);
}

// Вспомогательные функции для рассылки пуш-уведомлений
function onesignalCurlPost(array $fields, string $apiKey): array
{
    $authPrefix = (strpos($apiKey, 'os_') === 0) ? 'Key ' : 'Basic ';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.onesignal.com/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json; charset=utf-8',
        'Authorization: ' . $authPrefix . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

    $responseBody = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'body' => $responseBody,
        'http_code' => $httpCode
    ];
}

function sendBulkOneSignalPush(array $recipients, string $title, string $messageText): void
{
    $appId = "ebe09011-6587-4057-a4c1-f20d56b54763"; 
    $restApiKey = "os_v2_app_5pqjaelfq5afpjgb6igvnnkhmnekmr55skfexxfyqinicecrqd5joq2pccepslpgd3xgkz5uffpbnw7xjymp7qzxcbkffqqmnlgtwvy"; 

    $targetUrl = "https://neiro-bitva.ru/messages.php";

    $basePayload = [
        'app_id' => $appId,
        'headings' => ['ru' => $title, 'en' => $title],
        'contents' => ['ru' => "Система: " . $messageText, 'en' => "System: " . $messageText],
        'data' => ['targetUrl' => $targetUrl]
    ];

    $batches = array_chunk($recipients, 200);

    foreach ($batches as $batch) {
        $payloadV5 = array_merge($basePayload, [
            'include_aliases' => ['external_id' => $batch],
            'target_channel' => 'push'
        ]);

        $result = onesignalCurlPost($payloadV5, $restApiKey);

        if ($result['http_code'] === 400) {
            $payloadV3 = array_merge($basePayload, [
                'include_external_user_ids' => $batch
            ]);
            onesignalCurlPost($payloadV3, $restApiKey);
        }
    }
}

/* BROADCAST WITH HEADLINE AND PUSH NOTIFICATIONS */
if (isset($_POST['broadcast_news'])) {
    $newsTitle = trim($_POST['news_title'] ?? '');
    $newsContent = trim($_POST['news_content'] ?? '');

    if ($newsContent !== '' || $newsTitle !== '') {
        $stmtAll = $pdo->query("
            SELECT username
            FROM users
        ");

        $users = $stmtAll->fetchAll(PDO::FETCH_COLUMN);
        $cleanedContent = cleanBroadcastMessage($newsContent);

        $finalMessage = '';
        if ($newsTitle !== '') {
            $finalMessage .= "<b><font color=\"#2AABEE\">" . strip_tags($newsTitle) . "</font></b><div></div>";
        }
        $finalMessage .= "<div>" . $cleanedContent . "</div>";

        $stmtMsg = $pdo->prepare("
            INSERT INTO private_messages (sender, receiver, message, is_system)
            VALUES ('Система', :receiver, :msg, 1)
        ");

        foreach ($users as $receiver) {
            $stmtMsg->execute([
                'receiver' => $receiver,
                'msg' => $finalMessage
            ]);
        }

        $pushTitle = !empty($newsTitle) ? "Рассылка: " . strip_tags($newsTitle) : "Новое системное оповещение";
        $pushBody = !empty($newsContent) ? mb_substr(strip_tags($newsContent), 0, 80, 'UTF-8') . "..." : "Получена важная новость";
        
        sendBulkOneSignalPush($users, $pushTitle, $pushBody);

        header("Location: admin.php?tab=broadcast&success=1");
        exit();
    }
}

/* REGISTRATION STATUS */
if (isset($_POST['toggle_registration'])) {
    $currentStatusStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'registration_enabled' LIMIT 1");
    $currentStatus = $currentStatusStmt->fetchColumn();
    $newStatus = ($currentStatus === '0') ? '1' : '0';

    $stmtUpdate = $pdo->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('registration_enabled', :val)");
    $stmtUpdate->execute(['val' => $newStatus]);

    header("Location: admin.php?tab=settings");
    exit();
}

/* MAKE ADMIN */
if (isset($_POST['confirm_make_admin'])) {
    $userToMakeAdmin = $_POST['confirm_make_admin'];

    if ($userToMakeAdmin !== $currentUser) {
        $stmtMakeAdmin = $pdo->prepare("UPDATE users SET role = 'admin' WHERE username = :username");
        $stmtMakeAdmin->execute(['username' => $userToMakeAdmin]);

        header("Location: admin.php?tab=settings");
        exit();
    }
}

/* DELETE USER */
if (isset($_POST['confirm_delete'])) {
    $userToDelete = $_POST['confirm_delete'];

    if ($userToDelete !== $currentUser) {
        $stmtDelete = $pdo->prepare("DELETE FROM users WHERE username = :username");
        $stmtDelete->execute(['username' => $userToDelete]);

        header("Location: admin.php?tab=users");
        exit();
    }
}

/* === ОБРАБОТЧИКИ ОБУЧЕНИЯ И НАСТРОЕК ИИ === */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Сохранение API-ключа, Системного промпта, Прокси-сервера, cURL прокси и Имени модели
    if (isset($_POST['save_ai_settings'])) {
        $apiKey = trim($_POST['gemini_api_key'] ?? '');
        $prompt = trim($_POST['ai_system_instruction'] ?? '');
        $proxyUrl = trim($_POST['gemini_proxy_url'] ?? '');
        $curlProxy = trim($_POST['gemini_curl_proxy'] ?? '');
        $modelName = trim($_POST['ai_model_name'] ?? 'qwen/qwen-2.5-72b-instruct:free');

        $stmtKey = $pdo->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('gemini_api_key', ?)");
        $stmtKey->execute([$apiKey]);

        $stmtPrompt = $pdo->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('ai_system_instruction', ?)");
        $stmtPrompt->execute([$prompt]);

        $stmtProxy = $pdo->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('gemini_proxy_url', ?)");
        $stmtProxy->execute([$proxyUrl]);

        $stmtCurlProxy = $pdo->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('gemini_curl_proxy', ?)");
        $stmtCurlProxy->execute([$curlProxy]);

        $stmtModel = $pdo->prepare("REPLACE INTO settings (setting_key, setting_value) VALUES ('ai_model_name', ?)");
        $stmtModel->execute([$modelName]);

        header("Location: admin.php?tab=ai&saved=1");
        exit();
    }

    // 2. Добавление пользовательского правила ответов в единую таблицу ai_cache
    if (isset($_POST['add_ai_rule'])) {
        $question = trim($_POST['rule_question'] ?? '');
        $answer = trim($_POST['rule_answer'] ?? '');

        if ($question !== '' && $answer !== '') {
            $clean_q = preg_replace('/\s+/', ' ', mb_strtolower(trim($question), 'UTF-8'));
            $hash = hash('sha256', $clean_q);

            $stmtRule = $pdo->prepare("
                INSERT INTO ai_cache (question_hash, question, answer, is_custom)
                VALUES (?, ?, ?, 1)
                ON DUPLICATE KEY UPDATE question = VALUES(question), answer = VALUES(answer), is_custom = 1
            ");
            $stmtRule->execute([$hash, $question, $answer]);

            header("Location: admin.php?tab=ai&success_rule=1");
            exit();
        }
    }

    // 3. Сброс автоматического кэша в единой таблице ai_cache
    if (isset($_POST['clear_ai_cache'])) {
        $stmtClear = $pdo->query("DELETE FROM ai_cache WHERE is_custom = 0");
        header("Location: admin.php?tab=ai&cache_cleared=1");
        exit();
    }
}

/* ПОЛУЧЕНИЕ ДАННЫХ ИИ ДЛЯ ИНТЕРФЕЙСА ИЗ ЕДИНОЙ ТАБЛИЦЫ ai_cache */
$geminiApiKey = '';
try {
    $stmtVal = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'gemini_api_key' LIMIT 1");
    $geminiApiKey = $stmtVal->fetchColumn() ?: '';
} catch (PDOException $e) {}

$aiSystemInstruction = "Ты — приветливый ИИ-помощник на игровой платформе Neiro-Bitva. Отвечай кратко, грамотно, с умеренным использованием эмодзи.";
try {
    $stmtPromptVal = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'ai_system_instruction' LIMIT 1");
    $aiSystemInstruction = $stmtPromptVal->fetchColumn() ?: $aiSystemInstruction;
} catch (PDOException $e) {}

$geminiProxyUrl = '';
try {
    $stmtProxyVal = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'gemini_proxy_url' LIMIT 1");
    $geminiProxyUrl = $stmtProxyVal->fetchColumn() ?: '';
} catch (PDOException $e) {}

$geminiCurlProxy = '';
try {
    $stmtCurlProxyVal = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'gemini_curl_proxy' LIMIT 1");
    $geminiCurlProxy = $stmtCurlProxyVal->fetchColumn() ?: '';
} catch (PDOException $e) {}

$aiModelName = 'qwen/qwen-2.5-72b-instruct:free';
try {
    $stmtModelVal = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'ai_model_name' LIMIT 1");
    $aiModelName = $stmtModelVal->fetchColumn() ?: $aiModelName;
} catch (PDOException $e) {}

$totalCached = 0;
$totalCustom = 0;
$totalAuto = 0;
try {
    $totalCached = $pdo->query("SELECT COUNT(*) FROM ai_cache")->fetchColumn() ?: 0;
    $totalCustom = $pdo->query("SELECT COUNT(*) FROM ai_cache WHERE is_custom = 1")->fetchColumn() ?: 0;
    $totalAuto = $pdo->query("SELECT COUNT(*) FROM ai_cache WHERE is_custom = 0")->fetchColumn() ?: 0;
} catch (PDOException $e) {}

/* DATA FOR OTHER TABS */
$regStatusStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'registration_enabled' LIMIT 1");
$registrationEnabled = $regStatusStmt->fetchColumn();
if ($registrationEnabled === false) {
    $registrationEnabled = '1';
}

/* PAGINATION */
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 8;
$offset = ($page - 1) * $limit;

$totalUsersStmt = $pdo->query("SELECT COUNT(*) FROM users");
$totalUsers = $totalUsersStmt->fetchColumn();
$totalPages = ceil($totalUsers / $limit);

$stmtUsers = $pdo->prepare("
    SELECT username, role, last_seen, avatar_type
    FROM users
    ORDER BY last_seen DESC
    LIMIT :limit OFFSET :offset
");
$stmtUsers->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmtUsers->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmtUsers->execute();
$allUsers = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);

$myGender = [
    'male' => 'Мужской',
    'female' => 'Женский'
][$user['gender'] ?? 'male'] ?? 'Не указан';

$activeTab = $_GET['tab'] ?? 'broadcast';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Админ панель</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{
    --bg:#f4f7fb;
    --card:#ffffff;
    --border:#e7edf5;
    --primary:#2AABEE;
    --text:#1f2937;
    --muted:#6b7280;
}
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
}
body{
    background:var(--bg);
    color:var(--text);
    overflow-x:hidden;
}
.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:300px;
    height:100%;
    background:#ffffff;
    box-shadow:4px 0 24px rgba(0,0,0,.15);
    transform:translateX(-100%);
    transition: transform .25s cubic-bezier(0.4, 0, 0.2, 1);
    z-index:1000;
    display: flex;
    flex-direction: column;
}
.sidebar.active{
    transform:translateX(0);
}
.overlay{
    position:fixed;
    inset:0;
    background:rgba(15, 23, 42, 0.45);
    opacity:0;
    visibility:hidden;
    transition:.25s ease-in-out;
    z-index:950;
    backdrop-filter: blur(2px);
}
.overlay.active{
    opacity:1;
    visibility:visible;
}
.sidebar-profile {
    background: linear-gradient(135deg, #2AABEE, #229ED9);
    padding: 24px 20px 18px 20px;
    color: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
}
.sidebar-close-btn {
    position: absolute;
    top: 16px;
    right: 16px;
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.85);
    font-size: 16px;
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: background 0.15s, color 0.15s;
}
.sidebar-close-btn:hover {
    background: rgba(255,255,255,0.15);
    color: #ffffff;
}
.sidebar-avatar{
    width:64px;
    height:64px;
    min-width:64px;
    min-height:64px;
    border-radius:50%;
    overflow:hidden;
    position:relative;
    background:#ffffff;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
    border: 2px solid rgba(255, 255, 255, 0.25);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.sidebar-avatar > * {
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}
.sidebar-avatar img,
.sidebar-avatar svg {
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    object-position:center !important;
    display:block !important;
    border-radius:50% !important;
}
.sidebar-user-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}
.sidebar-user{
    font-size: 16px;
    font-weight:700;
    color: #ffffff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.sidebar-role{
    font-size:13px;
    color: rgba(255, 255, 255, 0.85);
}
.sidebar-menu{
    list-style:none;
    padding: 8px 0;
    overflow-y:auto;
    scrollbar-width:none;
    flex: 1;
}
.sidebar-menu::-webkit-scrollbar{
    display:none;
}
.sidebar-menu li {
    margin: 2px 8px;
}
.sidebar-menu a{
    display:flex;
    align-items:center;
    gap:20px;
    padding:12px 16px;
    text-decoration:none;
    color: #212121;
    font-weight:500;
    font-size: 14px;
    border-radius: 8px;
    transition: background 0.15s ease-in-out, color 0.15s;
}
.sidebar-menu a:hover{
    background: #f4f7f5;
}
.sidebar-menu a.active {
    background: #f0f7fc;
    color: #2AABEE;
    font-weight: 600;
}
.sidebar-menu a i {
    font-size: 18px;
    color: #707579;
    width: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: color 0.15s;
}
.sidebar-menu a:hover i {
    color: #2AABEE;
}
.sidebar-menu a.active i {
    color: #2AABEE;
}
.avatar-wrap {
    width: 52px;
    height: 52px;
    min-width: 52px;
    min-height: 52px;
    border-radius: 50%;
    overflow: hidden;
    background: #f3f4f6;
    position: relative;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease-in-out;
}
.avatar-wrap > * {
    width: 100% !important;
    height: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}
.avatar-wrap img,
.avatar-wrap svg {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    object-position: center !important;
    display: block !important;
    border-radius: 50% !important;
}
.container{
    max-width:920px;
    margin:0 auto;
    padding:0;
    background:#ffffff;
    min-height:100vh;
}
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:16px;
    margin-bottom:0;
    background: white;
    border-bottom: 1px solid var(--border);
    padding: 14px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
}
.header-left {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
}
.menu-btn-inline {
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #2AABEE;
    font-size: 20px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
    flex-shrink: 0;
}
.menu-btn-inline:hover {
    background: #f1f5f9;
}
.title{
    font-size:22px;
    font-weight:800;
    display: flex;
    align-items: center;
    gap: 8px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.tabs-wrapper {
    padding: 16px 16px 10px;
}
.tabs {
    display: flex;
    background: #f1f5f9;
    padding: 4px;
    border-radius: 12px;
    margin-bottom: 0;
    gap: 4px;
    overflow-x: auto;
    scrollbar-width: none;
}
.tabs::-webkit-scrollbar { display: none; }
.tab-btn {
    flex: 1;
    text-align: center;
    padding: 10px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    text-decoration: none;
    color: var(--muted);
    transition: 0.15s ease-in-out;
    white-space: nowrap;
}
.tab-btn.active {
    background: white;
    color: var(--primary);
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
.block-wrapper {
    padding: 0 16px 20px;
}
.block{
    background:white;
    border-radius:20px;
    padding:20px;
    border:1px solid var(--border);
    margin-bottom: 20px;
}
.block-title{
    font-size:18px;
    font-weight:800;
    margin-bottom:16px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.broadcast-toolbar{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
    margin-bottom:12px;
}
.broadcast-tool-btn{
    border:1px solid var(--border);
    background:#ffffff;
    color:var(--text);
    padding:8px 12px;
    border-radius:10px;
    font-size:13px;
    font-weight:600;
    cursor:pointer;
    transition: background 0.15s, border-color 0.15s;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.broadcast-tool-btn:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
}
.broadcast-input{
    width:100%;
    min-height:130px;
    border:1px solid var(--border);
    outline:none;
    background:#f8fafc;
    border-radius:14px;
    padding:14px;
    margin-bottom:14px;
    line-height:1.5;
    font-size: 15px;
    color: var(--text);
    transition: border-color 0.2s, background-color 0.2s;
}
.broadcast-input:focus {
    border-color: var(--primary);
    background-color: #ffffff;
}
.broadcast-btn{
    width:100%;
    border:none;
    background:#2AABEE;
    color:white;
    padding:14px;
    border-radius:14px;
    font-weight:700;
    cursor:pointer;
    transition: background 0.15s;
    font-size: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.broadcast-btn:hover {
    background: #2496d1;
}
.settings-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:12px;
}
.reg-toggle-btn{
    border:none;
    padding:12px 24px;
    border-radius:12px;
    color:white;
    font-weight:700;
    cursor:pointer;
    transition: opacity 0.15s;
}
.reg-toggle-btn:hover {
    opacity: 0.9;
}
.btn-enabled{
    background:#22c55e;
}
.btn-disabled{
    background:#ef4444;
}
.users-list {
    background: white;
    border: 1px solid var(--border);
    border-radius: 16px;
    overflow: hidden;
}
.user-card{
    background: white;
    border-bottom: 1px solid #edf1f5;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    transition: background 0.1s ease-in-out;
}
.user-card:last-child {
    border-bottom: none;
}
.user-card:hover {
    background: #f8fafc;
}
.user-main{
    display:flex;
    align-items:center;
    gap:14px;
    flex:1;
    min-width: 0;
}
.user-details {
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
    flex: 1;
}
.username-row {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
}
.username-row b {
    font-size:15px;
    font-weight: 700;
    color: var(--text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 150px;
}
.role-badge{
    font-size:10px;
    font-weight:700;
    padding:2px 6px;
    border-radius:6px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    background:#f1f5f9;
    color:var(--muted);
    flex-shrink: 0;
}
.role-badge.role-admin{
    background:#fee2e2;
    color:#ef4444;
}
.status-info{
    font-size:13px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.status-info.online {
    color: #22c55e;
    font-weight: 500;
}
.status-info.offline {
    color: var(--muted);
}
.status-dot {
    display: inline-block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    flex-shrink: 0;
}
.status-info.online .status-dot {
    background-color: #22c55e;
    box-shadow: 0 0 5px rgba(34, 197, 94, 0.6);
}
.status-info.offline .status-dot {
    background-color: #94a3b8;
}
.actions{
    display:flex;
    gap:8px;
    flex-shrink: 0;
}
.act-btn{
    border:none;
    padding:8px 14px;
    border-radius:10px;
    font-size:13px;
    font-weight:700;
    cursor:pointer;
    background:#eef6ff;
    color:#2AABEE;
    transition: 0.15s ease-in-out;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.act-btn:hover {
    background: #e0f2fe;
}
.act-btn.del{
    background:#fee2e2;
    color:#ef4444;
}
.act-btn.del:hover {
    background: #fecaca;
}
.pagination{
    display:flex;
    justify-content:center;
    gap:8px;
    margin-top:20px;
}
.page-btn{
    width:40px;
    height:40px;
    border-radius:12px;
    background:white;
    border:1px solid var(--border);
    text-decoration:none;
    color:var(--text);
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:700;
    transition: 0.15s;
}
.page-btn.active{
    background:#2AABEE;
    color:white;
    border-color:#2AABEE;
}
.modal-overlay{
    position:fixed;
    inset:0;
    background: rgba(15, 23, 42, 0.4);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:2000;
    padding:20px;
    backdrop-filter: blur(4px);
}
.modal{
    background:white;
    width:100%;
    max-width:360px;
    border-radius:20px;
    padding:24px;
    text-align:center;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}
.modal h3{
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 8px;
    color: var(--text);
}
.modal p{
    font-size: 14px;
    color: var(--muted);
    margin-bottom: 22px;
    line-height: 1.5;
}
.modal-btns{
    display:flex;
    gap:12px;
}
.modal-btns button{
    flex:1;
    border:none;
    padding:11px 16px;
    border-radius:12px;
    font-weight:600;
    cursor:pointer;
    font-size: 14px;
    transition: background 0.15s;
}
.confirm-btn{
    background:#2AABEE;
    color:white;
}
.confirm-btn:hover {
    background: #2496d1;
}
.cancel-btn{
    background:#f3f4f6;
    color:var(--text);
}
.cancel-btn:hover {
    background: #e5e7eb;
}
.del-confirm{
    background:#ef4444 !important;
}
.del-confirm:hover {
    background: #dc2626 !important;
}

/* Стили вкладок статистики и Обучения ИИ */
.ai-stats-row {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 20px;
}
.ai-stat-card {
    background: #f8fafc;
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 14px;
    text-align: center;
}
.ai-stat-card b {
    font-size: 20px;
    color: var(--primary);
    display: block;
    margin-bottom: 4px;
}
.ai-stat-card span {
    font-size: 11px;
    color: var(--muted);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

@media(max-width: 576px) {
    .act-btn .btn-text { display: none; }
    .act-btn { padding: 8px 10px; gap: 0; }
    .act-btn i { font-size: 14px; }
    .username-row b { max-width: 120px; }
    .ai-stats-row { grid-template-columns: 1fr; gap: 8px; }
}
@media(max-width:480px){
    .sidebar{ width: 280px; }
    .tabs-wrapper { padding: 10px 10px 6px; }
    .block-wrapper { padding: 0 10px 12px; }
    .block { padding: 16px 14px; border-radius: 16px; }
    .tab-btn { padding: 8px 4px; font-size: 12px; border-radius: 6px; }
    .tabs { border-radius: 10px; gap: 2px; }
    .header { padding: 10px 12px; }
    .menu-btn-inline { width: 36px; height: 36px; font-size: 18px; }
    .title { font-size: 18px; }
    .user-card { padding: 10px 12px; gap: 12px; }
    .avatar-wrap { width: 42px; height: 42px; min-width: 42px; min-height: 42px; }
    .username-row b { font-size: 14px; max-width: 100px; }
    .status-info { font-size: 12px; }
    .settings-row { flex-direction: column; align-items: stretch; gap: 16px; text-align: center; }
    .reg-toggle-btn { width: 100%; padding: 12px; }
    .broadcast-input { min-height: 110px; padding: 10px; font-size: 14px; margin-bottom: 12px; }
    .broadcast-tool-btn { padding: 8px 10px; font-size: 11px; }
    .pagination { margin-top: 16px; }
    .page-btn { width: 36px; height: 36px; border-radius: 10px; font-size: 13px; }
}
@media(max-width:360px) {
    .username-row b { max-width: 80px; }
}
</style>
</head>
<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="container">

<div class="header">
    <div class="header-left">
        <button class="menu-btn-inline" id="menuBtn">
            <i class="fa-solid fa-bars"></i>
        </button>
        <h1 class="title">Админ-панель</h1>
    </div>
</div>

<div class="tabs-wrapper">
    <div class="tabs">
        <a href="?tab=broadcast" class="tab-btn <?= $activeTab === 'broadcast' ? 'active' : '' ?>">Рассылка</a>
        <a href="?tab=users" class="tab-btn <?= $activeTab === 'users' ? 'active' : '' ?>">Пользователи</a>
        <a href="?tab=settings" class="tab-btn <?= $activeTab === 'settings' ? 'active' : '' ?>">Настройки</a>
        <a href="?tab=ai" class="tab-btn <?= $activeTab === 'ai' ? 'active' : '' ?>">Обучение ИИ</a>
    </div>
</div>

<div class="block-wrapper">

<?php if($activeTab === 'broadcast'): ?>
<?php if(isset($_GET['success'])): ?>
<div style="background:#dcfce7; color:#166534; padding:12px 16px; border-radius:12px; margin-bottom:16px; font-weight:700; border:1px solid #bbf7d0; font-size: 14px; text-align: center;">
    Рассылка новостей успешно отправлена всем пользователям!
</div>
<?php endif; ?>

<div class="block">
    <div class="block-title">Рассылка новостей</div>
    
    <form method="POST" onsubmit="prepareBroadcast()">
        <!-- Защита CSRF -->
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        
        <div style="margin-bottom: 16px;">
            <label style="font-weight: 700; font-size: 14px; display: block; margin-bottom: 6px; color: var(--text);">Заголовок новости</label>
            <input type="text" name="news_title" id="newsTitleInput" class="broadcast-input" style="min-height: auto; padding: 12px 16px; font-weight: 700; font-size: 15px;" placeholder="Введите краткий заголовок..." required>
        </div>

        <div style="margin-bottom: 6px;">
            <label style="font-weight: 700; font-size: 14px; display: block; color: var(--text);">Текст новости</label>
        </div>

        <div class="broadcast-toolbar" style="margin-bottom: 10px;">
            <button type="button" class="broadcast-tool-btn" onclick="formatBroadcast('bold')"><i class="fa-solid fa-bold"></i> Жирный</button>
            <button type="button" class="broadcast-tool-btn" onclick="formatBroadcast('foreColor','#ef4444')"><span style="color:#ef4444;">●</span> Красный</button>
            <button type="button" class="broadcast-tool-btn" onclick="formatBroadcast('foreColor','#22c55e')"><span style="color:#22c55e;">●</span> Зелёный</button>
            <button type="button" class="broadcast-tool-btn" onclick="formatBroadcast('foreColor','#2AABEE')"><span style="color:#2AABEE;">●</span> Синий</button>
        </div>

        <div id="broadcastEditor" class="broadcast-input" contenteditable="true" style="min-height: 150px; overflow-y: auto;" placeholder="Введите основной text новости..."></div>
        <input type="hidden" name="news_content" id="newsContent">
        
        <button type="submit" name="broadcast_news" class="broadcast-btn" style="margin-top: 16px;"><i class="fa-regular fa-paper-plane"></i> ОТПРАВИТЬ РАССЫЛКУ</button>
    </form>
</div>
<?php endif; ?>

<?php if($activeTab === 'settings'): ?>
<div class="block">
    <div class="block-title">Управление регистрацией</div>
    <div class="settings-row">
        <div>
            <div style="font-weight:700;">Регистрация</div>
            <div style="font-size:12px; color:#777; margin-top:4px;">
                <?= $registrationEnabled === '1' ? 'Открыта для всех' : 'Технические работы' ?>
            </div>
        </div>
        <form method="POST">
            <!-- Защита CSRF -->
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <button type="submit" name="toggle_registration" class="reg-toggle-btn <?= $registrationEnabled === '1' ? 'btn-enabled' : 'btn-disabled' ?>">
                <?= $registrationEnabled === '1' ? 'ВКЛ' : 'ВЫКЛ' ?>
            </button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if($activeTab === 'users'): ?>
<div class="users-list">
<?php foreach ($allUsers as $row):
    $lastSeen = !empty($row['last_seen']) ? strtotime($row['last_seen']) : 0;
    $isOnline = (time() - $lastSeen) <= 60;
?>
<div class="user-card">
    <div class="user-main">
        <div class="avatar-wrap">
            <?= renderAvatar($row['avatar_type'] ?? 0, $row['username']) ?>
        </div>
        <div class="user-details">
            <div class="username-row">
                <b><?= htmlspecialchars($row['username']) ?></b>
                <span class="role-badge <?= $row['role'] === 'admin' ? 'role-admin' : '' ?>">
                    <?= $row['role'] === 'admin' ? 'Админ' : 'Участник' ?>
                </span>
            </div>
            <div class="status-info <?= $isOnline ? 'online' : 'offline' ?>">
                <span class="status-dot"></span>
                <?= $isOnline ? 'В сети' : 'Не в сети' ?>
            </div>
        </div>
    </div>

    <?php if ($row['username'] !== $currentUser): ?>
    <div class="actions">
        <?php if ($row['role'] !== 'admin'): ?>
        <button class="act-btn" onclick="showModal('admin','<?= htmlspecialchars($row['username'], ENT_QUOTES) ?>')">
            <i class="fa-solid fa-user-shield"></i>
            <span class="btn-text">Админ</span>
        </button>
        <?php endif; ?>
        <button class="act-btn del" onclick="showModal('delete','<?= htmlspecialchars($row['username'], ENT_QUOTES) ?>')">
            <i class="fa-solid fa-trash-can"></i>
            <span class="btn-text">Удалить</span>
        </button>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>
</div>

<div class="pagination">
<?php for($i = 1; $i <= $totalPages; $i++): ?>
    <a href="?tab=users&page=<?= $i ?>" class="page-btn <?= $page == $i ? 'active' : '' ?>"><?= $i ?></a>
<?php endfor; ?>
</div>
<?php endif; ?>

<!-- === ВКЛАДКА "ОБУЧЕНИЕ ИИ" === -->
<?php if($activeTab === 'ai'): ?>

    <?php if(isset($_GET['saved'])): ?>
    <div style="background:#dcfce7; color:#166534; padding:12px 16px; border-radius:12px; margin-bottom:16px; font-weight:700; border:1px solid #bbf7d0; font-size: 14px; text-align: center;">
        Настройки интеграции OpenRouter и промпт успешно сохранены!
    </div>
    <?php endif; ?>

    <?php if(isset($_GET['success_rule'])): ?>
    <div style="background:#dcfce7; color:#166534; padding:12px 16px; border-radius:12px; margin-bottom:16px; font-weight:700; border:1px solid #bbf7d0; font-size: 14px; text-align: center;">
        Пользовательское правило вопрос-ответ успешно добавлено в базу знаний!
    </div>
    <?php endif; ?>

    <?php if(isset($_GET['cache_cleared'])): ?>
    <div style="background:#fee2e2; color:#991b1b; padding:12px 16px; border-radius:12px; margin-bottom:16px; font-weight:700; border:1px solid #fecaca; font-size: 14px; text-align: center;">
        Автоматический кэш нейросети полностью очищен. Пользовательские правила остались на месте.
    </div>
    <?php endif; ?>

    <!-- 1. Статистика базы знаний -->
    <div class="block">
        <div class="block-title"><i class="fa-solid fa-chart-line" style="color:var(--primary);"></i> Статистика и принцип работы ИИ</div>
        <p style="font-size:13.5px; line-height:1.5; color:var(--muted); margin-bottom:15px;">
            Наш ИИ-помощник использует двухконтурный механизм. Сначала вопрос пользователя преобразуется в хэш и ищется в <b>локальной базе данных</b>. Если точный ответ найден, он выдается за 0.001 секунды, экономя лимиты запросов. Если совпадения нет, сайт обращается к облачному <b>OpenRouter API</b> напрямую без каких-либо прокси и блокировок, возвращает ответ пользователю и автоматически сохраняет его в кэш.
        </p>
        <div class="ai-stats-row">
            <div class="ai-stat-card">
                <b><?= $totalCached ?></b>
                <span>Всего ответов в базе</span>
            </div>
            <div class="ai-stat-card">
                <b><?= $totalCustom ?></b>
                <span>Ручные правила (Админ)</span>
            </div>
            <div class="ai-stat-card">
                <b><?= $totalAuto ?></b>
                <span>Авто-кэш нейросети</span>
            </div>
        </div>
    </div>

    <!-- 2. Основные настройки и промпт -->
    <div class="block">
        <div class="block-title"><i class="fa-solid fa-sliders" style="color:var(--primary);"></i> Основные настройки ИИ</div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="save_ai_settings" value="1">

            <div style="margin-bottom: 16px;">
                <label style="font-weight: 700; font-size: 14px; display: block; margin-bottom: 6px; color: var(--text);">API-ключ OpenRouter</label>
                <input type="text" name="gemini_api_key" class="broadcast-input" style="min-height: auto; padding: 12px 16px; font-size: 14px;" placeholder="Вставьте ваш OpenRouter API Key (sk-or-v1-...)..." value="<?= htmlspecialchars($geminiApiKey) ?>" required>
            </div>

            <div style="margin-bottom: 16px;">
                <label style="font-weight: 700; font-size: 14px; display: block; margin-bottom: 6px; color: var(--text);">Имя модели ИИ (OpenRouter)</label>
                <input type="text" name="ai_model_name" class="broadcast-input" style="min-height: auto; padding: 12px 16px; font-size: 14px;" placeholder="Пример: qwen/qwen-2.5-72b-instruct:free" value="<?= htmlspecialchars($aiModelName) ?>" required>
                <span style="font-size: 11px; color: var(--muted); font-weight: 500; display: block; margin-top: -8px;">Рекомендуется использовать бесплатную модель qwen/qwen-2.5-72b-instruct:free (прекрасно владеет русским языком).</span>
            </div>

            <div style="margin-bottom: 16px;">
                <label style="font-weight: 700; font-size: 14px; display: block; margin-bottom: 6px; color: var(--text);">Системная инструкция (Промпт / Характер ИИ)</label>
                <textarea name="ai_system_instruction" class="broadcast-input" style="min-height: 100px; padding: 12px 16px; font-size: 14px; line-height: 1.45;" placeholder="Пример: Ты - ИИ-помощник на сайте Neiro-Bitva..." required><?= htmlspecialchars($aiSystemInstruction) ?></textarea>
                <span style="font-size: 11px; color: var(--muted); font-weight: 500; display: block; margin-top: -8px;">Опишите здесь роль ИИ, правила общения, список услуг сайта или важные нюансы, о которых он должен помнить при ответе.</span>
            </div>

            <button type="submit" class="broadcast-btn"><i class="fa-regular fa-floppy-disk"></i> Сохранить настройки ИИ</button>
        </form>
    </div>

    <!-- 3. Быстрое обучение (Добавление Custom Q&A) -->
    <div class="block">
        <div class="block-title"><i class="fa-solid fa-graduation-cap" style="color:var(--primary);"></i> Быстрое ручное обучение ИИ</div>
        <p style="font-size: 13px; color: var(--muted); margin-bottom: 15px;">
            Укажите точный вопрос (система сама приведет его к нижнему регистру и очистит от лишних пробелов) и ответ, который должен мгновенно выдаваться пользователю без отправки данных в нейросеть.
        </p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="add_ai_rule" value="1">

            <div style="margin-bottom: 16px;">
                <label style="font-weight: 700; font-size: 14px; display: block; margin-bottom: 6px; color: var(--text);">Ожидаемый вопрос от пользователя</label>
                <input type="text" name="rule_question" class="broadcast-input" style="min-height: auto; padding: 12px 16px; font-size: 14px;" placeholder="Пример: как скачать андроид приложение?" required>
            </div>

            <div style="margin-bottom: 16px;">
                <label style="font-weight: 700; font-size: 14px; display: block; margin-bottom: 6px; color: var(--text);">Мгновенный ответ ИИ</label>
                <textarea name="rule_answer" class="broadcast-input" style="min-height: 80px; padding: 12px 16px; font-size: 14px;" placeholder="Пример: Чтобы скачать наше официальное Android приложение, откройте боковое меню и разверните блок 'О нас', там будет кнопка скачивания APK-файла." required></textarea>
            </div>

            <button type="submit" class="broadcast-btn" style="background:#22c55e;"><i class="fa-solid fa-plus"></i> Добавить правило в базу знаний</button>
        </form>
    </div>

    <!-- 4. Сброс автоматического кэша -->
    <?php if ($totalAuto > 0): ?>
    <div class="block">
        <div class="block-title"><i class="fa-solid fa-eraser" style="color:#ef4444;"></i> Очистка памяти</div>
        <p style="font-size: 13px; color: var(--muted); margin-bottom: 15px;">
            Позволяет стереть автоматически сохраненные ответы, полученные от нейросети в процессе общения. Ручные правила, добавленные вами выше, удалены <b>не будут</b>.
        </p>
        <form method="POST" onsubmit="return confirm('Вы уверены, что хотите очистить автоматический кэш нейросети?');">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="clear_ai_cache" value="1">
            <button type="submit" class="broadcast-btn" style="background:#ef4444;"><i class="fa-solid fa-trash-can"></i> Очистить авто-кэш (<?= $totalAuto ?> ответов)</button>
        </form>
    </div>
    <?php endif; ?>

<?php endif; ?>

</div>
</div>

<div id="modalOverlay" class="modal-overlay">
<div class="modal">
    <h3 id="modalTitle">Подтверждение</h3>
    <p id="modalText">Вы уверены?</p>
    <form method="POST" id="modalForm">
        <!-- Защита CSRF -->
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <input type="hidden" name="" id="modalInput" value="">
        <div class="modal-btns">
            <button type="button" class="cancel-btn" onclick="closeModal()">Отмена</button>
            <button type="submit" id="modalConfirmBtn" class="confirm-btn">Подтвердить</button>
        </div>
    </form>
</div>
</div>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
document.getElementById('menuBtn').onclick = () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
};
document.getElementById('closeBtn').onclick = closeSidebar;
overlay.onclick = closeSidebar;

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
}

function formatBroadcast(command,value=null){
    document.getElementById('broadcastEditor').focus();
    document.execCommand(command,false,value);
}

function prepareBroadcast(){
    const editor = document.getElementById('broadcastEditor');
    if (editor) {
        document.getElementById('newsContent').value = editor.innerHTML.trim();
    }
}

function showModal(type,username){
    const modal = document.getElementById('modalOverlay');
    const title = document.getElementById('modalTitle');
    const text = document.getElementById('modalText');
    const input = document.getElementById('modalInput');
    const btn = document.getElementById('modalConfirmBtn');

    input.name = '';

    if(type === 'delete'){
        title.innerText = 'Удаление';
        text.innerText = 'Удалить пользователя ' + username + '?';
        input.name = 'confirm_delete';
        btn.classList.add('del-confirm');
    }else{
        title.innerText = 'Назначение';
        text.innerText = 'Сделать ' + username + ' администратором?';
        input.name = 'confirm_make_admin';
        btn.classList.remove('del-confirm');
    }

    input.value = username;
    modal.style.display = 'flex';
}

function closeModal(){
    document.getElementById('modalOverlay').style.display = 'none';
}

window.onclick = function(event){
    if(event.target === document.getElementById('modalOverlay')){
        closeModal();
    }
}
</script>
</body>
</html>