<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit();
}

function e2ee_is_base64($s) {
    if (!is_string($s) || $s === '') return false;
    return base64_encode(base64_decode($s, true)) === $s;
}

function safe_json_response($arr, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit();
}

function ensure_dir(string $dir): void {
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
}

function random_name(string $prefix = 'msg_', string $ext = 'bin'): string {
    return $prefix . bin2hex(random_bytes(16)) . '.' . $ext;
}

/**
 * Безопасная проверка того, находится ли относительный путь файла внутри разрешенного каталога uploads.
 */
function isSafeUploadPath(string $filePath): bool {
    $baseDir = realpath(__DIR__ . '/uploads');
    $realPath = realpath(__DIR__ . '/' . ltrim($filePath, '/\\'));
    
    if ($realPath === false || $baseDir === false) {
        return false;
    }
    
    return strpos($realPath, $baseDir) === 0;
}