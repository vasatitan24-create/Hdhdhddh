<?php
// Подключаем db.php для автоматического и безопасного старта долговечной сессии
require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: error.php");
    exit();
}

$userId = (int)$_SESSION['user_id'];
$currentUser = $_SESSION['username'] ?? null;

// === 1. ОБЪЯВЛЯЕМ ВСЕ ФУНКЦИИ В НАЧАЛЕ ФАЙЛА ===

// Загружаем прогресс пользователя из БД
function loadUserProgress(PDO $pdo, int $userId): array {
    try {
        $stmt = $pdo->prepare("SELECT progress_data FROM game_progress WHERE user_id = :user_id AND game_name = :game_name LIMIT 1");
        $stmt->execute([
            ':user_id' => $userId,
            ':game_name' => 'match3_pro'
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['progress_data'])) {
            $data = json_decode($row['progress_data'], true);
            if (is_array($data)) {
                return $data;
            }
        }
    } catch (PDOException $e) {
        // Безопасный откат при сбое БД
    }

    return [
        'unlockedLevel' => 1,
        'coins' => 0,
        'hints' => 0,
        'bombs' => 0,
        'timeBoosts' => 0,
        'lives' => 5,
        'lastRegenTime' => time() * 1000
    ];
}

// Таблица лидеров по уровню
function loadLeaderboard(PDO $pdo): array {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                gp.user_id,
                gp.progress_data,
                u.username
            FROM game_progress gp
            LEFT JOIN users u ON u.id = gp.user_id
            WHERE gp.game_name = :game_name
        ");
        $stmt->execute([
            ':game_name' => 'match3_pro'
        ]);

        $leaders = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $data = json_decode($row['progress_data'] ?? '', true);
            $level = (int)($data['unlockedLevel'] ?? 1);

            $leaders[] = [
                'username' => $row['username'] ?: ('ID ' . (int)$row['user_id']),
                'level' => $level
            ];
        }

        usort($leaders, function ($a, $b) {
            return $b['level'] <=> $a['level'];
        });

        return array_slice($leaders, 0, 10);
    } catch (PDOException $e) {
        return [];
    }
}

// === 2. ВЫПОЛНЯЕМ ЗАПРОСЫ ===

// AJAX обработчик для получения таблицы лидеров
if (isset($_GET['get_leaderboard']) || (isset($_GET['action']) && $_GET['action'] === 'get_leaderboard')) {
    header('Content-Type: application/json');
    echo json_encode(loadLeaderboard($pdo));
    exit();
}

$progress = loadUserProgress($pdo, $userId);
$leaderboard = loadLeaderboard($pdo);

$unlockedLevel = (int)($progress['unlockedLevel'] ?? 1);
$coins = (int)($progress['coins'] ?? 0);
$hints = (int)($progress['hints'] ?? 0);
$bombs = (int)($progress['bombs'] ?? 0);
$timeBoosts = (int)($progress['timeBoosts'] ?? 0);
$lives = (int)($progress['lives'] ?? 5);
$lastRegenTime = (int)($progress['lastRegenTime'] ?? (time() * 1000));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Три в ряд</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root{
            --bg:#f4f7fb;
            --card:#ffffff;
            --border:#e7edf5;
            --primary:#2AABEE;
            --text:#1f2937;
            --muted:#6b7280;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            --radius:24px;
            --gold:#d8b46a;
            --gold2:#f5d48a;
            --blue:#5aa7ff;
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
        }

        * { box-sizing: border-box; font-family: 'Inter', system-ui, -apple-system, sans-serif; margin: 0; padding: 0; }
        html, body { width: 100%; height: 100%; overflow: hidden; }
        
        body {
            background: var(--bg);
            color: var(--text);
            overflow: hidden;
        }

        /* Анимация исчезновения камней при обычном совмещении */
        @keyframes explode {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(0.6); opacity: 0; }
        }
        .exploding { animation: explode 0.2s ease-out forwards; z-index: 10; }

        /* Игровой контейнер */
        .game-wrapper {
            width: 100%;
            height: 100%;
            padding: 16px;
            background: var(--bg);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            margin: 0 auto;
            max-width: 440px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 10px;
            background: #ffffff;
            border-radius: 16px;
            margin-bottom: 8px;
            border: 1px solid var(--border);
            flex-shrink: 0;
            box-shadow: var(--shadow);
        }

        .header h1 { font-size: 15px; margin: 0; color: var(--text); font-weight: 800; letter-spacing: -0.3px; }

        .menu-btn-inline {
            border: none;
            border-radius: 50%;
            background: transparent;
            color: #2AABEE;
            font-size: 20px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.15s ease-in-out;
            flex-shrink: 0;
        }
        .menu-btn-inline:hover { background: #e2e8f0; }

        .lives-box {
            display: flex;
            align-items: center;
            gap: 4px;
            background: #eef2f6;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 700;
        }
        #lifeTimerDisplay { font-size: 11px; color: var(--muted); font-weight: 500; }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 4px;
            margin-bottom: 8px;
            padding: 8px 12px;
            background: #eef2f6;
            border-radius: 16px;
            flex-shrink: 0;
        }

        .stat-box {
            background: transparent;
            border: none;
            box-shadow: none;
            text-align: center;
        }
        .stat-label { font-size: 9px; color: var(--muted); text-transform: uppercase; margin-bottom: 2px; font-weight: 600; }
        .stat-val { font-size: 13px; font-weight: 800; color: var(--text); }

        .bonus-bar {
            display: flex;
            justify-content: center;
            gap: 12px;
            margin-bottom: 8px;
            flex-shrink: 0;
        }

        .bonus-icon {
            background: transparent;
            border: none;
            box-shadow: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
            cursor: pointer;
            transition: transform 0.15s;
        }
        .bonus-icon:hover { transform: scale(1.05); }
        .bonus-icon span:first-child { font-size: 24px; }
        .bonus-icon .stat-val { font-size: 11px; color: var(--muted); font-weight: 700; }
        .bonus-icon.active { transform: scale(1.1); filter: drop-shadow(0 0 8px rgba(245,158,11,0.5)); }
        .bonus-icon.disabled { opacity: 0.25; filter: grayscale(1); }

        .board-container {
            flex-grow: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            min-height: 0;
            margin-bottom: 8px;
        }

        .board {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 5px;
            width: 100%;
            max-width: 400px;
            aspect-ratio: 1/1;
            background: #eef2f6;
            padding: 8px;
            border-radius: 20px;
            border: 1px solid var(--border);
            position: relative;
        }

        /* Самоцветы */
        .cell {
            background: #ffffff;
            border: 1px solid rgba(0, 0, 0, 0.03);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8vw;
            cursor: pointer;
            user-select: none;
            aspect-ratio: 1/1;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
            transition: transform 0.1s, background-color 0.15s;
        }
        @media (min-width: 440px) {
            .cell { font-size: 32px; }
        }
        .cell.selected { transform: scale(0.92); background: #f0f7fc; border-color: var(--primary); }

        /* Стиль для активной подсказки (пульсирующее золотое свечение) */
        @keyframes pulse-hint {
            0% { box-shadow: 0 0 4px #f59e0b; background-color: #fef3c7; border-color: #f59e0b; transform: scale(1); }
            50% { box-shadow: 0 0 16px #f59e0b; background-color: #fde68a; border-color: #d97706; transform: scale(0.95); }
            100% { box-shadow: 0 0 4px #f59e0b; background-color: #fef3c7; border-color: #f59e0b; transform: scale(1); }
        }
        .cell.hint {
            animation: pulse-hint 1s infinite ease-in-out;
            z-index: 5;
            position: relative;
        }

        /* Эффект тряски игрового поля при взрыве бомбы */
        @keyframes shake {
            0%, 100% { transform: translate(0, 0); }
            10%, 30%, 50%, 70%, 90% { transform: translate(-4px, 2px); }
            20%, 40%, 60%, 80% { transform: translate(4px, -2px); }
        }
        .shake {
            animation: shake 0.3s ease-in-out;
        }

        /* Плавная анимация взрыва бомбы без громоздких областей наложения */
        @keyframes bomb-explode {
            0% { transform: scale(1) rotate(0deg); filter: brightness(1) saturate(1); }
            30% { transform: scale(1.35) rotate(15deg); filter: brightness(2.8) saturate(1.8); }
            100% { transform: scale(0) rotate(-45deg); filter: brightness(4) opacity(0); }
        }
        .bomb-exploding {
            animation: bomb-explode 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
            z-index: 20;
        }

        .controls { display: block; margin-top: 8px; flex-shrink: 0; }
        
        .btn {
            padding: 12px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.15s;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
        }
        .btn-success { background: #22c55e; color: #fff; }
        .btn-primary { background: #3b82f6; color: #fff; }
        .btn-warning { background: var(--gold); color: #000; }
        .btn-danger { background: #ef4444; color: #fff; }

        .game-overlay {
            position: absolute;
            inset: 0;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 100;
            padding: 24px;
            border-radius: var(--radius);
        }
        .game-overlay.active { display: flex; }

        .menu-card {
            width: 100%;
            background: transparent;
            text-align: center;
            display: flex;
            flex-direction: column;
            height: 100%;
            justify-content: center;
            color: var(--text);
        }

        .leaderboard-box {
            margin-top: 15px;
            background: #f1f5f9;
            padding: 10px; border-radius: 16px; text-align: left;
            border: 1px solid var(--border);
            max-height: 25vh;
            overflow-y: auto;
        }
        .leaderboard-box::-webkit-scrollbar { width: 3px; }
        .leaderboard-box::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.05); border-radius: 999px; }

        .leaderboard-title { color: #b45309; font-weight: 800; margin-bottom: 6px; text-align: center; font-size: 12px; text-transform: uppercase; }
        .leaderboard-table { width: 100%; font-size: 11px; border-collapse: collapse; }
        .leaderboard-table td { padding: 6px 4px; border-bottom: 1px solid var(--border); color: var(--text); }

        .shop-item {
            display: flex; align-items: center; justify-content: space-between;
            background: #f1f5f9;
            padding: 10px; border-radius: 14px; margin-bottom: 8px;
            border: 1px solid var(--border);
            font-size: 13px;
        }

        @media (max-width: 360px) {
            .cell { font-size: 6.2vw; }
            .game-wrapper { padding: 12px; }
            .header { padding: 4px 6px; }
        }
    </style>
</head>
<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="game-wrapper">
    <div class="header">
        <div style="display:flex; gap:6px; align-items:center;">
            <button class="menu-btn-inline" id="menuBtn" title="Меню">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 id="levelHeader">Уровень 1</h1>
        </div>
        
        <div class="lives-box">
            <span style="color:#ff5b7a; font-weight:800;">❤️ <span id="livesDisplay"><?= (int)$lives ?></span></span>
            <span id="lifeTimerDisplay"></span>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-box" style="grid-column: span 2;"><div class="stat-label">Цели уровня</div><div class="stat-val" id="goal">0</div></div>
        <div class="stat-box"><div class="stat-label">Время</div><div class="stat-val" id="timer">00:00</div></div>
        <div class="stat-box"><div class="stat-label">Монеты</div><div class="stat-val"><span id="coinsDisplay"><?= (int)$coins ?></span> 💰</div></div>
    </div>

    <div class="bonus-bar">
        <div class="bonus-icon" id="bonusHint" onclick="useHint()">
            <span>💡</span><span class="stat-val" id="bonusHintCount"><?= (int)$hints ?></span>
        </div>
        <div class="bonus-icon" id="bonusBomb" onclick="activateBombMode()">
            <span>💣</span><span class="stat-val" id="bonusBombCount"><?= (int)$bombs ?></span>
        </div>
        <div class="bonus-icon" id="bonusTime" onclick="useTimeBoost()">
            <span>⏰</span><span class="stat-val" id="bonusTimeCount"><?= (int)$timeBoosts ?></span>
        </div>
    </div>

    <div class="board-container">
        <div id="board" class="board"></div>
    </div>

    <div class="controls">
        <button class="btn btn-warning" style="width: 100%;" onclick="shuffleBoard()">Перемешать поле (5 💰)</button>
    </div>

    <!-- Локальные оверлеи -->
    <div id="startMenu" class="game-overlay active">
        <div class="menu-card">
            <h2 style="color:var(--primary); margin-bottom:15px; font-size: 22px; letter-spacing: 0.5px;">ГЛАВНОЕ МЕНЮ</h2>
            <div style="background:#f1f5f9; padding:16px; border-radius:20px; margin-bottom:15px; border: 1px solid var(--border);">
                <div style="font-size:14px; margin-bottom:4px; font-weight: 700;">Жизни: <span id="menuLives" style="color:#ff5b7a; font-weight:800;"><?= (int)$lives ?></span>/5</div>
                <div id="menuLifeTimer" style="font-size:11px; color:var(--muted); font-weight: 500;"></div>
                <div style="font-size:14px; margin-top:4px; font-weight: 700;">Монеты: <span id="menuCoins" style="color:var(--gold); font-weight:800;"><?= (int)$coins ?></span> 💰</div>
            </div>
            <button class="btn btn-success" style="width:100%; margin-bottom:10px; padding:15px; font-size: 13px;" onclick="startGame(unlockedLevel)">ИГРАТЬ (УРОВЕНЬ <span id="startMenuLvl"><?= (int)$unlockedLevel ?></span>)</button>
            <div style="display:flex; gap:10px;">
                <button class="btn btn-primary" style="flex:1; padding: 12px;" onclick="openShop()">МАГАЗИН</button>
                <button class="btn btn-danger" style="flex:1; padding: 12px;" onclick="window.location.href='games.php'">ВЫХОД</button>
            </div>

            <div class="leaderboard-box">
                <div class="leaderboard-title">ТОП-10 ИГРОКОВ</div>
                <table class="leaderboard-table">
                    <tbody id="leaderboardBody">
                    <?php foreach ($leaderboard as $index => $leader): ?>
                        <tr>
                            <td style="color:var(--muted);"><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($leader['username']) ?></td>
                            <td style="text-align:right; font-weight:800; color:var(--primary);">LVL <?= (int)$leader['level'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="shopMenu" class="game-overlay">
        <div class="menu-card">
            <h2 style="font-size: 20px; margin-bottom: 10px;">МАГАЗИН</h2>
            <div style="text-align:right; margin-bottom:12px; color:var(--text); font-weight:800; font-size: 13px;">БАЛАНС: <span id="shopCoins">0</span> 💰</div>
            <div class="shop-item">
                <span>❤️ Восстановить Жизни</span>
                <button class="btn btn-success" style="padding: 6px 12px; font-size: 10px;" onclick="buyItem('life')">50 💰</button>
            </div>
            <div class="shop-item">
                <span>💡 Подсказка</span>
                <button class="btn btn-success" style="padding: 6px 12px; font-size: 10px;" onclick="buyItem('hint')">15 💰</button>
            </div>
            <div class="shop-item">
                <span>💣 Бомба</span>
                <button class="btn btn-success" style="padding: 6px 12px; font-size: 10px;" onclick="buyItem('bomb')">30 💰</button>
            </div>
            <div class="shop-item">
                <span>⏰ Время +30с</span>
                <button class="btn btn-success" style="padding: 6px 12px; font-size: 10px;" onclick="buyItem('time')">20 💰</button>
            </div>
            <button class="btn btn-danger" style="width:100%; margin-top:10px;" onclick="goToMenu()">В МЕНЮ</button>
        </div>
    </div>

    <div id="resultMenu" class="game-overlay">
        <div class="menu-card" style="justify-content: center; height: auto; margin: auto 0;">
            <h2 id="resultTitle" style="font-size: 2.2rem; margin-bottom: 8px;">ПОБЕДА!</h2>
            <p id="resultText" style="color:var(--muted); margin-bottom:20px; font-size: 13px;"></p>
            <div style="display:grid; gap:8px; width: 100%;">
                <button class="btn btn-success" id="nextBtn" style="padding: 14px;" onclick="nextLevel()">СЛЕДУЮЩИЙ УРОВЕНЬ</button>
                <button class="btn btn-warning" style="padding: 12px;" onclick="retryLevel()">ПОВТОРИТЬ</button>
                <button class="btn btn-danger" style="padding: 12px;" onclick="goToMenu()">В ГЛАВНОЕ МЕНЮ</button>
            </div>
        </div>
    </div>
</div>

<script>
var USER_ID = <?= (int)$userId ?>;

var gems = ['🔮', '💎', '🔥', '⭐', '🍀', '🍎', '🪐'];
var GOAL_POOL = ['🔮', '💎', '🔥', '⭐', '🍀', '🍎', '🪐'];

var targetGem1 = '🔮', targetGem2 = '💎';
var targetCount1 = 0, targetCount2 = 0;

var board = [], level = 1, timeLeft = 0;
var lives = <?= (int)$lives ?>, coins = <?= (int)$coins ?>, hints = <?= (int)$hints ?>, bombs = <?= (int)$bombs ?>, timeBoosts = <?= (int)$timeBoosts ?>;
var unlockedLevel = <?= (int)$unlockedLevel ?>, selected = null, busy = false, gameStarted = false, bombMode = false;
var timerInterval;
var comboCount = 0;

var MAX_LIVES = 5;
var REGEN_TIME = 900;
var SHUFFLE_COST = 5;
var lastRegenTime = <?= (int)$lastRegenTime ?>;

var audioCtx = null;
function playSound(f, t, d) {
    if (!t) t = 'sine';
    if (!d) d = 0.1;
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        var o = audioCtx.createOscillator();
        var g = audioCtx.createGain();
        o.type = t; 
        o.frequency.setValueAtTime(f, audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + d);
        o.connect(g); 
        g.connect(audioCtx.destination);
        o.start(); 
        o.stop(audioCtx.currentTime + d);
    } catch (e) {
        console.warn("Аудио-движка отклонена:", e);
    }
}

// Басовый звук раската для активации бомбы
function playExplosionSound() {
    try {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        var osc = audioCtx.createOscillator();
        var gain = audioCtx.createGain();
        
        osc.type = 'triangle'; 
        osc.frequency.setValueAtTime(180, audioCtx.currentTime); 
        osc.frequency.exponentialRampToValueAtTime(10, audioCtx.currentTime + 0.5);
        
        gain.gain.setValueAtTime(0.6, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
        
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.start();
        osc.stop(audioCtx.currentTime + 0.5);
    } catch (e) {
        console.warn("Синтез аудиоэффекта отклонен:", e);
    }
}

// Отправка прогресса на обработчик save_progress.php
function saveProgress() {
    var data = { unlockedLevel: unlockedLevel, coins: coins, hints: hints, bombs: bombs, timeBoosts: timeBoosts, lives: lives, lastRegenTime: lastRegenTime };
    fetch('save_progress.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'game_name=match3_pro&progress_data=' + encodeURIComponent(JSON.stringify(data))
    }).catch(function() {});
}

// Запрос рейтинга с обновленным параметром get_leaderboard
function refreshLeaderboard() {
    fetch('game_match3.php?get_leaderboard=1', { cache: 'no-store' })
        .then(function(res) { return res.json(); })
        .then(function(leaders) {
            var tbody = document.getElementById('leaderboardBody');
            if (!tbody) return;
            tbody.innerHTML = '';
            
            leaders.forEach(function(leader, index) {
                var tr = document.createElement('tr');
                var td1 = document.createElement('td');
                td1.style.color = 'var(--muted)';
                td1.textContent = index + 1;
                var td2 = document.createElement('td');
                td2.textContent = leader.username;
                var td3 = document.createElement('td');
                td3.style.textAlign = 'right';
                td3.style.fontWeight = '800';
                td3.style.color = 'var(--primary)';
                td3.textContent = 'LVL ' + parseInt(leader.level);
                
                tr.appendChild(td1);
                tr.appendChild(td2);
                tr.appendChild(td3);
                tbody.appendChild(tr);
            });
        })
        .catch(function(e) { console.error("Лидерборд не обновился", e); });
}

function updateCurrencyHud() {
    var ids = ['coinsDisplay','menuCoins','shopCoins'];
    for (var i = 0; i < ids.length; i++) {
        var el = document.getElementById(ids[i]);
        if (el) el.textContent = coins;
    }
    document.getElementById('menuLives').textContent = lives;
    document.getElementById('livesDisplay').textContent = lives;
    document.getElementById('bonusHintCount').textContent = hints;
    document.getElementById('bonusBombCount').textContent = bombs;
    document.getElementById('bonusTimeCount').textContent = timeBoosts;
    
    var startMenuLvl = document.getElementById('startMenuLvl');
    if (startMenuLvl) startMenuLvl.textContent = unlockedLevel;
}

function processLivesRegen() {
    if (lives < MAX_LIVES) {
        var now = Date.now();
        var diff = Math.floor((now - lastRegenTime) / 1000);
        if (diff >= REGEN_TIME) {
            var gained = Math.floor(diff / REGEN_TIME);
            lives = Math.min(MAX_LIVES, lives + gained);
            lastRegenTime = now - (diff % REGEN_TIME) * 1000;
            saveProgress();
        }
        var remaining = REGEN_TIME - (diff % REGEN_TIME);
        var m = Math.floor(remaining / 60), s = remaining % 60;
        var timeStr = m + ':' + (s < 10 ? '0' + s : s);
        document.getElementById('livesDisplay').textContent = lives;
        document.getElementById('lifeTimerDisplay').textContent = '| ' + timeStr;
        document.getElementById('menuLives').textContent = lives;
        document.getElementById('menuLifeTimer').textContent = "Новая жизнь через: " + timeStr;
    } else {
        document.getElementById('livesDisplay').textContent = lives;
        document.getElementById('lifeTimerDisplay').textContent = "";
        document.getElementById('menuLives').textContent = lives;
        document.getElementById('menuLifeTimer').textContent = "";
    }
    updateCurrencyHud();
}

setInterval(processLivesRegen, 1000);

// Исключаем появление готовых комбинаций на старте с помощью findMatches()
function buildBoard() {
    var attempts = 0;
    do {
        board = [];
        for(var y=0; y<7; y++) {
            board[y] = [];
            for(var x=0; x<7; x++) {
                board[y][x] = gems[Math.floor(Math.random() * gems.length)];
            }
        }
        attempts++;
        if (attempts > 500) break; 
    } while (findMatches().length > 0);
    render();
}

function render(highlights) {
    if (!highlights) highlights = [];
    var container = document.getElementById('board');
    container.innerHTML = '';
    board.forEach(function(row, y) {
        row.forEach(function(gem, x) {
            var div = document.createElement('div');
            div.className = 'cell';

            if (selected && selected.x === x && selected.y === y) div.classList.add('selected');
            
            var isHint = false;
            for (var i = 0; i < highlights.length; i++) {
                if (highlights[i].x === x && highlights[i].y === y) {
                    isHint = true;
                    break;
                }
            }
            if (isHint) div.classList.add('hint');
            
            var textNode = document.createTextNode(gem || '');
            div.appendChild(textNode);

            div.onclick = function() { handleCellClick(x, y); };
            container.appendChild(div);
        });
    });
}

function handleCellClick(x, y) {
    if (busy || !gameStarted) return;
    if (bombMode) {
        if (bombs > 0) {
            bombs--; 
            bombMode = false;
            
            playExplosionSound(); 
            
            // Встряска поля
            var boardEl = document.getElementById('board');
            boardEl.classList.add('shake');
            setTimeout(function() {
                boardEl.classList.remove('shake');
            }, 300);

            explodeArea(x, y);
            updateCurrencyHud(); 
            saveProgress(); 
        }
        return;
    }
    if (!selected) {
        selected = {x: x, y: y}; 
        render(); 
        playSound(400);
    } else {
        var dx = Math.abs(x - selected.x), dy = Math.abs(y - selected.y);
        if ((dx === 1 && dy === 0) || (dx === 0 && dy === 1)) {
            busy = true; 
            var s1 = selected; 
            animateSwap(s1, {x: x, y: y});
            setTimeout(function() {
                swap(s1.x, s1.y, x, y);
                if (findMatches().length > 0) {
                    selected = null; 
                    comboCount = 0; 
                    processMatches();
                    saveProgress(); 
                } else {
                    swap(s1.x, s1.y, x, y); 
                    selected = null; 
                    render();
                    busy = false; 
                }
            }, 150);
        } else { 
            selected = {x: x, y: y}; 
            render(); 
        }
    }
}

function animateSwap(p1, p2) {
    var cells = document.getElementById('board').children;
    var c1 = cells[p1.y * 7 + p1.x];
    var c2 = cells[p2.y * 7 + p2.x];
    var dx = (p2.x - p1.x) * c1.offsetWidth, dy = (p2.y - p1.y) * c1.offsetHeight;
    c1.style.transition = c2.style.transition = 'transform 0.15s';
    c1.style.transform = 'translate(' + dx + 'px, ' + dy + 'px)';
    c2.style.transform = 'translate(' + (-dx) + 'px, ' + (-dy) + 'px)';
}

function processMatches() {
    var matches = findMatches();
    if (matches.length === 0) {
        busy = false; 
        checkEnd(); // Проверка окончания игры при нулевом количестве каскадов
        return;
    }
    busy = true;

    comboCount++; 

    matches.forEach(function(p) {
        var gem = board[p.y][p.x];
        if (gem === targetGem1) {
            targetCount1 = Math.max(0, targetCount1 - 1);
        } else if (gem === targetGem2) {
            targetCount2 = Math.max(0, targetCount2 - 1);
        }
    });

    updateHud();

    // Мгновенная проверка достижения целей внутри каскада ходов
    if (targetCount1 <= 0 && targetCount2 <= 0) {
        checkEnd();
    }

    var pitch = 450 + (comboCount * 100);
    playSound(pitch, 'triangle', 0.2);

    var cells = document.getElementById('board').children;
    matches.forEach(function(p) { 
        if(cells[p.y * 7 + p.x]) cells[p.y * 7 + p.x].classList.add('exploding'); 
    });
    
    setTimeout(function() {
        matches.forEach(function(p) {
            board[p.y][p.x] = null;
        });

        for (var x = 0; x < 7; x++) {
            var empty = 6;
            for (var y = 6; y >= 0; y--) {
                if (board[y][x]) { 
                    board[empty][x] = board[y][x]; 
                    if (empty !== y) {
                        board[y][x] = null;
                    } 
                    empty--; 
                }
            }
            for (var y = empty; y >= 0; y--) {
                board[y][x] = gems[Math.floor(Math.random() * gems.length)];
            }
        }

        render(); 
        
        setTimeout(function() {
            processMatches();
        }, 120);
    }, 200);
}

function explodeArea(cx, cy) {
    busy = true; 
    var affected = [];
    for(var y=cy-1; y<=cy+1; y++) {
        for(var x=cx-1; x<=cx+1; x++) {
            if(x>=0 && x<7 && y>=0 && y<7) {
                affected.push({x: x, y: y});
            }
        }
    }

    // Подсчет уничтоженных бомбой целевых фигур ДО очистки
    affected.forEach(function(p) {
        var gem = board[p.y][p.x];
        if (gem === targetGem1) {
            targetCount1 = Math.max(0, targetCount1 - 1);
        } else if (gem === targetGem2) {
            targetCount2 = Math.max(0, targetCount2 - 1);
        }
    });

    updateHud();

    // Мгновенная проверка достижения целей сразу после взрыва бомбы
    if (targetCount1 <= 0 && targetCount2 <= 0) {
        checkEnd();
    }

    var cells = document.getElementById('board').children;
    affected.forEach(function(p) { 
        if(cells[p.y*7 + p.x]) {
            cells[p.y*7 + p.x].classList.add('bomb-exploding'); 
        }
    });
    
    setTimeout(function() {
        affected.forEach(function(p) {
            board[p.y][p.x] = null;
        });
        for (var x = 0; x < 7; x++) {
            var empty = 6;
            for (var y = 6; y >= 0; y--) { 
                if (board[y][x]) { 
                    board[empty][x] = board[y][x]; 
                    if (empty !== y) {
                        board[y][x] = null;
                    } 
                    empty--; 
                } 
            }
            for (var y = empty; y >= 0; y--) {
                board[y][x] = gems[Math.floor(Math.random() * gems.length)];
            }
        }
        render(); 
        processMatches(); 
    }, 300); 
}

function findMatches() {
    var visited = [];
    for (var i = 0; i < 7; i++) {
        visited[i] = [];
        for (var j = 0; j < 7; j++) {
            visited[i][j] = false;
        }
    }
    var allMatches = [];
    
    for (var y = 0; y < 7; y++) {
        for (var x = 0; x < 7; x++) {
            if (!visited[y][x] && board[y][x]) {
                var currentGroup = [];
                var color = board[y][x];
                var queue = [{x: x, y: y}];
                visited[y][x] = true;
                
                while (queue.length > 0) {
                    var cell = queue.shift(); 
                    currentGroup.push(cell);
                    
                    var neighbors = [
                        {nx:1,ny:0},{nx:-1,ny:0},{nx:0,ny:1},{nx:0,ny:-1}
                    ];
                    for (var n = 0; n < neighbors.length; n++) {
                        var nx = neighbors[n].nx;
                        var ny = neighbors[n].ny;
                        var tx = cell.x+nx;
                        var ty = cell.y+ny;
                        if (tx>=0 && tx<7 && ty>=0 && ty<7 && !visited[ty][tx] && board[ty][tx] === color) {
                            visited[ty][tx] = true; 
                            queue.push({x: tx, y: ty});
                        }
                    }
                }
                if (currentGroup.length >= 3) {
                    allMatches = allMatches.concat(currentGroup);
                }
            }
        }
    }
    return allMatches;
}

function swap(x1, y1, x2, y2) { 
    var t = board[y1][x1]; board[y1][x1] = board[y2][x2]; board[y2][x2] = t; 
}

function startGame(lv) {
    if (lives <= 0) return alert("Кончились жизни!");
    level = lv; busy = false; gameStarted = true;
    
    timeLeft = 60 + (lv * 5);
    
    var shuffledPool = [];
    for (var i = 0; i < GOAL_POOL.length; i++) {
        shuffledPool.push(GOAL_POOL[i]);
    }
    shuffledPool.sort(function() { return 0.5 - Math.random(); });
    
    targetGem1 = shuffledPool[0];
    targetGem2 = shuffledPool[1];
    
    targetCount1 = 8 + (lv * 2);
    targetCount2 = 8 + (lv * 2);

    hideOverlays(); 
    updateHud(); 
    buildBoard(); 
    startTimer();
}

function startTimer() {
    clearInterval(timerInterval);
    timerInterval = setInterval(function() {
        if(!gameStarted) return;
        if(--timeLeft <= 0) checkEnd();
        updateTimerDisplay();
    }, 1000);
}

function checkEnd() {
    if(!gameStarted) return;
    if(targetCount1 <= 0 && targetCount2 <= 0) {
        gameStarted = false; 
        if(level >= unlockedLevel) {
            unlockedLevel = level + 1;
        }
        
        // Сбалансированная награда за прохождение
        var coinsWon = 15 + (level * 2);
        coins += coinsWon; 
        
        saveProgress(); 
        refreshLeaderboard();
        showResult("ПОБЕДА!", `Все цели собраны! Получено награды: ${coinsWon} 💰. Прогресс сохранён.`, true);
    } else if(timeLeft <= 0) {
        if (lives === MAX_LIVES) lastRegenTime = Date.now();
        gameStarted = false; 
        lives--; 
        saveProgress();
        showResult("ПОРАЖЕНИЕ", `Время вышло. Не все цели были собраны!`, false);
    }
}

function showResult(t, txt, ok) {
    document.getElementById('resultTitle').textContent = t;
    document.getElementById('resultText').textContent = txt;
    document.getElementById('nextBtn').style.display = ok ? 'block' : 'none';
    document.getElementById('resultMenu').classList.add('active');
}

function updateHud() {
    document.getElementById('goal').textContent = targetGem1 + ' ' + targetCount1 + ' | ' + targetGem2 + ' ' + targetCount2;
    document.getElementById('levelHeader').textContent = 'Уровень ' + level;
    updateCurrencyHud();
}

function updateTimerDisplay() {
    var m = Math.floor(timeLeft / 60);
    var s = timeLeft % 60;
    document.getElementById('timer').textContent = m + ':' + (s < 10 ? '0' + s : s);
}

function useHint() {
    if(!gameStarted || hints <= 0 || busy) return;
    
    // Проверка горизонтальных перестановок
    for(var y=0; y<7; y++) {
        for(var x=0; x<6; x++) {
            swap(x,y,x+1,y);
            if(findMatches().length > 0) {
                swap(x,y,x+1,y);
                hints--;
                updateCurrencyHud();
                saveProgress();
                render([{x: x, y: y},{x: x+1, y: y}]);
                return;
            }
            swap(x,y,x+1,y);
        }
    }
    
    // Проверка вертикальных перестановок
    for(var y=0; y<6; y++) {
        for(var x=0; x<7; x++) {
            swap(x,y,x,y+1);
            if(findMatches().length > 0) {
                swap(x,y,x,y+1);
                hints--;
                updateCurrencyHud();
                saveProgress();
                render([{x: x, y: y},{x: x, y: y+1}]);
                return;
            }
            swap(x,y,x,y+1);
        }
    }
    
    alert("Нет доступных ходов! Пожалуйста, перемешайте поле.");
}

function activateBombMode() {
    if(!gameStarted || bombs <= 0) return;
    bombMode = !bombMode;
    updateCurrencyHud();
}

function useTimeBoost() {
    if(!gameStarted || timeBoosts <= 0) return;
    timeBoosts--; timeLeft += 30; updateCurrencyHud(); saveProgress();
}

function buyItem(type) {
    const prices = { life: 50, hint: 15, bomb: 30, time: 20 };
    if(coins < prices[type]) return alert("Недостаточно монет!");
    coins -= prices[type];
    if(type === 'life') { lives = MAX_LIVES; lastRegenTime = Date.now(); }
    if(type === 'hint') hints++; if(type === 'bomb') bombs++; if(type === 'time') timeBoosts++;
    updateCurrencyHud(); saveProgress(); playSound(900);
}

function openLevels() {
    hideOverlays(); const grid = document.getElementById('levelGrid'); grid.innerHTML = '';
    const maxLevelToRender = Math.max(unlockedLevel + 24, 40);
    
    for(var i=1; i<=maxLevelToRender; i++) {
        var btn = document.createElement('button');
        btn.className = 'lvl-btn' + (i > unlockedLevel ? ' locked' : '');
        btn.textContent = i;
        if(i <= unlockedLevel) {
            (function(levelNum) {
                btn.onclick = function() { startGame(levelNum); };
            })(i);
        }
        grid.appendChild(btn);
    }
    document.getElementById('levelMenu').classList.add('active');
}

function openShop() { hideOverlays(); document.getElementById('shopMenu').classList.add('active'); updateCurrencyHud(); }
function goToMenu() { hideOverlays(); document.getElementById('startMenu').classList.add('active'); gameStarted=false; updateCurrencyHud(); refreshLeaderboard(); }
function hideOverlays() { 
    var overlays = document.querySelectorAll('.game-overlay');
    for (var i = 0; i < overlays.length; i++) {
        overlays[i].classList.remove('active');
    }
}
function nextLevel() { startGame(level + 1); }
function retryLevel() { startGame(level); }

function shuffleBoard() {
    if(gameStarted && !busy) {
        if (coins < SHUFFLE_COST) return alert("Нужно 5 монет!");
        coins -= SHUFFLE_COST; updateCurrencyHud(); saveProgress(); buildBoard();
    }
}

(function() {
    var sidebarEl = document.getElementById('sidebar');
    var overlayEl = document.getElementById('overlay');
    var menuBtnEl = document.getElementById('menuBtn');
    var closeBtnEl = document.getElementById('closeBtn');

    if (menuBtnEl && sidebarEl && overlayEl) {
        menuBtnEl.onclick = function() {
            sidebarEl.classList.add('active');
            overlayEl.classList.add('active');
        };
    }
    if (closeBtnEl && sidebarEl && overlayEl) {
        closeBtnEl.onclick = closeSidebarMenu;
    }
    if (overlayEl && sidebarEl) {
        overlayEl.onclick = closeSidebarMenu;
    }

    function closeSidebarMenu(){
        sidebarEl.classList.remove('active');
        overlayEl.classList.remove('active');
    }
})();

function loadProgressUI() { updateCurrencyHud(); processLivesRegen(); }
loadProgressUI(); buildBoard();
</script>
</body>
</html>