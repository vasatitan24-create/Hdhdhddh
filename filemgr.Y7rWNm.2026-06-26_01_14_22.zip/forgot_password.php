<?php
// Подключаем базу данных и сессии по верному пути
require_once 'db.php';

// Автоматически создаем таблицу токенов, если ее еще нет в вашей БД
$pdo->exec("
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Валидация CSRF-токена безопасности
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        $error = "Ошибка безопасности: неверный CSRF-токен.";
    } else {
        $email = trim($_POST['email'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Пожалуйста, укажите корректный адрес электронной почты.";
        } else {
            try {
                // Проверяем, существует ли аккаунт с этим email
                $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$user) {
                    $error = "Пользователь с таким адресом электронной почты не найден.";
                } else {
                    // Создаем одноразовый токен сброса пароля
                    $token = bin2hex(random_bytes(32));
                    $expiresAt = date('Y-m-d H:i:s', time() + 3600); // Токен активен ровно 1 час

                    // Удаляем старые неиспользованные токены этого email
                    $del = $pdo->prepare("DELETE FROM password_resets WHERE email = ?");
                    $del->execute([$email]);

                    // Записываем новый токен в БД
                    $ins = $pdo->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
                    $ins->execute([$email, $token, $expiresAt]);

                    // Формируем ссылку восстановления
                    $protocol = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['SERVER_PORT'] == 443)) ? 'https://' : 'http://';
                    
                    // Нормализуем путь к текущей папке для создания корректного URL
                    $dir = dirname($_SERVER['PHP_SELF']);
                    $dir = ($dir === DIRECTORY_SEPARATOR) ? '' : $dir;
                    
                    $resetLink = $protocol . $_SERVER['HTTP_HOST'] . $dir . '/reset_password.php?token=' . $token . '&email=' . urlencode($email);

                    // Отправляем письмо через системную функцию mail()
                    $to = $email;
                    $subject = "Восстановление пароля | " . $_SERVER['HTTP_HOST'];
                    
                    $message = "Здравствуйте, " . htmlspecialchars($user['username']) . "!\n\n";
                    $message .= "Вы запросили восстановление пароля на сайте " . $_SERVER['HTTP_HOST'] . ".\n";
                    $message .= "Для сброса пароля перейдите по следующей ссылке:\n\n";
                    $message .= $resetLink . "\n\n";
                    $message .= "Ссылка действительна в течение 1 часа.\n";
                    $message .= "Если вы не запрашивали сброс пароля, просто проигнорируйте это письмо.\n\n";
                    $message .= "С уважением,\nАдминистрация сайта.";

                    $headers = "From: noreply@" . $_SERVER['HTTP_HOST'] . "\r\n";
                    $headers .= "Reply-To: noreply@" . $_SERVER['HTTP_HOST'] . "\r\n";
                    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
                    $headers .= "X-Mailer: PHP/" . phpversion();

                    // Безопасная отправка
                    if (@mail($to, $subject, $message, $headers)) {
                        $success = "Ссылка для восстановления успешно отправлена. Проверьте ваш почтовый ящик (и папку Спам).";
                    } else {
                        $error = "Не удалось отправить письмо через сервер. Обратитесь к администратору.";
                    }
                }
            } catch (PDOException $e) {
                $error = "Ошибка базы данных во время обработки запроса.";
            }
        }
    }
}

// Генерация CSRF-токена безопасности формы
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Восстановление пароля</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{
            --bg:#f4f7fb;
            --card:#ffffff;
            --border:#e7edf5;
            --primary:#2AABEE;
            --text:#1f2937;
            --muted:#6b7280;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
            --radius:24px;
        }
        * { box-sizing: border-box; font-family: 'Inter', sans-serif; margin: 0; padding: 0; }
        body { min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 22px; background: var(--bg); }
        .auth-container { width: 100%; max-width: 420px; padding: 40px 30px; border-radius: var(--radius); background: var(--card); border: 1px solid var(--border); box-shadow: var(--shadow); text-align: center; }
        h2 { margin-bottom: 24px; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; }
        p { font-size: 14px; color: var(--muted); margin-bottom: 20px; line-height: 1.45; }
        .alert { padding: 14px 16px; border-radius: 14px; font-size: 14px; margin-bottom: 24px; text-align: center; font-weight: 500; }
        .alert-error { background: #fef2f2; border: 1px solid #fee2e2; color: #b91c1c; }
        .alert-success { background: #f0fdf4; border: 1px solid #dcfce7; color: #15803d; }
        .input-group { margin-bottom: 18px; }
        .input-group input { width: 100%; padding: 16px 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 14px; color: var(--text); font-size: 15px; outline: none; }
        .input-group input:focus { background: #ffffff; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(42, 171, 238, 0.12); }
        .main-btn { width: 100%; padding: 16px; border: none; border-radius: 14px; background: linear-gradient(135deg, #2AABEE, #229ED9); color: white; font-size: 16px; font-weight: 700; cursor: pointer; transition: 0.2s; box-shadow: 0 6px 20px rgba(42, 171, 238, 0.15); }
        .main-btn:hover { transform: translateY(-1px); filter: brightness(1.05); }
        .back-link { display: inline-block; margin-top: 20px; color: var(--muted); text-decoration: none; font-size: 14px; font-weight: 600; }
        .back-link:hover { color: var(--primary); }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2>Сброс пароля</h2>
        <p>Введите ваш Email, указанный при регистрации, и мы отправим вам ссылку для безопасной смены пароля.</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <!-- Защита CSRF -->
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="input-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <button type="submit" class="main-btn">Отправить ссылку</button>
        </form>

        <a href="index.php" class="back-link">Вернуться к авторизации</a>
    </div>
</body>
</html>