<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: error.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Кликер</title>
    <style>
        body {
            margin: 0;
            font-family: sans-serif;
            background: #f4f7f6;
            text-align: center;
        }
        .wrap {
            max-width: 480px;
            margin: 0 auto;
            padding: 20px;
        }
        .btn {
            padding: 14px 20px;
            border: none;
            border-radius: 12px;
            background: #28a745;
            color: #fff;
            font-size: 20px;
            font-weight: bold;
        }
        .small {
            background: #6c757d;
            text-decoration: none;
            display: inline-block;
            margin-top: 15px;
        }
        .count {
            font-size: 48px;
            margin: 30px 0;
        }
    </style>
</head>
<body>
<div class="wrap">
    <h1>Кликер</h1>
    <div class="count" id="count">0</div>
    <button class="btn" onclick="add()">Клик!</button>
    <div>
        <button class="btn" style="margin-top:15px;" onclick="saveProgress()">Сохранить</button>
    </div>
    <div>
        <a class="btn small" href="games.php">Назад</a>
    </div>
</div>

<script>
const gameName = 'clicker';
let count = 0;

function add() {
    count++;
    document.getElementById('count').textContent = count;
}

function saveProgress() {
    const data = { count };
    fetch('save_progress.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'game_name=' + encodeURIComponent(gameName) + '&progress_data=' + encodeURIComponent(JSON.stringify(data))
    })
    .then(r => r.text())
    .then(() => alert('Прогресс сохранён'));
}

function loadProgress() {
    fetch('load_progress.php?game_name=' + encodeURIComponent(gameName))
        .then(r => r.json())
        .then(data => {
            if (data && data.count !== undefined) {
                count = data.count;
                document.getElementById('count').textContent = count;
            }
        });
}

loadProgress();
</script>
</body>
</html>