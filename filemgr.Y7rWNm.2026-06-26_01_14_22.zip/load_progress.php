<?php
// Подключаем db.php для автоматического и безопасного старта долговечной сессии
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Нет доступа');
}

$user_id = (int)$_SESSION['user_id'];
$game_name = $_GET['game_name'] ?? '';

if ($game_name === '') {
    http_response_code(400);
    exit('Нет названия игры');
}

$stmt = $pdo->prepare("SELECT progress_data FROM game_progress WHERE user_id = :user_id AND game_name = :game_name LIMIT 1");
$stmt->execute([
    ':user_id' => $user_id,
    ':game_name' => $game_name
]);

$row = $stmt->fetch();

header('Content-Type: application/json; charset=utf-8');

if ($row) {
    echo $row['progress_data'];
} else {
    echo json_encode([]);
}
?>