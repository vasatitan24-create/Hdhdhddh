const toggleLogin = document.getElementById('toggleLogin');
const toggleRegister = document.getElementById('toggleRegister');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

toggleLogin.addEventListener('click', () => {
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
    toggleLogin.classList.add('active');
    toggleRegister.classList.remove('active');
});

toggleRegister.addEventListener('click', () => {
    registerForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
    toggleRegister.classList.add('active');
    toggleLogin.classList.remove('active');
});