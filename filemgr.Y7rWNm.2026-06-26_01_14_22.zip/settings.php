<?php

require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit;
}

$currentUser = $_SESSION['username'];
$avatars = getAvatarList();

$stmt = $pdo->prepare("
    SELECT avatar_type, gender, role, email, password
    FROM users
    WHERE username = ?
");
$stmt->execute([$currentUser]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$currentAvatar = (int)($user['avatar_type'] ?? 0);
$currentGender = $user['gender'] ?? 'male';
$currentEmail = $user['email'] ?? '';
$isAdmin = ($user['role'] ?? '') === 'admin';

// Генерация токена защиты CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$activeTab = 'avatar'; // Активная вкладка по умолчанию

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Валидация CSRF токена
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        http_response_code(403);
        die("Ошибка безопасности: неверный или отсутствующий CSRF-токен.");
    }

    $avatar = (int)($_POST['avatar'] ?? 0);
    $gender = $_POST['gender'] ?? 'male';
    if (!in_array($gender, ['male', 'female'])) {
        $gender = 'male';
    }

    $email = trim($_POST['email'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $currentPassword = $_POST['current_password'] ?? '';
    $passwordHash = null;

    // 1. Проверка и изменение email
    if ($email !== $currentEmail) {
        $activeTab = 'security';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Пожалуйста, укажите корректный адрес электронной почты.";
        } else {
            // Проверка, не занят ли email другим пользователем
            $checkEmail = $pdo->prepare("SELECT id FROM users WHERE email = ? AND username != ? LIMIT 1");
            $checkEmail->execute([$email, $currentUser]);
            if ($checkEmail->fetch()) {
                $error = "Этот адрес электронной почты уже используется другим аккаунтом.";
            } elseif (empty($currentPassword) || !password_verify($currentPassword, $user['password'])) {
                $error = "Для изменения email необходимо ввести верный текущий пароль.";
            }
        }
    }

    // 2. Проверка и изменение пароля
    if (!isset($error) && $newPassword !== '') {
        $activeTab = 'security';
        $hasLowercase = preg_match('/[a-z]/', $newPassword);
        $hasUppercase = preg_match('/[A-Z]/', $newPassword);
        $onlyEnglish = preg_match('/^[a-zA-Z0-9_!@#$%^&*()+\-=\[\]{};\':"\\\\|,.<>\/?]+$/', $newPassword);

        if (strlen($newPassword) < 8 || !$hasLowercase || !$hasUppercase || !$onlyEnglish) {
            $error = "Новый пароль должен содержать не менее 8 символов, включая заглавные (A-Z) и строчные (a-z) латинские буквы.";
        } elseif ($newPassword !== $confirmPassword) {
            $error = "Новые пароли не совпадают.";
        } elseif (empty($currentPassword) || !password_verify($currentPassword, $user['password'])) {
            $error = "Для изменения пароля необходимо ввести верный текущий пароль.";
        } else {
            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        }
    }

    // 3. Сохранение данных при отсутствии ошибок
    if (!isset($error)) {
        if ($passwordHash !== null) {
            $stmt = $pdo->prepare("
                UPDATE users
                SET avatar_type = ?, gender = ?, email = ?, password = ?
                WHERE username = ?
            ");
            $stmt->execute([$avatar, $gender, $email, $passwordHash, $currentUser]);
        } else {
            $stmt = $pdo->prepare("
                UPDATE users
                SET avatar_type = ?, gender = ?, email = ?
                WHERE username = ?
            ");
            $stmt->execute([$avatar, $gender, $email, $currentUser]);
        }

        header("Location: settings.php?saved=1");
        exit;
    }
}

$myGender = [
    'male' => 'Мужской',
    'female' => 'Женский'
][$currentGender] ?? 'Не указан';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Настройки</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{
    --bg:#f4f7fb;
    --card:#ffffff;
    --border:#e7edf5;
    --primary:#2AABEE;
    --text:#1f2937;
    --muted:#6b7280;
}
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
}
body{
    background:var(--bg);
    color:var(--text);
    overflow-x:hidden;
}
.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:300px;
    height:100%;
    background:#ffffff;
    box-shadow:4px 0 24px rgba(0,0,0,.15);
    transform:translateX(-100%);
    transition: transform .25s cubic-bezier(0.4, 0, 0.2, 1);
    z-index:1000;
    display: flex;
    flex-direction: column;
}
.sidebar.active{
    transform:translateX(0);
}
.overlay{
    position:fixed;
    inset:0;
    background:rgba(15, 23, 42, 0.45);
    opacity:0;
    visibility:hidden;
    transition:.25s ease-in-out;
    z-index:950;
    backdrop-filter: blur(2px);
}
.overlay.active{
    opacity:1;
    visibility:visible;
}
.sidebar-profile {
    background: linear-gradient(135deg, #2AABEE, #229ED9);
    padding: 24px 20px 18px 20px;
    color: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
}
.sidebar-close-btn {
    position: absolute;
    top: 16px;
    right: 16px;
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.85);
    font-size: 16px;
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: background 0.15s, color 0.15s;
}
.sidebar-close-btn:hover {
    background: rgba(255,255,255,0.15);
    color: #ffffff;
}
.sidebar-avatar{
    width:64px;
    height:64px;
    min-width:64px;
    min-height:64px;
    border-radius:50%;
    overflow:hidden;
    position:relative;
    background:#ffffff;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
    border: 2px solid rgba(255, 255, 255, 0.25);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.sidebar-avatar > * {
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}
.sidebar-avatar img,
.sidebar-avatar svg {
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    object-position:center !important;
    display:block !important;
    border-radius:50% !important;
}
.sidebar-user-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}
.sidebar-user{
    font-size: 16px;
    font-weight:700;
    color: #ffffff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.sidebar-role{
    font-size:13px;
    color: rgba(255, 255, 255, 0.85);
}
.sidebar-menu{
    list-style:none;
    padding: 8px 0;
    overflow-y:auto;
    scrollbar-width:none;
    flex: 1;
}
.sidebar-menu::-webkit-scrollbar{
    display:none;
}
.sidebar-menu li {
    margin: 2px 8px;
}
.sidebar-menu a{
    display:flex;
    align-items:center;
    gap:20px;
    padding:12px 16px;
    text-decoration:none;
    color: #212121;
    font-weight:500;
    font-size: 14px;
    border-radius: 8px;
    transition: background 0.15s ease-in-out, color 0.15s;
}
.sidebar-menu a:hover{
    background: #f4f4f5;
}
.sidebar-menu a.active {
    background: #f0f7fc;
    color: #2AABEE;
    font-weight: 600;
}
.sidebar-menu a i {
    font-size: 18px;
    color: #707579;
    width: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: color 0.15s;
}
.sidebar-menu a:hover i {
    color: #2AABEE;
}
.sidebar-menu a.active i {
    color: #2AABEE;
}
.container{
    max-width:920px;
    margin:0 auto;
    padding:0;
    background:#ffffff;
    min-height:100vh;
}
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:16px;
    margin-bottom:0;
    background: white;
    border-bottom: 1px solid var(--border);
    padding: 14px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
}
.header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}
.menu-btn-inline {
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #2AABEE;
    font-size: 20px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}
.menu-btn-inline:hover {
    background: #f1f5f9;
}
.title{
    font-size:22px;
    font-weight:800;
    display: flex;
    align-items: center;
    gap: 8px;
}
.saved{
    background:#dcfce7;
    color:#166534;
    padding:12px 16px;
    border-radius:12px;
    margin: 16px;
    text-align:center;
    font-weight:700;
    border:1px solid #bbf7d0;
    font-size: 14px;
}
.error-msg{
    background:#fef2f2;
    color:#b91c1c;
    padding:12px 16px;
    border-radius:12px;
    margin: 16px;
    text-align:center;
    font-weight:700;
    border:1px solid #fee2e2;
    font-size: 14px;
}
.settings-content-wrapper {
    padding: 16px;
}
.card{
    background:#ffffff;
    border-radius:16px;
    padding:20px;
    border:1px solid var(--border);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
}
.preview{
    display:flex;
    flex-direction:column;
    align-items:center;
    margin-bottom:24px;
    text-align: center;
}
.preview-avatar{
    width:96px;
    height:96px;
    border-radius:50%;
    overflow:hidden;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#f3f4f6;
    margin-bottom:12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.preview-avatar > *{
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}
.preview-avatar svg,
.preview-avatar img{
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    display:block !important;
    border-radius:50% !important;
}
.preview-name{
    font-size:18px;
    font-weight:700;
    color: var(--text);
}
.preview-gender{
    font-size:13px;
    color: var(--muted);
    margin-top:4px;
}
.tabs-container {
    margin-bottom: 20px;
}
.tabs {
    display: flex;
    background: #f1f5f9;
    padding: 4px;
    border-radius: 12px;
    gap: 4px;
}
.tab-btn {
    flex: 1;
    text-align: center;
    padding: 10px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    border: none;
    background: transparent;
    color: var(--muted);
    cursor: pointer;
    transition: 0.15s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}
.tab-btn.active {
    background: white;
    color: var(--primary);
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
.tab-content {
    display: none;
    animation: fadeIn 0.25s ease-in-out;
}
.tab-content.active {
    display: block;
}
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(4px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.avatar-scroll-container {
    display: flex;
    overflow-x: auto;
    gap: 12px;
    padding: 8px 4px;
    scroll-behavior: smooth;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
}
.avatar-scroll-container::-webkit-scrollbar {
    display: none;
}
.avatar-option{
    flex: 0 0 72px;
    width: 72px;
    height: 72px;
    border-radius: 50%;
    overflow: hidden;
    position: relative;
    background: #f3f4f6;
    border: 3px solid transparent;
    cursor: pointer;
    transition: all 0.15s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
}
.avatar-option.selected{
    border-color: var(--primary);
    transform:scale(1.05);
    box-shadow: 0 0 0 2px rgba(42,171,238,0.2);
}
.avatar-option > *{
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}
.avatar-option svg,
.avatar-option img{
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    display:block !important;
    border-radius:50% !important;
}
.gender-row{
    display:flex;
    gap:12px;
}
.gender-card{
    flex:1;
    padding:16px;
    border-radius:12px;
    border:2px solid transparent;
    background:#f1f5f9;
    cursor:pointer;
    text-align:center;
    transition: all 0.15s ease-in-out;
    color: var(--text);
    font-size: 14px;
    font-weight: 600;
}
.gender-card.selected{
    border-color: var(--primary);
    background:#eef7ff;
    color: var(--primary);
}
.gender-card i{
    font-size:24px;
    margin-bottom:8px;
    display: block;
}
.settings-input {
    width: 100%;
    padding: 14px;
    border: 1px solid var(--border);
    border-radius: 12px;
    font-size: 15px;
    outline: none;
    background: #f8fafc;
    color: var(--text);
    transition: all 0.15s ease-in-out;
}
.settings-input:focus {
    border-color: var(--primary);
    background: #ffffff;
    box-shadow: 0 0 0 4px rgba(42, 171, 238, 0.12);
}
.save-btn{
    width:100%;
    border:none;
    background: var(--primary);
    color:#ffffff;
    padding:14px;
    border-radius:12px;
    font-size:15px;
    font-weight:700;
    cursor:pointer;
    margin-top:24px;
    transition: background 0.15s ease-in-out, transform 0.1s ease-in-out;
}
.save-btn:hover{
    background: #2496d1;
}
.save-btn:active {
    transform: scale(0.98);
}
@media(max-width:480px){
    .sidebar{
        width: 280px;
    }
    .title{
        font-size:18px;
    }
    .header {
        padding: 12px 12px;
    }
}
</style>
</head>

<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="container">

    <div class="header">
        <div class="header-left">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="title">Настройки</h1>
        </div>
    </div>

    <?php if(isset($_GET['saved'])): ?>
    <div class="saved">
        Настройки сохранены
    </div>
    <?php endif; ?>

    <?php if(isset($error)): ?>
    <div class="error-msg">
        <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <div class="settings-content-wrapper">
        <form method="POST">
            <!-- Защита CSRF -->
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div class="card">
                <div class="preview">
                    <div class="preview-avatar" id="previewAvatar">
                        <?= renderAvatar($currentAvatar, $currentUser) ?>
                    </div>
                    <div class="preview-name">
                        <?= htmlspecialchars($currentUser) ?>
                    </div>
                    <div style="font-size:13px; color: var(--muted); margin-top:4px;">
                        Email: <?= htmlspecialchars($currentEmail) ?>
                    </div>
                    <div class="preview-gender" id="previewGender" style="margin-top:2px;">
                        Пол: <?= htmlspecialchars($myGender) ?>
                    </div>
                </div>

                <div class="tabs-container">
                    <div class="tabs">
                        <button type="button" id="tabBtnAvatar" class="tab-btn active" onclick="switchTab('avatar')">🖼️ Аватар</button>
                        <button type="button" id="tabBtnGender" class="tab-btn" onclick="switchTab('gender')">⚧ Пол</button>
                        <button type="button" id="tabBtnSecurity" class="tab-btn" onclick="switchTab('security')">🔒 Данные</button>
                    </div>
                </div>

                <!-- ВКЛАДКА: АВАТАР -->
                <div class="tab-content active" id="tabContentAvatar">
                    <div class="avatar-scroll-container">
                        <?php foreach($avatars as $i => $av): ?>
                        <div class="avatar-option <?= $i == $currentAvatar ? 'selected' : '' ?>" onclick="selectAvatar(<?= $i ?>)">
                            <?= renderAvatar($i, $currentUser) ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- ВКЛАДКА: ПОЛ -->
                <div class="tab-content" id="tabContentGender">
                    <div class="gender-row">
                        <div class="gender-card <?= $currentGender === 'male' ? 'selected' : '' ?>" onclick="selectGender('male')" id="maleCard">
                            <i class="fas fa-mars"></i>
                            <div>Мужской</div>
                        </div>

                        <div class="gender-card <?= $currentGender === 'female' ? 'selected' : '' ?>" onclick="selectGender('female')" id="femaleCard">
                            <i class="fas fa-venus"></i>
                            <div>Женский</div>
                        </div>
                    </div>
                </div>

                <!-- ВКЛАДКА: БЕЗОПАСНОСТЬ И ДАННЫЕ -->
                <div class="tab-content" id="tabContentSecurity">
                    <div style="margin-bottom: 16px; text-align: left;">
                        <label style="font-weight: 700; font-size: 13px; display: block; margin-bottom: 6px; color: var(--muted);">ЭЛЕКТРОННАЯ ПОЧТА (EMAIL)</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($currentEmail) ?>" class="settings-input" required autocomplete="email">
                    </div>

                    <div style="margin-bottom: 16px; text-align: left;">
                        <label style="font-weight: 700; font-size: 13px; display: block; margin-bottom: 6px; color: var(--muted);">НОВЫЙ ПАРОЛЬ (оставьте пустым, если не хотите менять)</label>
                        <input type="password" name="new_password" id="regPassword" class="settings-input" autocomplete="new-password">
                        <div id="passwordFeedback" style="font-size: 11px; margin-top: 5px; display: none; font-weight: 600;"></div>
                    </div>

                    <div style="margin-bottom: 16px; text-align: left;">
                        <label style="font-weight: 700; font-size: 13px; display: block; margin-bottom: 6px; color: var(--muted);">ПОДТВЕРЖДЕНИЕ НОВОГО ПАРОЛЯ</label>
                        <input type="password" name="confirm_password" class="settings-input" autocomplete="new-password">
                    </div>

                    <div style="margin-bottom: 16px; text-align: left; padding: 14px; background: #fffbeb; border: 1px solid #fef3c7; border-radius: 12px;">
                        <label style="font-weight: 700; font-size: 13px; display: block; margin-bottom: 6px; color: #b45309;">ТЕКУЩИЙ ПАРОЛЬ</label>
                        <p style="font-size: 11px; color: #b45309; margin-bottom: 8px;">Необходимо ввести ваш текущий пароль для подтверждения изменения почты или пароля.</p>
                        <input type="password" name="current_password" class="settings-input" style="background:#ffffff; border-color:#cbd5e1;" autocomplete="current-password">
                    </div>
                </div>

                <input type="hidden" name="avatar" id="avatarInput" value="<?= $currentAvatar ?>">
                <input type="hidden" name="gender" id="genderInput" value="<?= htmlspecialchars($currentGender) ?>">

                <button class="save-btn">Сохранить настройки</button>
            </div>
        </form>
    </div>

</div>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

document.getElementById('menuBtn').onclick = () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
};

document.getElementById('closeBtn').onclick = closeSidebar;
overlay.onclick = closeSidebar;

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
}

function switchTab(tabName) {
    document.getElementById('tabContentAvatar').classList.remove('active');
    document.getElementById('tabContentGender').classList.remove('active');
    document.getElementById('tabContentSecurity').classList.remove('active');
    document.getElementById('tabBtnAvatar').classList.remove('active');
    document.getElementById('tabBtnGender').classList.remove('active');
    document.getElementById('tabBtnSecurity').classList.remove('active');

    if (tabName === 'avatar') {
        document.getElementById('tabContentAvatar').classList.add('active');
        document.getElementById('tabBtnAvatar').classList.add('active');
    } else if (tabName === 'gender') {
        document.getElementById('tabContentGender').classList.add('active');
        document.getElementById('tabBtnGender').classList.add('active');
    } else if (tabName === 'security') {
        document.getElementById('tabContentSecurity').classList.add('active');
        document.getElementById('tabBtnSecurity').classList.add('active');
    }
}

function selectAvatar(idx){
    document.getElementById('avatarInput').value = idx;
    document.querySelectorAll('.avatar-option').forEach((el,i)=>{
        el.classList.toggle('selected', i === idx);
    });

    const selected = document.querySelectorAll('.avatar-option')[idx].innerHTML;
    document.getElementById('previewAvatar').innerHTML = selected;
}

function selectGender(gender){
    document.getElementById('genderInput').value = gender;
    document.getElementById('maleCard').classList.toggle('selected', gender === 'male');
    document.getElementById('femaleCard').classList.toggle('selected', gender === 'female');
    document.getElementById('previewGender').innerHTML = 'Пол: ' + (gender === 'male' ? 'Мужской' : 'Женский');
}

// === ИНТЕРАКТИВНАЯ КЛИЕНТСКАЯ ВАЛИДАЦИЯ НОВОГО ПАРОЛЯ ===
const regPassword = document.getElementById('regPassword');
const passwordFeedback = document.getElementById('passwordFeedback');

if (regPassword) {
    regPassword.addEventListener('input', () => {
        const value = regPassword.value;
        if (value === "") {
            passwordFeedback.style.display = "none";
            return;
        }
        const hasLowercase = /[a-z]/.test(value);
        const hasUppercase = /[A-Z]/.test(value);
        const onlyEnglish = /^[a-zA-Z0-9_!@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?]+$/.test(value);

        if (value.length < 8) {
            showFeedback(passwordFeedback, "Пароль должен содержать не менее 8 символов.", "error");
        } else if (!hasLowercase || !hasUppercase) {
            showFeedback(passwordFeedback, "Пароль должен содержать как строчные (a-z), так и заглавные (A-Z) английские буквы.", "error");
        } else if (!onlyEnglish) {
            showFeedback(passwordFeedback, "Пароль должен состоять исключительно из английских букв, цифр и спецсимволов.", "error");
        } else {
            showFeedback(passwordFeedback, "✓ Пароль соответствует требованиям безопасности", "success");
        }
    });
}

function showFeedback(element, text, status) {
    element.textContent = text;
    element.style.display = "block";
    if (status === "error") {
        element.style.color = "#ef4444";
    } else if (status === "success") {
        element.style.color = "#22c55e";
    }
}

// Автоматически переключаем вкладку при наличии ошибок отправки формы
switchTab('<?= $activeTab ?>');
</script>

</body>
</html>