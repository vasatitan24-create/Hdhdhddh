<?php
require_once 'db.php';

// Проверка: разрешена ли регистрация в настройках админки
try {
    $regCheck = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'registration_enabled' LIMIT 1")->fetchColumn();
} catch (PDOException $e) {
    $regCheck = '1';
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Если регистрация временно отключена в админке
    if ($regCheck === '0') {
        header("Location: index.php?tab=register&error=" . urlencode("Регистрация новых аккаунтов временно приостановлена."));
        exit();
    }

    // Валидация CSRF-токена безопасности
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        header("Location: index.php?tab=register&error=" . urlencode("Ошибка безопасности: неверный CSRF-токен."));
        exit();
    }

    // Проверка капчи регистрации
    $user_captcha = strtolower(trim($_POST['captcha'] ?? ''));
    $session_captcha = $_SESSION['captcha_code_register'] ?? '';

    // Сразу очищаем капчу в сессии во избежание повторного использования
    unset($_SESSION['captcha_code_register']);

    if ($user_captcha === '' || $user_captcha !== $session_captcha) {
        header("Location: index.php?tab=register&error=" . urlencode("Неверно введен проверочный код капчи."));
        exit();
    }

    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // 1. Проверка на заполненность обязательных полей
    if (empty($username) || empty($email) || empty($password)) {
        header("Location: index.php?tab=register&error=" . urlencode("Пожалуйста, заполните все обязательные поля."));
        exit();
    }

    // 2. Строгая проверка имени пользователя (только латиница и цифры, длина от 3 до 20)
    if (!preg_match('/^[a-zA-Z0-9]{3,20}$/', $username)) {
        header("Location: index.php?tab=register&error=" . urlencode("Логин должен состоять только из английских букв и цифр (от 3 до 20 символов)."));
        exit();
    }

    // 3. Строгая проверка корректности Email на стороне сервера
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: index.php?tab=register&error=" . urlencode("Указан некорректный адрес электронной почты."));
        exit();
    }

    // 4. Строгая проверка сложности пароля на сервере (длина >= 8, строчные и заглавные английские буквы, без кириллицы)
    $hasLowercase = preg_match('/[a-z]/', $password);
    $hasUppercase = preg_match('/[A-Z]/', $password);
    $onlyEnglish = preg_match('/^[a-zA-Z0-9_!@#$%^&*()+\-=\[\]{};\':"\\\\|,.<>\/?]+$/', $password);

    if (strlen($password) < 8 || !$hasLowercase || !$hasUppercase || !$onlyEnglish) {
        header("Location: index.php?tab=register&error=" . urlencode("Пароль должен содержать минимум 8 символов, включая заглавные (A-Z) и строчные (a-z) английские буквы."));
        exit();
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Проверка существования пользователя по email или логину
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1");
        $stmt->execute([$email, $username]);

        if ($stmt->fetch()) {
            header("Location: index.php?tab=register&error=" . urlencode("Пользователь с таким email или логином уже зарегистрирован."));
            exit();
        }

        // Вставка нового пользователя
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')");
        if ($stmt->execute([$username, $email, $passwordHash])) {
            $_SESSION['username'] = $username;
            header("Location: index.php?success=" . urlencode("Аккаунт успешно создан! Теперь вы можете войти."));
            exit();
        } else {
            header("Location: index.php?tab=register&error=" . urlencode("Произошла ошибка при сохранении данных в БД."));
            exit();
        }
    } catch (PDOException $e) {
        header("Location: index.php?tab=register&error=" . urlencode("Ошибка сервера во время регистрации."));
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}