<?php
// Подключаем конфигурацию базы данных и сессий с правильным путем /sessions
require_once 'db.php';

// Очищаем массив сессионных переменных
$_SESSION = [];

// Стираем сессионную куку в браузере (WebView) пользователя
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Физически уничтожаем файл сессии в папке /sessions
session_destroy();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Выход из аккаунта</title>
    <style>
        body {
            background: #f4f7fb;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #6b7280;
        }
        .loader-box {
            text-align: center;
        }
        .loader-text {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class="loader-box">
        <div class="loader-text">Выход из аккаунта...</div>
    </div>
    
    <script>
        function runOneSignalLogoutAndRedirect() {
            var bridge = window.Median || window.median || window.gonative;
            if (bridge) {
                try {
                    // Новая модель (User-Centric SDK v5+)
                    if (bridge.onesignal && typeof bridge.onesignal.logout === 'function') {
                        bridge.onesignal.logout();
                    } else if (window.Median && window.Median.onesignal && typeof window.Median.onesignal.logout === 'function') {
                        window.Median.onesignal.logout();
                    }
                    
                    // Устаревшая модель (Legacy / External User ID)
                    if (bridge.onesignal && bridge.onesignal.externalUserId && typeof bridge.onesignal.externalUserId.remove === 'function') {
                        bridge.onesignal.externalUserId.remove();
                    }
                } catch (e) {
                    console.error("[OneSignal Logout Error]", e);
                }
            }
            
            // Мгновенный переход на главную
            window.location.href = "index.php";
        }

        // Пробуем выполнить сброс сразу
        runOneSignalLogoutAndRedirect();

        // Страховочный таймаут для гарантированного перехода
        setTimeout(function() {
            window.location.href = "index.php";
        }, 400);
    </script>
</body>
</html>