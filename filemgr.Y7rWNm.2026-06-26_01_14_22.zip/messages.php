<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit();
}

$currentUser = $_SESSION['username'];

// Гарантированная миграция структуры БД при входе в чаты
try {
    $pdo->exec("ALTER TABLE users ADD COLUMN public_key TEXT DEFAULT NULL");
} catch (PDOException $e) {
    // Игнорируем ошибку, если колонка уже существует
}

// === ФОНОВАЯ РЕГИСТРАЦИЯ ПУБЛИЧНОГО КЛЮЧА ИЗ СПИСКА ЧАТОВ (API) ===
if (isset($_GET['save_public_key']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $pubKey = isset($_POST['public_key']) ? trim($_POST['public_key']) : '';
    if ($pubKey === '') {
        echo json_encode(['status' => 'error', 'message' => 'Пустой ключ']);
        exit();
    }
    try {
        $upd = $pdo->prepare("UPDATE users SET public_key = :pk WHERE username = :u");
        $upd->execute(['pk' => $pubKey, 'u' => $currentUser]);
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit();
}

// Получаем тип аватара и роль текущего пользователя для бокового меню
$currentUserAvatarType = 0;
$currentUserRole = 'user';

try {
    $userStmt = $pdo->prepare("SELECT avatar_type, role FROM users WHERE username = :u");
    $userStmt->execute(['u' => $currentUser]);
    $userRow = $userStmt->fetch(PDO::FETCH_ASSOC);
    if ($userRow) {
        $currentUserAvatarType = (int)($userRow['avatar_type'] ?? 0);
        $currentUserRole = $userRow['role'] ?? 'user';
    }
} catch (PDOException $e) {
    // Безопасный откат
    $userStmt = $pdo->prepare("SELECT avatar_type FROM users WHERE username = :u");
    $userStmt->execute(['u' => $currentUser]);
    $userRow = $userStmt->fetch(PDO::FETCH_ASSOC);
    if ($userRow) {
        $currentUserAvatarType = (int)($userRow['avatar_type'] ?? 0);
    }
}

/*
|--------------------------------------------------------------------------
| AJAX GET DIALOGS (REAL-TIME UPDATE WITH REORDERING)
|--------------------------------------------------------------------------
*/

if (isset($_GET['ajax_get_dialogs'])) {

    header('Content-Type: application/json; charset=utf-8');

    $query = "
    SELECT
        pm.*,
        u.avatar_type AS contact_avatar_type,
        u.last_seen AS contact_last_seen,
        CASE
            WHEN pm.sender = :u THEN pm.receiver
            ELSE pm.sender
        END AS contact_name
    FROM private_messages pm
    INNER JOIN (
        SELECT
            CASE
                WHEN sender = :u THEN receiver
                ELSE sender
            END AS contact_name,
            MAX(id) AS max_id
        FROM private_messages
        WHERE
        (
            (receiver = :u AND hidden_by_receiver = 0)
            OR
            (sender = :u AND hidden_by_sender = 0)
        )
        GROUP BY 1
    ) t ON pm.id = t.max_id
    LEFT JOIN users u ON u.username =
    (
        CASE
            WHEN pm.sender = :u THEN pm.receiver
            ELSE pm.sender
        END
    )
    ORDER BY pm.created_at DESC
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute(['u' => $currentUser]);
    $ajaxDialogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $unreadStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM private_messages
        WHERE receiver = :u
          AND is_read = 0
          AND hidden_by_receiver = 0
    ");
    $unreadStmt->execute(['u' => $currentUser]);
    $totalUnread = (int)$unreadStmt->fetchColumn();

    ob_start();
    if (empty($ajaxDialogs)): ?>
        <div class="empty">У вас пока нет сообщений</div>
    <?php else: ?>
        <div class="dialog-list">
            <?php foreach ($ajaxDialogs as $chat): 
                $contact = $chat['contact_name'];
                $isOnline = false;

                if (!empty($chat['contact_last_seen'])) {
                    $lastSeenTime = strtotime($chat['contact_last_seen']);
                    if ((time() - $lastSeenTime) < 300) {
                        $isOnline = true;
                    }
                }

                $unreadStmt2 = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM private_messages
                    WHERE receiver = :u
                      AND sender = :contact
                      AND is_read = 0
                      AND hidden_by_receiver = 0
                ");
                $unreadStmt2->execute([
                    'u' => $currentUser,
                    'contact' => $contact
                ]);
                $unreadCount = (int)$unreadStmt2->fetchColumn();
            ?>
                <div class="chat-card" data-contact="<?= htmlspecialchars($contact) ?>">
                    <a href="dialog.php?user=<?= urlencode($contact) ?>" class="chat-link">
                        <div class="avatar-wrap">
                            <?= renderAvatar($chat['contact_avatar_type'] ?? 0, $contact) ?>
                        </div>
                        <div class="content">
                            <div class="row-top">
                                <span class="username" style="display: flex; align-items: center; gap: 6px;">
                                    <?= htmlspecialchars($contact) ?>
                                    <?php if ($isOnline): ?>
                                        <span class="online-dot-inline" title="В сети"></span>
                                    <?php endif; ?>
                                </span>
                                <span class="time">
                                    <?= date('H:i', strtotime($chat['created_at'])) ?>
                                </span>
                            </div>
                            <div class="subtitle">Нажмите, чтобы открыть диалог</div>
                        </div>
                        <?php if ($unreadCount > 0): ?>
                            <div class="unread-badge"><?= $unreadCount ?></div>
                        <?php endif; ?>
                    </a>
                    <form method="post" style="margin:0;" onsubmit="event.preventDefault(); showConfirmModal('Удалить диалог?', 'Вы действительно хотите удалить этот диалог у себя?', this);">
                        <input type="hidden" name="hide_dialog" value="1">
                        <input type="hidden" name="contact" value="<?= htmlspecialchars($contact) ?>">
                        <button type="submit" class="hide-btn" title="Удалить диалог">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif;

    $html = ob_get_clean();

    echo json_encode([
        'total' => $totalUnread,
        'html' => $html
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

/*
|--------------------------------------------------------------------------
| DELETE ALL
|--------------------------------------------------------------------------
*/

if (isset($_POST['delete_all'])) {

    $pdo->beginTransaction();

    try {

        $stmt1 = $pdo->prepare("
            UPDATE private_messages
            SET hidden_by_sender = 1
            WHERE sender = :u
        ");

        $stmt1->execute([
            'u' => $currentUser
        ]);

        $stmt2 = $pdo->prepare("
            UPDATE private_messages
            SET hidden_by_receiver = 1
            WHERE receiver = :u
        ");

        $stmt2->execute([
            'u' => $currentUser
        ]);

        $pdo->commit();

    } catch(Throwable $e){

        $pdo->rollBack();
        throw $e;
    }

    header("Location: messages.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| DELETE DIALOG
|--------------------------------------------------------------------------
*/

if (
    isset($_POST['hide_dialog']) &&
    !empty($_POST['contact'])
){

    $contact = trim($_POST['contact']);

    $pdo->beginTransaction();

    try{

        $stmtOut = $pdo->prepare("
            UPDATE private_messages
            SET hidden_by_sender = 1
            WHERE sender = :me
              AND receiver = :contact
        ");

        $stmtOut->execute([
            'me' => $currentUser,
            'contact' => $contact
        ]);

        $stmtIn = $pdo->prepare("
            UPDATE private_messages
            SET hidden_by_receiver = 1
            WHERE sender = :contact
              AND receiver = :me
        ");

        $stmtIn->execute([
            'me' => $currentUser,
            'contact' => $contact
        ]);

        $pdo->commit();

    }catch(Throwable $e){

        $pdo->rollBack();
        throw $e;
    }

    header("Location: messages.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| INITIAL DIALOGS LOAD
|--------------------------------------------------------------------------
*/

$query = "
SELECT
    pm.*,
    u.avatar_type AS contact_avatar_type,
    u.last_seen AS contact_last_seen,
    CASE
        WHEN pm.sender = :u THEN pm.receiver
        ELSE pm.sender
    END AS contact_name
FROM private_messages pm
INNER JOIN (
    SELECT
        CASE
            WHEN sender = :u THEN receiver
            ELSE sender
        END AS contact_name,
        MAX(id) AS max_id
    FROM private_messages
    WHERE
    (
        (receiver = :u AND hidden_by_receiver = 0)
        OR
        (sender = :u AND hidden_by_sender = 0)
    )
    GROUP BY 1
) t ON pm.id = t.max_id
LEFT JOIN users u ON u.username =
(
    CASE
        WHEN pm.sender = :u THEN pm.receiver
        ELSE pm.sender
    END
)
ORDER BY pm.created_at DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute([
    'u' => $currentUser
]);
$dialogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$unreadStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM private_messages
    WHERE receiver = :u
      AND is_read = 0
      AND hidden_by_receiver = 0
");
$unreadStmt->execute([
    'u' => $currentUser
]);
$totalUnread = (int)$unreadStmt->fetchColumn();

?>

<!DOCTYPE html>
<html lang="ru">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
>

<title>Сообщения</title>

<link
rel="preconnect"
href="https://fonts.googleapis.com"
>

<link
rel="preconnect"
href="https://fonts.gstatic.com"
crossorigin
>

<link
href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
rel="stylesheet"
>

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
>

<style>

:root{
    --bg:#f4f7fb;
    --card:#ffffff;
    --border:#e7edf5;
    --primary:#2AABEE;
    --text:#1f2937;
    --muted:#6b7280;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
}

body{
    background:var(--bg);
    color:var(--text);
    overflow-x:hidden;
}

/* SIDEBAR (TELEGRAM STYLE) */

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:300px;
    height:100%;
    background:#ffffff;
    box-shadow:4px 0 24px rgba(0,0,0,.15);
    transform:translateX(-100%);
    transition: transform .25s cubic-bezier(0.4, 0, 0.2, 1);
    z-index:1000;
    display: flex;
    flex-direction: column;
}

.sidebar.active{
    transform:translateX(0);
}

.overlay{
    position:fixed;
    inset:0;
    background:rgba(15, 23, 42, 0.45);
    opacity:0;
    visibility:hidden;
    transition:.25s ease-in-out;
    z-index:950;
    backdrop-filter: blur(2px);
}

.overlay.active{
    opacity:1;
    visibility:visible;
}

.sidebar-profile {
    background: linear-gradient(135deg, #2AABEE, #229ED9);
    padding: 24px 20px 18px 20px;
    color: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
}

.sidebar-close-btn {
    position: absolute;
    top: 16px;
    right: 16px;
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.85);
    font-size: 16px;
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: background 0.15s, color 0.15s;
}

.sidebar-close-btn:hover {
    background: rgba(255,255,255,0.15);
    color: #ffffff;
}

.sidebar-avatar{
    width:64px;
    height:64px;
    min-width:64px;
    min-height:64px;
    border-radius:50%;
    overflow:hidden;
    position:relative;
    background:#ffffff;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
    border: 2px solid rgba(255, 255, 255, 0.25);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.sidebar-avatar > *:not(.online-status){
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}

.sidebar-avatar img,
.sidebar-avatar svg{
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    object-position:center !important;
    display:block !important;
    border-radius:50% !important;
}

.sidebar-user-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.sidebar-user{
    font-size: 16px;
    font-weight:700;
    color: #ffffff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-role{
    font-size:13px;
    color: rgba(255, 255, 255, 0.85);
}

.sidebar-menu{
    list-style:none;
    padding: 8px 0;
    overflow-y:auto;
    scrollbar-width:none;
    flex: 1;
}

.sidebar-menu::-webkit-scrollbar{
    display:none;
}

.sidebar-menu li {
    margin: 2px 8px;
}

.sidebar-menu a{
    display:flex;
    align-items:center;
    gap:20px;
    padding:12px 16px;
    text-decoration:none;
    color:#212121;
    font-weight:500;
    font-size: 14px;
    border-radius: 8px;
    transition: background 0.15s ease-in-out, color 0.15s;
}

.sidebar-menu a:hover{
    background:#f4f4f5;
}

.sidebar-menu a.active {
    background: #f0f7fc;
    color: #2AABEE;
    font-weight: 600;
}

.sidebar-menu a i {
    font-size: 18px;
    color: #707579;
    width: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: color 0.15s;
}

.sidebar-menu a:hover i {
    color: #2AABEE;
}

.sidebar-menu a.active i {
    color: #2AABEE;
}

.container{
    max-width:920px;
    margin:0 auto;
    padding:0;
    background: #ffffff;
    min-height: 100vh;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:16px;
    margin-bottom:0;
    background: white;
    border: none;
    border-bottom: 1px solid var(--border);
    border-radius: 0;
    padding: 14px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.menu-btn-inline {
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #2AABEE;
    font-size: 20px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}

.menu-btn-inline:hover {
    background: #f1f5f9;
}

.title{
    font-size:22px;
    font-weight:800;
    display: flex;
    align-items: center;
    gap: 8px;
}

.title span{
    color:#2AABEE;
}

.clear-btn{
    border:none;
    background:#ef4444;
    color:white;
    padding:10px 16px;
    border-radius:12px;
    font-weight:700;
    font-size: 13px;
    cursor:pointer;
    transition: background 0.15s ease-in-out;
}

.clear-btn:hover {
    background: #dc2626;
}

.dialog-list {
    background: white;
    border: none;
    border-radius: 0;
}

.chat-card{
    background: white;
    border: none;
    border-bottom: 1px solid #edf1f5;
    padding: 12px 16px;
    margin-bottom: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    transition: background 0.1s ease-in-out;
}

.chat-card:last-child {
    border-bottom: none;
}

.chat-card:hover {
    background: #f8fafc;
}

.chat-link{
    display:flex;
    align-items:center;
    gap:14px;
    flex:1;
    text-decoration:none;
    color:inherit;
    min-width:0;
}

.avatar-wrap{
    width:52px;
    height:52px;
    min-width:52px;
    min-height:52px;
    border-radius:50%;
    overflow:hidden;
    background:#f3f4f6;
    position:relative;
    flex-shrink:0;
    display:flex;
    align-items:center;
    justify-content:center;
}

.avatar-wrap > *{
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}

.avatar-wrap img,
.avatar-wrap svg{
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    object-position:center !important;
    display:block !important;
    border-radius:50% !important;
}

.online-dot-inline {
    display: inline-block;
    width: 8px;
    height: 8px;
    background-color: #22c55e;
    border-radius: 50%;
    flex-shrink: 0;
    box-shadow: 0 0 5px rgba(34, 197, 94, 0.6);
}

.content{
    flex:1;
    min-width:0;
}

.row-top{
    display:flex;
    justify-content:space-between;
    align-items: center;
    gap:10px;
}

.username{
    font-weight:700;
    font-size:15px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.time{
    font-size:12px;
    color:#8a8f95;
}

.subtitle{
    font-size:13px;
    color:#8a8f95;
    margin-top:4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.unread-badge{
    min-width:20px;
    height:20px;
    padding:0 6px;
    border-radius:999px;
    background:#2AABEE;
    color:white;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    font-size:11px;
    font-weight:700;
    margin-left:8px;
}

.hide-btn{
    border:none;
    background:transparent;
    color:#a0aec0;
    padding:8px;
    border-radius:50%;
    font-size:14px;
    cursor:pointer;
    transition:all 0.15s ease-in-out;
    display:flex;
    align-items:center;
    justify-content:center;
    width:32px;
    height:32px;
    flex-shrink:0;
}

.hide-btn:hover{
    background:#fee2e2;
    color:#ef4444;
}

.empty{
    text-align:center;
    padding:80px 20px;
    color:#777;
    background: white;
    border: none;
}

.custom-modal {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s ease-in-out;
    z-index: 2000;
    backdrop-filter: blur(4px);
}

.custom-modal.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    border-radius: 20px;
    padding: 24px;
    width: 90%;
    max-width: 360px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    transform: scale(0.95);
    transition: all 0.2s ease-in-out;
    text-align: center;
}

.custom-modal.active .modal-content {
    transform: scale(1);
}

.modal-title {
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 8px;
    color: var(--text);
}

.modal-text {
    font-size: 14px;
    color: var(--muted);
    margin-bottom: 22px;
    line-height: 1.5;
}

.modal-actions {
    display: flex;
    gap: 12px;
    justify-content: center;
}

.modal-btn {
    flex: 1;
    border: none;
    padding: 11px 16px;
    border-radius: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
    font-size: 14px;
}

.modal-btn.cancel {
    background: #f3f4f6;
    color: var(--text);
}

.modal-btn.cancel:hover {
    background: #e5e7eb;
}

.modal-btn.confirm {
    background: #ef4444;
    color: white;
}

.modal-btn.confirm:hover {
    background: #dc2626;
}

@media(max-width:480px){
    .sidebar{
        width: 280px;
    }
    .title{
        font-size:18px;
    }
    .header {
        padding: 12px 12px;
    }
}

</style>

</head>

<body>

<?php require_once 'templates/sidebar.php'; ?>

<!-- КАСТОМНОЕ ОКНО ПОДТВЕРЖДЕНИЯ -->
<div class="custom-modal" id="confirmModal">
    <div class="modal-content">
        <h3 class="modal-title" id="modalTitle">Удалить?</h3>
        <p class="modal-text" id="modalText">Вы действительно хотите выполнить это действие?</p>
        <div class="modal-actions">
            <button class="modal-btn cancel" id="modalCancelBtn">Отмена</button>
            <button class="modal-btn confirm" id="modalConfirmBtn">Удалить</button>
        </div>
    </div>
</div>

<div class="container">

<div class="header">
    <div class="header-left">
        <button class="menu-btn-inline" id="menuBtn">
            <i class="fa-solid fa-bars"></i>
        </button>
        <h1 class="title">
            Сообщения
            <span id="total-unread-badge">
                <?= $totalUnread > 0 ? $totalUnread : '' ?>
            </span>
        </h1>
    </div>

    <?php if (!empty($dialogs)): ?>
    <form
    method="post"
    style="margin:0;"
    onsubmit="event.preventDefault(); showConfirmModal('Очистить всё?', 'Вы действительно хотите удалить все сообщения только у себя?', this);"
    >
    <input type="hidden" name="delete_all" value="1">
    <button
    type="submit"
    class="clear-btn"
    >
    Очистить всё
    </button>
    </form>
    <?php endif; ?>

</div>

<div id="dialogs-container">
<?php if (empty($dialogs)): ?>
    <div class="empty">
    У вас пока нет сообщений
    </div>
<?php else: ?>
    <div class="dialog-list">
        <?php foreach ($dialogs as $chat): ?>
        <?php
        $contact = $chat['contact_name'];
        $isOnline = false;

        if (!empty($chat['contact_last_seen'])) {
            $lastSeenTime = strtotime($chat['contact_last_seen']);
            if ((time() - $lastSeenTime) < 300) {
                $isOnline = true;
            }
        }

        $unreadStmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM private_messages
            WHERE receiver = :u
              AND sender = :contact
              AND is_read = 0
              AND hidden_by_receiver = 0
        ");
        $unreadStmt->execute([
            'u' => $currentUser,
            'contact' => $contact
        ]);
        $unreadCount = (int)$unreadStmt->fetchColumn();
        ?>

        <div
        class="chat-card"
        data-contact="<?= htmlspecialchars($contact) ?>"
        >
            <a
            href="dialog.php?user=<?= urlencode($contact) ?>"
            class="chat-link"
            >
                <div class="avatar-wrap">
                <?= renderAvatar(
                    $chat['contact_avatar_type'] ?? 0,
                    $contact
                ) ?>
                </div>

                <div class="content">
                    <div class="row-top">
                        <span class="username">
                        <?= htmlspecialchars($contact) ?>
                        <?php if ($isOnline): ?>
                            <span class="online-dot-inline" title="В сети"></span>
                        <?php endif; ?>
                        </span>
                        <span class="time">
                        <?= date('H:i', strtotime($chat['created_at'])) ?>
                        </span>
                    </div>
                    <div class="subtitle">
                    Нажмите, чтобы открыть диалог
                    </div>
                </div>

                <?php if ($unreadCount > 0): ?>
                <div class="unread-badge">
                <?= $unreadCount ?>
                </div>
                <?php endif; ?>
            </a>

            <form
            method="post"
            style="margin:0;"
            onsubmit="event.preventDefault(); showConfirmModal('Удалить диалог?', 'Вы действительно хотите удалить этот диалог у себя?', this);"
            >
                <input type="hidden" name="hide_dialog" value="1">
                <input
                type="hidden"
                name="contact"
                value="<?= htmlspecialchars($contact) ?>"
                >
                <button
                type="submit"
                class="hide-btn"
                title="Удалить диалог"
                >
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
</div>

</div>

<script>
    // === АВТОМАТИЧЕСКАЯ ФОНОВАЯ ГЕНЕРАЦИЯ И СИНХРОНИЗАЦИЯ КЛЮЧЕЙ ПРИ ВХОДЕ В ПРИЛОЖЕНИЕ (E2EE/ECDH) ===
    (async function() {
        const DB_E2EE_NAME = 'E2EE_Keys_DB_System';
        const DB_E2EE_VERSION = 1;
        const STORE_E2EE_NAME = 'key_store';
        const currentUsername = <?= json_encode($currentUser) ?>;

        function getE2EEDB() {
            return new Promise((resolve, reject) => {
                const request = indexedDB.open(DB_E2EE_NAME, DB_E2EE_VERSION);
                request.onupgradeneeded = (e) => {
                    const db = e.target.result;
                    if (!db.objectStoreNames.contains(STORE_E2EE_NAME)) {
                        db.createObjectStore(STORE_E2EE_NAME);
                    }
                };
                request.onsuccess = (e) => resolve(e.target.result);
                request.onerror = (e) => reject(e.target.error);
            });
        }

        // Ключи изолируются по имени текущего пользователя
        function getStoredKeys() {
            return new Promise(async (resolve) => {
                try {
                    const db = await getE2EEDB();
                    const transaction = db.transaction(STORE_E2EE_NAME, 'readonly');
                    const store = transaction.objectStore(STORE_E2EE_NAME);
                    const request = store.get('my_key_pair_' + currentUsername);
                    request.onsuccess = () => resolve(request.result || null);
                    request.onerror = () => resolve(null);
                } catch (e) { resolve(null); }
            });
        }

        // Ключи изолируются по имени текущего пользователя
        function saveStoredKeys(keyPairJWK) {
            return new Promise(async (resolve) => {
                try {
                    const db = await getE2EEDB();
                    const transaction = db.transaction(STORE_E2EE_NAME, 'readwrite');
                    const store = transaction.objectStore(STORE_E2EE_NAME);
                    const request = store.put(keyPairJWK, 'my_key_pair_' + currentUsername);
                    request.onsuccess = () => resolve(true);
                    request.onerror = () => resolve(false);
                } catch (e) { resolve(false); }
            });
        }

        try {
            let keys = await getStoredKeys();
            if (!keys) {
                // Генерируем новую пару ECDH P-256 в фоновом режиме за долю секунды
                const keyPair = await window.crypto.subtle.generateKey(
                    {
                        name: "ECDH",
                        namedCurve: "P-256",
                    },
                    true,
                    ["deriveKey", "deriveBits"]
                );

                const publicKeyJwk = await window.crypto.subtle.exportKey("jwk", keyPair.publicKey);
                const privateKeyJwk = await window.crypto.subtle.exportKey("jwk", keyPair.privateKey);

                keys = {
                    publicKey: publicKeyJwk,
                    privateKey: privateKeyJwk
                };

                await saveStoredKeys(keys);
            }

            // Гарантированная синхронизация публичной части ключа с базой данных при каждом обновлении страницы
            const formData = new FormData();
            formData.append('public_key', JSON.stringify(keys.publicKey));
            await fetch('messages.php?save_public_key=1', {
                method: 'POST',
                body: formData,
                cache: 'no-store'
            });
        } catch (err) {
            console.error("[E2EE] Ошибка фоновой генерации/синхронизации ключей:", err);
        }
    })();

const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

document.getElementById('menuBtn').onclick = () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
};

document.getElementById('closeBtn').onclick = closeSidebar;
overlay.onclick = closeSidebar;

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
}

let activeFormToSubmit = null;

// Показ кастомного модального окна
function showConfirmModal(title, text, formElement) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalText').textContent = text;
    activeFormToSubmit = formElement;
    document.getElementById('confirmModal').classList.add('active');
}

document.getElementById('modalCancelBtn').onclick = () => {
    document.getElementById('confirmModal').classList.remove('active');
    activeFormToSubmit = null;
};

document.getElementById('modalConfirmBtn').onclick = () => {
    if (activeFormToSubmit) {
        activeFormToSubmit.submit();
    }
};

document.querySelector('.modal-content').onclick = (e) => {
    e.stopPropagation();
};

document.getElementById('confirmModal').onclick = () => {
    document.getElementById('confirmModal').classList.remove('active');
    activeFormToSubmit = null;
};

function updateDialogsList(){
    fetch('messages.php?ajax_get_dialogs=1', { cache: 'no-store' })
    .then(response => response.json())
    .then(data => {
        const badge = document.getElementById('total-unread-badge');
        badge.textContent = data.total > 0 ? data.total : '';

        const container = document.getElementById('dialogs-container');
        container.innerHTML = data.html;
    })
    .catch(err => console.error('Ошибка обновления диалогов:', err));
}

setInterval(updateDialogsList, 3000);
</script>

</body>
</html>