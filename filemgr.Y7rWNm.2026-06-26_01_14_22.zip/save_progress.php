<?php
// Подключаем db.php для автоматического и безопасного старта долговечной сессии
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Нет доступа');
}

$user_id = (int)$_SESSION['user_id'];
$game_name = $_POST['game_name'] ?? '';
$progress_data = $_POST['progress_data'] ?? '';

if ($game_name === '' || $progress_data === '') {
    http_response_code(400);
    exit('Не хватает данных');
}

$sql = "INSERT INTO game_progress (user_id, game_name, progress_data)
        VALUES (:user_id, :game_name, :progress_data)
        ON DUPLICATE KEY UPDATE progress_data = :progress_data";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':user_id' => $user_id,
    ':game_name' => $game_name,
    ':progress_data' => $progress_data
]);

echo "OK";
?>