<?php
// Подключаем db.php для автоматического запуска долговечной сессии
require_once 'db.php';

if (!isset($_SESSION['username'])) {
    echo 0;
    exit;
}

$currentUser = $_SESSION['username'];

try {
    // Считаем только те непрочитанные сообщения, которые не были скрыты (удалены) получателем
    $stmtUnread = $pdo->prepare("
        SELECT COUNT(*) 
        FROM private_messages 
        WHERE receiver = :username 
          AND is_read = 0 
          AND COALESCE(hidden_by_receiver, 0) = 0
    ");
    $stmtUnread->execute(['username' => $currentUser]);

    echo (int)$stmtUnread->fetchColumn();
} catch (PDOException $e) {
    echo 0;
}
?>