<?php

require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location:error.php");
    exit;
}

$currentUser = $_SESSION['username'];

// Генерация CSRF-токена, если он отсутствует в сессии
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 1. ОБРАБОТКА POST-ЗАПРОСА: ДОБАВЛЕНИЕ В КОНТАКТЫ (С ЗАЩИТОЙ CSRF)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    // Проверка CSRF-токена
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        http_response_code(403);
        exit('Ошибка безопасности: неверный CSRF-токен');
    }

    $contact = trim($_POST['add']);

    if ($contact !== $currentUser) {
        $check = $pdo->prepare("
            SELECT id
            FROM contacts
            WHERE owner = ?
            AND contact_user = ?
        ");

        $check->execute([
            $currentUser,
            $contact
        ]);

        if (!$check->fetch()) {
            $add = $pdo->prepare("
                INSERT INTO contacts
                (owner, contact_user)
                VALUES (?, ?)
            ");

            $add->execute([
                $currentUser,
                $contact
            ]);
        }
    }
    exit('ok');
}

// 2. ОБРАБОТКА GET-ЗАПРОСА: ДИНАМИЧЕСКИЙ ПОИСК ПОЛЬЗОВАТЕЛЕЙ (AJAX)
if (isset($_GET['search'])) {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim($_GET['search']);
    
    if ($q === '') {
        echo json_encode([]);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT username, avatar_type, last_seen
        FROM users
        WHERE username != ? AND username LIKE ?
        ORDER BY username ASC
        LIMIT 30
    ");
    $stmt->execute([$currentUser, '%' . $q . '%']);
    $foundUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $contactsStmt = $pdo->prepare("
        SELECT contact_user
        FROM contacts
        WHERE owner = ?
    ");
    $contactsStmt->execute([$currentUser]);
    $myContacts = $contactsStmt->fetchAll(PDO::FETCH_COLUMN);

    $results = [];
    foreach ($foundUsers as $user) {
        $isOnline = $user['last_seen'] && (time() - strtotime($user['last_seen'])) <= 60;
        $added = in_array($user['username'], $myContacts);

        ob_start();
        echo renderAvatar($user['avatar_type'] ?? 0, $user['username']);
        $avatarHtml = ob_get_clean();

        $results[] = [
            'username' => $user['username'],
            'isOnline' => $isOnline,
            'added' => $added,
            'avatar_html' => $avatarHtml
        ];
    }

    echo json_encode($results);
    exit;
}

// 3. ПОЛУЧЕНИЕ ДАННЫХ ТЕКУЩЕГО ПОЛЬЗОВАТЕЛЯ ДЛЯ ШАБЛОНА
$stmtMe = $pdo->prepare("
    SELECT avatar_type, gender, role
    FROM users
    WHERE username = ?
");
$stmtMe->execute([$currentUser]);
$me = $stmtMe->fetch(PDO::FETCH_ASSOC);

$isAdmin = ($me['role'] ?? '') === 'admin';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Поиск контактов</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
    --bg:#f4f7fb;
    --card:#ffffff;
    --border:#e7edf5;
    --primary:#2AABEE;
    --text:#1f2937;
    --muted:#6b7280;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
}

body{
    background:var(--bg);
    color:var(--text);
    overflow-x:hidden;
}

.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:300px;
    height:100%;
    background:#ffffff;
    box-shadow:4px 0 24px rgba(0,0,0,.15);
    transform:translateX(-100%);
    transition: transform .25s cubic-bezier(0.4, 0, 0.2, 1);
    z-index:1000;
    display: flex;
    flex-direction: column;
}

.sidebar.active{
    transform:translateX(0);
}

.overlay{
    position:fixed;
    inset:0;
    background:rgba(15, 23, 42, 0.45);
    opacity:0;
    visibility:hidden;
    transition:.25s ease-in-out;
    z-index:950;
    backdrop-filter: blur(2px);
}

.overlay.active{
    opacity:1;
    visibility:visible;
}

.sidebar-profile {
    background: linear-gradient(135deg, #2AABEE, #229ED9);
    padding: 24px 20px 18px 20px;
    color: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
}

.sidebar-close-btn {
    position: absolute;
    top: 16px;
    right: 16px;
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.85);
    font-size: 16px;
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: background 0.15s, color 0.15s;
}

.sidebar-close-btn:hover {
    background: rgba(255,255,255,0.15);
    color: #ffffff;
}

.sidebar-avatar{
    width:64px;
    height:64px;
    min-width:64px;
    min-height:64px;
    border-radius:50%;
    overflow:hidden;
    position:relative;
    background:#ffffff;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
    border: 2px solid rgba(255, 255, 255, 0.25);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.sidebar-avatar > * {
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}

.sidebar-avatar img,
.sidebar-avatar svg {
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    object-position:center !important;
    display:block !important;
    border-radius:50% !important;
}

.sidebar-user-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.sidebar-user{
    font-size: 16px;
    font-weight:700;
    color: #ffffff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-role{
    font-size:13px;
    color: rgba(255, 255, 255, 0.85);
}

.sidebar-menu{
    list-style:none;
    padding: 8px 0;
    overflow-y:auto;
    scrollbar-width:none;
    flex: 1;
}

.sidebar-menu::-webkit-scrollbar{
    display:none;
}

.sidebar-menu li {
    margin: 2px 8px;
}

.sidebar-menu a{
    display:flex;
    align-items:center;
    gap:20px;
    padding:12px 16px;
    text-decoration:none;
    color: #212121;
    font-weight:500;
    font-size: 14px;
    border-radius: 8px;
    transition: background 0.15s ease-in-out, color 0.15s;
}

.sidebar-menu a:hover{
    background: #f4f4f5;
}

.sidebar-menu a.active {
    background: #f0f7fc;
    color: #2AABEE;
    font-weight: 600;
}

.sidebar-menu a i {
    font-size: 18px;
    color: #707579;
    width: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: color 0.15s;
}

.sidebar-menu a:hover i {
    color: #2AABEE;
}

.sidebar-menu a.active i {
    color: #2AABEE;
}

.container{
    max-width:920px;
    margin:0 auto;
    padding:0;
    background:#ffffff;
    min-height:100vh;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:16px;
    margin-bottom:0;
    background: white;
    border-bottom: 1px solid var(--border);
    padding: 14px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.menu-btn-inline {
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #2AABEE;
    font-size: 20px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}

.menu-btn-inline:hover {
    background: #f1f5f9;
}

.title{
    font-size:22px;
    font-weight:800;
    display: flex;
    align-items: center;
    gap: 8px;
}

.search-box-wrapper {
    padding: 16px;
    background: #ffffff;
    border-bottom: 1px solid var(--border);
}

.search-box{
    position:relative;
}

.search-box i{
    position:absolute;
    left:16px;
    top:50%;
    transform:translateY(-50%);
    color:var(--muted);
    font-size: 16px;
}

.search-input{
    width:100%;
    height:48px;
    border:none;
    background:#f1f5f9;
    border-radius:12px;
    padding:0 16px 0 46px;
    outline:none;
    font-size:15px;
    transition:.15s ease-in-out;
    color: var(--text);
}

.search-input:focus{
    background: #ffffff;
    box-shadow: 0 0 0 2px var(--primary);
}

.user-list {
    display: flex;
    flex-direction: column;
    background: #ffffff;
}

.user-card{
    background:#ffffff;
    border-bottom:1px solid #edf1f5;
    padding:12px 16px;
    display:flex;
    align-items:center;
    gap:14px;
    transition: background 0.1s ease-in-out;
}

.user-card:hover{
    background: #f8fafc;
}

.user-card:last-child {
    border-bottom: none;
}

.avatar-wrap {
    width: 52px;
    height: 52px;
    min-width: 52px;
    min-height: 52px;
    border-radius: 50%;
    overflow: hidden;
    background: #f3f4f6;
    position: relative;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.avatar-wrap > * {
    width: 100% !important;
    height: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}

.avatar-wrap img,
.avatar-wrap svg {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    object-position: center !important;
    display: block !important;
    border-radius: 50% !important;
}

.online-dot{
    position:absolute;
    right: 0px;
    bottom: 0px;
    width:13px;
    height:13px;
    border-radius:50%;
    background:#22c55e;
    border:2px solid white;
    z-index:20;
}

.user-info{
    flex:1;
    min-width:0;
}

.username{
    font-size:15px;
    font-weight:700;
    color: var(--text);
}

.actions{
    display:flex;
    gap:8px;
}

.icon-btn{
    width:36px;
    height:36px;
    border:none;
    border-radius:10px;
    display:flex;
    align-items:center;
    justify-content:center;
    cursor:pointer;
    text-decoration:none;
    font-size:14px;
    transition: transform 0.1s ease-in-out, background-color 0.15s;
}

.icon-btn:active{
    transform:scale(0.95);
}

.add-btn{
    background:#e8f7ee;
    color:#22c55e;
}

.add-btn:hover {
    background: #d1f2dd;
}

.chat-btn{
    background:#eef6ff;
    color:#2AABEE;
}

.chat-btn:hover {
    background: #e0f0ff;
}

.added{
    background:#f3f4f6 !important;
    color:#888 !important;
    cursor:default !important;
}

.empty{
    text-align:center;
    padding:80px 20px;
    color:var(--muted);
    background: white;
    border: none;
    font-size: 15px;
}

@media(max-width:480px){
    .sidebar{
        width: 280px;
    }
    .title{
        font-size:18px;
    }
    .header {
        padding: 12px 12px;
    }
}
</style>
</head>

<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="container">
    <div class="header">
        <div class="header-left">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="title">Поиск контактов</h1>
        </div>
    </div>

    <div class="search-box-wrapper">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input
                type="text"
                id="searchInput"
                class="search-input"
                placeholder="Введите имя пользователя..."
                autocomplete="off"
            >
        </div>
    </div>

    <div class="user-list" id="userList">
        <div class="empty" id="emptyText">
            Начните вводить имя пользователя
        </div>
    </div>
</div>

<script>
const CSRF_TOKEN = '<?= $_SESSION['csrf_token'] ?>';

const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

document.getElementById('menuBtn').onclick = () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
};

document.getElementById('closeBtn').onclick = closeSidebar;
overlay.onclick = closeSidebar;

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
}

const input = document.getElementById('searchInput');
const userList = document.getElementById('userList');
const emptyText = document.getElementById('emptyText');
let searchTimeout = null;

input.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    const q = input.value.trim();

    document.querySelectorAll('.user-card').forEach(card => card.remove());

    if (q.length === 0) {
        emptyText.innerHTML = 'Начните вводить имя пользователя';
        emptyText.style.display = 'block';
        return;
    }

    searchTimeout = setTimeout(() => {
        fetch('?search=' + encodeURIComponent(q))
        .then(res => res.json())
        .then(users => {
            document.querySelectorAll('.user-card').forEach(card => card.remove());

            if (users.length === 0) {
                emptyText.innerHTML = 'Ничего не найдено';
                emptyText.style.display = 'block';
                return;
            }

            emptyText.style.display = 'none';

            users.forEach(user => {
                const card = document.createElement('div');
                card.className = 'user-card';

                const avatarWrap = document.createElement('div');
                avatarWrap.className = 'avatar-wrap';
                avatarWrap.innerHTML = user.avatar_html;

                if (user.isOnline) {
                    const onlineDot = document.createElement('div');
                    onlineDot.className = 'online-dot';
                    avatarWrap.appendChild(onlineDot);
                }
                card.appendChild(avatarWrap);

                const userInfo = document.createElement('div');
                userInfo.className = 'user-info';
                
                const usernameDiv = document.createElement('div');
                usernameDiv.className = 'username';
                usernameDiv.textContent = user.username;
                
                userInfo.appendChild(usernameDiv);
                card.appendChild(userInfo);

                const actions = document.createElement('div');
                actions.className = 'actions';

                const addBtn = document.createElement('button');
                addBtn.className = 'icon-btn add-btn';
                
                if (user.added) {
                    addBtn.classList.add('added');
                    addBtn.disabled = true;
                    addBtn.innerHTML = '<i class="fas fa-check"></i>';
                } else {
                    addBtn.innerHTML = '<i class="fas fa-plus"></i>';
                    addBtn.addEventListener('click', () => {
                        addContact(addBtn, user.username);
                    });
                }
                actions.appendChild(addBtn);

                const chatBtn = document.createElement('a');
                chatBtn.className = 'icon-btn chat-btn';
                chatBtn.href = 'dialog.php?user=' + encodeURIComponent(user.username);
                chatBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
                actions.appendChild(chatBtn);

                card.appendChild(actions);
                userList.appendChild(card);
            });
        })
        .catch(err => {
            console.error('Ошибка при поиске:', err);
        });
    }, 300);
});

function addContact(btn, username) {
    if (btn.disabled) return;

    const formData = new FormData();
    formData.append('add', username);
    formData.append('csrf_token', CSRF_TOKEN);

    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(res => {
        if (!res.ok) throw new Error('Network response error');
        return res.text();
    })
    .then(data => {
        if (data.trim() === 'ok') {
            btn.classList.add('added');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-check"></i>';
        } else {
            console.error('Ошибка добавления:', data);
        }
    })
    .catch(err => {
        console.error('Ошибка запроса на добавление контакта:', err);
    });
}
</script>
</body>
</html>