<?php
require_once 'db.php';
require_once 'crypto.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit();
}

$currentUser = $_SESSION['username'];
$otherUser = isset($_GET['user']) ? trim($_GET['user']) : '';

// Гарантированная фоновая миграция БД при открытии диалога
try {
    $pdo->exec("ALTER TABLE private_messages ADD COLUMN forwarded_from VARCHAR(50) DEFAULT NULL");
} catch (PDOException $e) {
    // Игнорируем ошибку, если колонка уже существует
}

try {
    $pdo->exec("ALTER TABLE users ADD COLUMN public_key TEXT DEFAULT NULL");
} catch (PDOException $e) {
    // Игнорируем ошибку, если колонка уже существует
}

// === ОБНОВЛЕНИЕ АКТИВНОСТИ ТЕКУЩЕГО ПОЛЬЗОВАТЕЛЯ ===
try {
    $updateLastSeen = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE username = :u");
    $updateLastSeen->execute(['u' => $currentUser]);
} catch (Exception $e) {
    try {
        $updateLastSeen = $pdo->prepare("UPDATE users SET last_active = NOW() WHERE username = :u");
        $updateLastSeen->execute(['u' => $currentUser]);
    } catch (Exception $e2) {
        // Игнорируем
    }
}

// === ПРОВЕРКА НАХОЖДЕНИЯ ПОЛУЧАТЕЛЯ В АКТИВНОМ ЧАТЕ ДЛЯ ПОДАВЛЕНИЯ ПУШЕЙ ===
function isReceiverInChat(string $sender, string $receiver): bool
{
    $file = __DIR__ . '/uploads/typing/' .
        preg_replace('/[^a-zA-Z0-9_\-]/', '_', $sender) . '__' .
        preg_replace('/[^a-zA-Z0-9_\-]/', '_', $receiver) . '.json';
        
    if (is_file($file)) {
        $data = json_decode((string)file_get_contents($file), true);
        if (is_array($data)) {
            $lastActive = (int)($data['updated_at'] ?? 0);
            if ((time() - $lastActive) < 15) {
                return true;
            }
        }
    }
    return false;
}

// === СОХРАНЕНИЕ ПУБЛИЧНОГО КЛЮЧА ТЕКУЩЕГО ПОЛЬЗОВАТЕЛЯ (API) ===
if (isset($_GET['save_public_key']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $pubKey = isset($_POST['public_key']) ? trim($_POST['public_key']) : '';
    if ($pubKey === '') {
        safe_json_response(['status' => 'error', 'message' => 'Пустой ключ'], 400);
    }
    try {
        $upd = $pdo->prepare("UPDATE users SET public_key = :pk WHERE username = :u");
        $upd->execute(['pk' => $pubKey, 'u' => $currentUser]);
        safe_json_response(['status' => 'success']);
    } catch (Exception $e) {
        safe_json_response(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
    exit();
}

// === ПОЛУЧЕНИЕ ПУБЛИЧНОГО КЛЮЧА ПОЛУЧАТЕЛЯ ДЛЯ ПЕРЕШИФРОВАНИЯ (API) ===
if (isset($_GET['get_room_key'])) {
    header('Content-Type: application/json; charset=utf-8');
    $targetUser = isset($_GET['target']) ? trim($_GET['target']) : '';
    if ($targetUser === '') {
        safe_json_response(['status' => 'error', 'message' => 'Не указан получатель'], 400);
    }
    
    try {
        $stmt = $pdo->prepare("SELECT public_key FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$targetUser]);
        $targetPublicKey = $stmt->fetchColumn() ?: null;
        
        safe_json_response(['status' => 'success', 'public_key' => $targetPublicKey]);
    } catch (Exception $e) {
        safe_json_response(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
    exit();
}

// Разрешаем выполнение скрипта без параметра "user" для системных запросов пересылки и получения ключей
if ($otherUser === '' && !isset($_GET['get_forward_targets']) && !isset($_GET['forward_message']) && !isset($_GET['get_room_key'])) {
    header("Location: messages.php");
    exit();
}

$uploadDir = __DIR__ . '/uploads/messages/';
$uploadUrl = 'uploads/messages/';
ensure_dir($uploadDir);

$currentUserAvatarType = 0;
$currentUserRole = 'user';

try {
    $userStmt = $pdo->prepare("SELECT avatar_type, role FROM users WHERE username = :u");
    $userStmt->execute(['u' => $currentUser]);
    $userRow = $userStmt->fetch(PDO::FETCH_ASSOC);
    if ($userRow) {
        $currentUserAvatarType = (int)($userRow['avatar_type'] ?? 0);
        $currentUserRole = $userRow['role'] ?? 'user';
    }
} catch (PDOException $e) {
    // Безопасный откат
}

$otherUserAvatarType = 0;
$otherUserPublicKey = '';
$otherUserRole = 'user';
$otherUserGender = null;
$otherUserLastSeen = null;

try {
    $otherStmt = $pdo->prepare("SELECT avatar_type, public_key, role FROM users WHERE username = :u");
    $otherStmt->execute(['u' => $otherUser]);
    $otherUserAvatarRow = $otherStmt->fetch(PDO::FETCH_ASSOC);
    if ($otherUserAvatarRow) {
        $otherUserAvatarType = (int)($otherUserAvatarRow['avatar_type'] ?? 0);
        $otherUserPublicKey = $otherUserAvatarRow['public_key'] ?? '';
        $otherUserRole = $otherUserAvatarRow['role'] ?? 'user';
    }
} catch (PDOException $e) {
    // Игнорируем
}

// Пытаемся получить пол и время последнего посещения собеседника (с автоопределением колонок БД)
try {
    $checkCols = $pdo->query("SELECT * FROM users LIMIT 1");
    if ($checkCols) {
        $row = $checkCols->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $hasGender = array_key_exists('gender', $row);
            $hasSex = array_key_exists('sex', $row);
            $hasLastSeen = array_key_exists('last_seen', $row);
            $hasLastActive = array_key_exists('last_active', $row);
            
            $selectFields = [];
            if ($hasGender) $selectFields[] = 'gender';
            elseif ($hasSex) $selectFields[] = 'sex AS gender';
            
            if ($hasLastSeen) $selectFields[] = 'last_seen';
            elseif ($hasLastActive) $selectFields[] = 'last_active AS last_seen';
            
            if (!empty($selectFields)) {
                $extraStmt = $pdo->prepare("SELECT " . implode(', ', $selectFields) . " FROM users WHERE username = :u");
                $extraStmt->execute(['u' => $otherUser]);
                $extraRow = $extraStmt->fetch(PDO::FETCH_ASSOC);
                if ($extraRow) {
                    if (isset($extraRow['gender'])) {
                        $otherUserGender = $extraRow['gender'];
                    }
                    if (isset($extraRow['last_seen'])) {
                        $otherUserLastSeen = $extraRow['last_seen'];
                    }
                }
            }
        }
    }
} catch (Exception $e) {
    // Безопасный откат
}

$genderName = 'Не указан';
if ($otherUserGender) {
    $g = strtolower($otherUserGender);
    if ($g === 'male' || $g === 'm' || $g === 'мужской' || $g === 'муж') {
        $genderName = 'Мужской';
    } elseif ($g === 'female' || $g === 'f' || $g === 'женский' || $g === 'жен') {
        $genderName = 'Женский';
    } else {
        $genderName = htmlspecialchars($otherUserGender);
    }
}

$otherRoleName = 'Пользователь';
$r = strtolower($otherUserRole);
if ($r === 'admin' || $r === 'administrator') {
    $otherRoleName = 'Администратор';
} elseif ($r === 'moderator') {
    $otherRoleName = 'Модератор';
} elseif ($r === 'support') {
    $otherRoleName = 'Поддержка';
}

$isContact = false;
try {
    $checkContact = $pdo->prepare("SELECT 1 FROM contacts WHERE owner = :cu AND contact_user = :ou LIMIT 1");
    $checkContact->execute(['cu' => $currentUser, 'ou' => $otherUser]);
    if ($checkContact->fetch()) {
        $isContact = true;
    }
} catch (PDOException $e) {
    $isContact = false;
}

function onesignalCurlPost(array $fields, string $apiKey): array
{
    $authPrefix = (strpos($apiKey, 'os_') === 0) ? 'Key ' : 'Basic ';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.onesignal.com/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json; charset=utf-8',
        'Authorization: ' . $authPrefix . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

    $responseBody = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'body' => $responseBody,
        'http_code' => $httpCode
    ];
}

function sendMedianOneSignalPush(string $sender, string $receiver, string $messageText): void
{
    $appId = "ebe09011-6587-4057-a4c1-f20d56b54763"; 
    $restApiKey = "os_v2_app_5pqjaelfq5afpjgb6igvnnkhmnekmr55skfexxfyqinicecrqd5joq2pccepslpgd3xgkz5uffpbnw7xjymp7qzxcbkffqqmnlgtwvy"; 

    $targetUrl = "https://neiro-bitva.ru/dialog.php?user=" . urlencode($sender);

    $basePayload = [
        'app_id' => $appId,
        'headings' => ['ru' => "Новое сообщение", 'en' => "New message"],
        'contents' => ['ru' => $sender . ": " . $messageText, 'en' => $sender . ": " . $messageText],
        'data' => ['targetUrl' => $targetUrl]
    ];

    $payloadV5 = array_merge($basePayload, [
        'include_aliases' => ['external_id' => [$receiver]],
        'target_channel' => 'push'
    ]);

    $result = onesignalCurlPost($payloadV5, $restApiKey);

    if ($result['http_code'] === 400) {
        $payloadV3 = array_merge($basePayload, [
            'include_external_user_ids' => [$receiver]
        ]);
        onesignalCurlPost($payloadV3, $restApiKey);
    }
}

// === ПОЛУЧЕНИЕ ДВУХ ОТДЕЛЬНЫХ СПИСКОВ: КОНТАКТОВ И ДИАЛОГОВ ДЛЯ ПЕРЕСЫЛКИ ===
if (isset($_GET['get_forward_targets'])) {
    header('Content-Type: application/json; charset=utf-8');
    try {
        // 1. Contacts
        $getContacts = $pdo->prepare("
            SELECT u.username, u.avatar_type
            FROM contacts c
            INNER JOIN users u ON c.contact_user = u.username
            WHERE c.owner = ?
            ORDER BY u.username ASC
        ");
        $getContacts->execute([$currentUser]);
        $contacts = $getContacts->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($contacts as &$c) {
            ob_start();
            echo renderAvatar((int)$c['avatar_type'], $c['username']);
            $c['avatar_html'] = ob_get_clean();
        }
        unset($c);

        // 2. Dialogs
        $getDialogs = $pdo->prepare("
            SELECT DISTINCT u.username, u.avatar_type FROM (
                SELECT sender AS contact_name FROM private_messages WHERE receiver = :user AND COALESCE(hidden_by_receiver, 0) = 0
                UNION
                SELECT receiver AS contact_name FROM private_messages WHERE sender = :user AND COALESCE(hidden_by_sender, 0) = 0
            ) t
            INNER JOIN users u ON u.username = t.contact_name
            WHERE u.username != :user
            ORDER BY u.username ASC
        ");
        $getDialogs->execute(['user' => $currentUser]);
        $dialogs = $getDialogs->fetchAll(PDO::FETCH_ASSOC);

        foreach ($dialogs as &$d) {
            ob_start();
            echo renderAvatar((int)$d['avatar_type'], $d['username']);
            $d['avatar_html'] = ob_get_clean();
        }
        unset($d);
        
        safe_json_response([
            'contacts' => $contacts,
            'dialogs'  => $dialogs
        ]);
    } catch (Exception $e) {
        safe_json_response(['error' => $e->getMessage()], 500);
    }
    exit();
}

// (Устаревший endpoint серверной пересылки - оставлен для обратной совместимости, но клиент переведен на безопасное перешифрование)
if (isset($_GET['forward_message']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $msgId = isset($_POST['message_id']) ? (int)$_POST['message_id'] : 0;
    $targetUser = isset($_POST['target_user']) ? trim($_POST['target_user']) : '';
    
    if ($msgId <= 0 || $targetUser === '') {
        safe_json_response(['status' => 'error', 'message' => 'Некорректные параметры'], 400);
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM private_messages 
            WHERE id = :id 
              AND (sender = :user OR receiver = :user)
            LIMIT 1
        ");
        $stmt->execute(['id' => $msgId, 'user' => $currentUser]);
        $msg = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$msg) {
            safe_json_response(['status' => 'error', 'message' => 'Сообщение не найдено'], 404);
        }

        $forwardedFrom = !empty($msg['forwarded_from']) ? $msg['forwarded_from'] : $msg['sender'];
        
        $ins = $pdo->prepare("
            INSERT INTO private_messages (
                sender, receiver, message, file_path, file_type, original_name,
                is_encrypted, message_salt, message_iv, file_salt, file_iv, original_mime,
                is_read, expires_at, hidden_by_sender, hidden_by_receiver, reply_to_id, forwarded_from
            ) VALUES (
                :sender, :receiver, :message, :file_path, :file_type, :original_name,
                :is_encrypted, :message_salt, :message_iv, :file_salt, :file_iv, :original_mime,
                0, NULL, 0, 0, NULL, :forwarded_from
            )
        ");
        
        $ins->execute([
            'sender'         => $currentUser,
            'receiver'       => $targetUser,
            'message'        => $msg['message'],
            'file_path'      => $msg['file_path'],
            'file_type'      => $msg['file_type'],
            'original_name'  => $msg['original_name'],
            'is_encrypted'   => $msg['is_encrypted'],
            'message_salt'   => $msg['message_salt'],
            'message_iv'     => $msg['message_iv'],
            'file_salt'      => $msg['file_salt'],
            'file_iv'        => $msg['file_iv'],
            'original_mime'  => $msg['original_mime'],
            'forwarded_from' => $forwardedFrom
        ]);
        
        $pushText = $msg['is_encrypted'] ? '🔐 Получено защищенное пересланное сообщение' : $msg['message'];
        if ($msg['file_path']) {
            $pushText = '📎 Переслан файл: ' . ($msg['original_name'] ?: 'вложение');
        }
        
        if (!isReceiverInChat($currentUser, $targetUser)) {
            sendMedianOneSignalPush($currentUser, $targetUser, $pushText);
        }
        
        safe_json_response(['status' => 'success']);
    } catch (Exception $e) {
        safe_json_response(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
    exit();
}

if (isset($_GET['add_contact']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $ins = $pdo->prepare("INSERT INTO contacts (owner, contact_user) VALUES (:cu, :ou)");
        $ins->execute(['cu' => $currentUser, 'ou' => $otherUser]);
        safe_json_response(['status' => 'success']);
    } catch (Exception $e) {
        safe_json_response(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
    exit();
}

if (isset($_GET['remove_contact']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $del = $pdo->prepare("DELETE FROM contacts WHERE owner = :cu AND contact_user = :ou");
        $del->execute(['cu' => $currentUser, 'ou' => $otherUser]);
        safe_json_response(['status' => 'success']);
    } catch (Exception $e) {
        safe_json_response(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
    exit();
}

if (isset($_GET['toggle_reaction']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $messageId = isset($_POST['message_id']) ? (int)$_POST['message_id'] : 0;
    $reaction = isset($_POST['reaction']) ? trim($_POST['reaction']) : '';

    if ($messageId <= 0 || empty($reaction)) {
        safe_json_response(['status' => 'error', 'message' => 'Некорректные параметры реакций'], 400);
    }

    try {
        $check = $pdo->prepare("SELECT id, reaction FROM message_reactions WHERE message_id = :mid AND username = :u LIMIT 1");
        $check->execute(['mid' => $messageId, 'u' => $currentUser]);
        $existing = $check->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $del = $pdo->prepare("DELETE FROM message_reactions WHERE message_id = :mid AND username = :u");
            $del->execute(['mid' => $messageId, 'u' => $currentUser]);
            
            if ($existing['reaction'] !== $reaction) {
                $ins = $pdo->prepare("INSERT INTO message_reactions (message_id, username, reaction) VALUES (:mid, :u, :r)");
                $ins->execute(['mid' => $messageId, 'u' => $currentUser, 'r' => $reaction]);
            }
        } else {
            $ins = $pdo->prepare("INSERT INTO message_reactions (message_id, username, reaction) VALUES (:mid, :u, :r)");
            $ins->execute(['mid' => $messageId, 'u' => $currentUser, 'r' => $reaction]);
        }

        safe_json_response(['status' => 'success']);
    } catch (Exception $e) {
        safe_json_response(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
    exit();
}

if (isset($_GET['delete']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $messageId = isset($_POST['message_id']) ? (int)$_POST['message_id'] : 0;
    if ($messageId <= 0) {
        safe_json_response(['status' => 'error', 'message' => 'Некорректный ID сообщения'], 400);
    }

    $msgCheck = $pdo->prepare("
        SELECT sender, receiver 
        FROM private_messages 
        WHERE id = :id 
          AND (sender = :user OR receiver = :user)
        LIMIT 1
    ");
    $msgCheck->execute(['id' => $messageId, 'user' => $currentUser]);
    $msgRow = $msgCheck->fetch(PDO::FETCH_ASSOC);

    if (!$msgRow) {
        safe_json_response(['status' => 'error', 'message' => 'Сообщение не найдено'], 404);
    }

    if ($msgRow['sender'] === $currentUser) {
        $upd = $pdo->prepare("UPDATE private_messages SET hidden_by_sender = 1 WHERE id = :id");
    } else {
        $upd = $pdo->prepare("UPDATE private_messages SET hidden_by_receiver = 1 WHERE id = :id");
    }
    $upd->execute(['id' => $messageId]);

    safe_json_response(['status' => 'success']);
    exit();
}

function dialogVisibleWhere(): string
{
    return "(
        (sender = :currentUser AND receiver = :otherUser AND COALESCE(hidden_by_sender, 0) = 0)
        OR
        (sender = :otherUser AND receiver = :currentUser AND COALESCE(hidden_by_receiver, 0) = 0)
    )";
}

function deleteFullyHiddenMessages(PDO $pdo): void
{
    $stmt = $pdo->prepare("
        SELECT id, file_path
        FROM private_messages
        WHERE COALESCE(hidden_by_sender, 0) = 1
          AND COALESCE(hidden_by_receiver, 0) = 1
    ");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $msg) {
        if (!empty($msg['file_path'])) {
            if (isSafeUploadPath($msg['file_path'])) {
                $fullPath = __DIR__ . '/' . ltrim($msg['file_path'], '/\\');
                if (is_file($fullPath)) {
                    @unlink($fullPath);
                }
            }
        }
    }

    $del = $pdo->prepare("
        DELETE FROM private_messages
        WHERE COALESCE(hidden_by_sender, 0) = 1
          AND COALESCE(hidden_by_receiver, 0) = 1
    ");
    $del->execute();
}

function deleteExpiredMessages(PDO $pdo): void
{
    $stmt = $pdo->prepare("
        SELECT id, file_path
        FROM private_messages
        WHERE expires_at IS NOT NULL
          AND expires_at <= NOW()
    ");
    $stmt->execute();
    $expiredMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($expiredMessages as $msg) {
        if (!empty($msg['file_path'])) {
            if (isSafeUploadPath($msg['file_path'])) {
                $fullPath = __DIR__ . '/' . ltrim($msg['file_path'], '/\\');
                if (is_file($fullPath)) {
                    @unlink($fullPath);
                }
            }
        }
    }

    $deleteStmt = $pdo->prepare("
        DELETE FROM private_messages
        WHERE expires_at IS NOT NULL
          AND expires_at <= NOW()
    ");
    $deleteStmt->execute();
}

if (!isset($_GET['fetch']) && !isset($_GET['typing']) && !isset($_GET['set_typing']) && !isset($_GET['mark_read']) && !isset($_GET['toggle_reaction'])) {
    deleteFullyHiddenMessages($pdo);
    deleteExpiredMessages($pdo);
}

if (isset($_GET['mark_read'])) {
    header('Content-Type: application/json; charset=utf-8');

    $stmt = $pdo->prepare("
        UPDATE private_messages
        SET is_read = 1
        WHERE sender = :otherUser
          AND receiver = :currentUser
          AND is_read = 0
          AND COALESCE(hidden_by_receiver, 0) = 0
          AND (expires_at IS NULL OR expires_at > NOW())
    ");
    $stmt->execute([
        'otherUser'   => $otherUser,
        'currentUser' => $currentUser
    ]);

    safe_json_response(['status' => 'success']);
}

if (isset($_GET['typing'])) {
    header('Content-Type: application/json; charset=utf-8');

    $typingFile = __DIR__ . '/uploads/typing/' .
        preg_replace('/[^a-zA-Z0-9_\-]/', '_', $currentUser) . '__' .
        preg_replace('/[^a-zA-Z0-9_\-]/', '_', $otherUser) . '.json';

    $isTyping = false;
    $lastActive = 0;

    if (is_file($typingFile)) {
        $data = json_decode((string)file_get_contents($typingFile), true);
        if (is_array($data)) {
            $isTyping = !empty($data['typing']) && !empty($data['expires_at']) && (int)$data['expires_at'] >= time();
            $lastActive = (int)($data['updated_at'] ?? 0);
        }
    }

    safe_json_response([
        'status'     => 'success',
        'typing'     => $isTyping,
        'updated_at' => $lastActive
    ]);
}

if (isset($_GET['set_typing'])) {
    header('Content-Type: application/json; charset=utf-8');

    ensure_dir(__DIR__ . '/uploads/typing/');

    $typing = isset($_POST['typing']) ? (int)$_POST['typing'] : 0;
    $typingFile = __DIR__ . '/uploads/typing/' .
        preg_replace('/[^a-zA-Z0-9_\-]/', '_', $otherUser) . '__' .
        preg_replace('/[^a-zA-Z0-9_\-]/', '_', $currentUser) . '.json';

    $payload = [
        'typing'     => $typing ? 1 : 0,
        'updated_at' => time(),
        'expires_at' => $typing ? (time() + 6) : time()
    ];

    file_put_contents($typingFile, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    safe_json_response(['status' => 'success']);
}

if (isset($_GET['edit']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $messageId = isset($_POST['message_id']) ? (int)$_POST['message_id'] : 0;
    $messageCipher = trim($_POST['message_cipher'] ?? '');
    $messageIv = trim($_POST['message_iv'] ?? '');
    $plainFallback = trim($_POST['message'] ?? '');

    if ($messageId <= 0) {
        safe_json_response(['status' => 'error', 'message' => 'Некорректный ID сообщения'], 400);
    }

    $checkStmt = $pdo->prepare("
        SELECT id
        FROM private_messages
        WHERE id = :id
          AND sender = :sender
          AND receiver = :receiver
          AND COALESCE(hidden_by_sender, 0) = 0
          AND (expires_at IS NULL OR expires_at > NOW())
        LIMIT 1
    ");
    $checkStmt->execute([
        'id'       => $messageId,
        'sender'   => $currentUser,
        'receiver' => $otherUser
    ]);
    $existing = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if (!$existing) {
        safe_json_response(['status' => 'error', 'message' => 'Сообщение не найдено или нельзя редактировать'], 403);
    }

    $isEncrypted = 0;
    if ($messageCipher !== '') {
        if (!e2ee_is_base64($messageCipher) || !e2ee_is_base64($messageIv)) {
            safe_json_response(['status' => 'error', 'message' => 'Некорректные данные шифрования'], 400);
        }
        $isEncrypted = 1;
    }

    if ($messageCipher === '' && $plainFallback === '') {
        safe_json_response(['status' => 'error', 'message' => 'Пустое сообщение'], 400);
    }

    $messageToSave = $messageCipher !== '' ? $messageCipher : $plainFallback;

    $updStmt = $pdo->prepare("
        UPDATE private_messages
        SET message = :message,
            is_encrypted = :is_encrypted,
            message_salt = '',
            message_iv = :message_iv,
            is_edited = 1,
            edited_at = NOW()
        WHERE id = :id
          AND sender = :sender
          AND receiver = :receiver
          AND COALESCE(hidden_by_sender, 0) = 0
    ");
    $updStmt->execute([
        'message'      => $messageToSave,
        'is_encrypted' => $isEncrypted,
        'message_iv'   => $messageIv ?: null,
        'id'           => $messageId,
        'sender'       => $currentUser,
        'receiver'     => $otherUser
    ]);

    safe_json_response(['status' => 'success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');

    $messageCipher = trim($_POST['message_cipher'] ?? '');
    $messageIv = trim($_POST['message_iv'] ?? '');
    $plainFallback = trim($_POST['message'] ?? '');
    $forwardedFrom = isset($_POST['forwarded_from']) ? trim($_POST['forwarded_from']) : null;

    if ($forwardedFrom === '') {
        $forwardedFrom = null;
    }

    $filePath = null;
    $fileType = null;
    $originalName = null;
    $fileIv = trim($_POST['file_iv'] ?? '');
    $originalMime = trim($_POST['original_mime'] ?? '');
    $isEncrypted = 0;

    $ttlSeconds = isset($_POST['ttl_seconds']) ? (int)$_POST['ttl_seconds'] : 0;
    $allowedTtl = [0, 60, 300, 900, 3600, 86400];
    if (!in_array($ttlSeconds, $allowedTtl, true)) {
        $ttlSeconds = 0;
    }
    $expiresAt = $ttlSeconds > 0 ? date('Y-m-d H:i:s', time() + $ttlSeconds) : null;

    $replyToId = isset($_POST['reply_to_id']) ? (int)$_POST['reply_to_id'] : null;
    if ($replyToId <= 0) $replyToId = null;

    if ($messageCipher !== '') {
        if (!e2ee_is_base64($messageCipher) || !e2ee_is_base64($messageIv)) {
            safe_json_response(['status' => 'error', 'message' => 'Некорректные данные шифрования'], 400);
        }
        $isEncrypted = 1;
    }

    if (isset($_FILES['media']) && $_FILES['media']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['media']['error'] !== UPLOAD_ERR_OK) {
            safe_json_response(['status' => 'error', 'message' => 'Ошибка загрузки файла'], 400);
        }

        $tmpName = $_FILES['media']['tmp_name'];
        $originalName = $_POST['original_name'] ?? $_FILES['media']['name'];

        if ($fileIv !== '' || $originalMime !== '') {
            if (!e2ee_is_base64($fileIv)) {
                safe_json_response(['status' => 'error', 'message' => 'Некорректные параметры файла'], 400);
            }

            $storedName = random_name('msg_', 'bin');
            $destination = $uploadDir . $storedName;

            if (!move_uploaded_file($tmpName, $destination)) {
                safe_json_response(['status' => 'error', 'message' => 'Не удалось сохранить файл'], 500);
            }

            $filePath = $uploadUrl . $storedName;
            $fileType = 'application/e2ee';
            $isEncrypted = 1;
        } else {
            safe_json_response(['status' => 'error', 'message' => 'Файл должен быть зашифрован на клиенте'], 400);
        }
    }

    if ($plainFallback === '' && $messageCipher === '' && !$filePath) {
        safe_json_response(['status' => 'error', 'message' => 'Пустое сообщение'], 400);
    }

    $messageToSave = $messageCipher !== '' ? $messageCipher : $plainFallback;

    $stmt = $pdo->prepare("
        INSERT INTO private_messages (
            sender, receiver, message, file_path, file_type, original_name,
            is_encrypted, message_salt, message_iv, file_salt, file_iv, original_mime,
            is_read, expires_at, hidden_by_sender, hidden_by_receiver, reply_to_id, forwarded_from
        )
        VALUES (
            :sender, :receiver, :message, :file_path, :file_type, :original_name,
            :is_encrypted, '', :message_iv, '', :file_iv, :original_mime,
            0, :expires_at, 0, 0, :reply_to_id, :forwarded_from
        )
    ");
    $stmt->execute([
        'sender'        => $currentUser,
        'receiver'      => $otherUser,
        'message'       => $messageToSave,
        'file_path'     => $filePath,
        'file_type'     => $fileType,
        'original_name' => $originalName,
        'is_encrypted'  => $isEncrypted,
        'message_iv'    => $messageIv ?: null,
        'file_iv'       => $fileIv ?: null,
        'original_mime' => $originalMime ?: null,
        'expires_at'    => $expiresAt,
        'reply_to_id'   => $replyToId,
        'forwarded_from'=> $forwardedFrom
    ]);

    $pushText = $messageCipher !== '' ? '🔐 Получено защищенное сообщение' : $plainFallback;
    if ($filePath) {
        $pushText = '📎 Отправлен файл: ' . ($originalName ?: 'вложение');
    }
    
    if (!isReceiverInChat($currentUser, $otherUser)) {
        sendMedianOneSignalPush($currentUser, $otherUser, $pushText);
    }

    safe_json_response(['status' => 'success']);
}

if (isset($_GET['fetch'])) {
    deleteFullyHiddenMessages($pdo);
    deleteExpiredMessages($pdo);

    $beforeId = isset($_GET['before_id']) ? (int)$_GET['before_id'] : 0;
    $limit = 30;
    $visibleWhere = dialogVisibleWhere();

    if ($beforeId > 0) {
        $sql = "
            SELECT id, sender, message, created_at, file_path, file_type, original_name,
                   is_encrypted, message_salt, message_iv, file_salt, file_iv, original_mime,
                   is_read, expires_at, is_edited, edited_at, reply_to_id, forwarded_from
            FROM private_messages
            WHERE {$visibleWhere}
              AND id < :beforeId
              AND (expires_at IS NULL OR expires_at > NOW())
            ORDER BY id DESC
            LIMIT :limit
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':currentUser', $currentUser, PDO::PARAM_STR);
        $stmt->bindValue(':otherUser', $otherUser, PDO::PARAM_STR);
        $stmt->bindValue(':beforeId', $beforeId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $messages = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
    } else {
        $sql = "
            SELECT id, sender, message, created_at, file_path, file_type, original_name,
                   is_encrypted, message_salt, message_iv, file_salt, file_iv, original_mime,
                   is_read, expires_at, is_edited, edited_at, reply_to_id, forwarded_from
            FROM private_messages
            WHERE {$visibleWhere}
              AND (expires_at IS NULL OR expires_at > NOW())
            ORDER BY id DESC
            LIMIT :limit
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':currentUser', $currentUser, PDO::PARAM_STR);
        $stmt->bindValue(':otherUser', $otherUser, PDO::PARAM_STR);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $messages = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    $msgIds = array_map('intval', array_column($messages, 'id'));
    $reactionsMap = [];
    $repliesMap = [];

    if (!empty($msgIds)) {
        try {
            $inClause = implode(',', $msgIds);
            $reactStmt = $pdo->query("SELECT message_id, username, reaction FROM message_reactions WHERE message_id IN ($inClause)");
            while ($r = $reactStmt->fetch(PDO::FETCH_ASSOC)) {
                $reactionsMap[$r['message_id']][] = $r;
            }
        } catch (PDOException $e) {}

        $replyToIds = array_filter(array_map(function($m) { return isset($m['reply_to_id']) ? (int)$m['reply_to_id'] : 0; }, $messages));
        if (!empty($replyToIds)) {
            try {
                $replyInClause = implode(',', $replyToIds);
                $replyStmt = $pdo->query("SELECT id, sender, message, is_encrypted, message_salt, message_iv FROM private_messages WHERE id IN ($replyInClause)");
                while ($rp = $replyStmt->fetch(PDO::FETCH_ASSOC)) {
                    $repliesMap[$rp['id']] = $rp;
                }
            } catch (PDOException $e) {}
        }
    }

    foreach ($messages as &$m) {
        $mId = (int)$m['id'];
        $m['reactions'] = $reactionsMap[$mId] ?? [];
        $m['reply_to_msg'] = null;
        if (!empty($m['reply_to_id']) && isset($repliesMap[$m['reply_to_id']])) {
            $m['reply_to_msg'] = $repliesMap[$m['reply_to_id']];
        }
    }
    unset($m);

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($messages, JSON_UNESCAPED_UNICODE);
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Чат: <?= htmlspecialchars($otherUser) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --bg: #e7ebf0;
            --card: #ffffff;
            --border: #e4e7eb;
            --primary: #3390ec;
            --primary-hover: #2b7ecf;
            --text: #1f2937;
            --text-dark: #0f172a;
            --muted: #707579;
            --read-blue: #4faeef;
            --tick-muted: #a1aab3;
            --mine-bg: #d9fdd3;
            --mine-border: rgba(0, 0, 0, 0.04);
            --other-bg: #ffffff;
            --other-border: rgba(0, 0, 0, 0.04);
            --gold: #d97706;
            --gold2: #b45309;
            --blue: #3390ec;
            --shadow: 0 1px 2px rgba(16,22,26,0.08);
            --safe-top: env(safe-area-inset-top);
            --safe-bottom: env(safe-area-inset-bottom);
        }
        
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overscroll-behavior-y: contain;
            overscroll-behavior: none;
            background: #dfe3e6;
        }

        * {
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            min-height: 100dvh;
            display: flex;
            justify-content: center;
            align-items: stretch;
            padding: 0;
            color: var(--text-dark);
            overflow: hidden;
        }

        /* Боковое меню в Telegram-стиле */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 290px;
            height: 100%;
            background: #ffffff;
            box-shadow: 0 0 16px rgba(0,0,0,0.15);
            transform: translateX(-100%);
            transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }
        .sidebar.active {
            transform: translateX(0);
        }
        .overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.3);
            opacity: 0;
            visibility: hidden;
            transition: 0.2s ease-in-out;
            z-index: 950;
            backdrop-filter: blur(1px);
        }
        .overlay.active {
            opacity: 1;
            visibility: visible;
        }
        .sidebar-profile {
            background: linear-gradient(135deg, #2b7ecf, #3390ec);
            padding: 24px 20px 20px;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            gap: 12px;
            position: relative;
        }
        .sidebar-close-btn {
            position: absolute;
            top: 16px;
            right: 16px;
            background: transparent;
            border: none;
            color: rgba(255,255,255,0.8);
            font-size: 16px;
            cursor: pointer;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        .sidebar-close-btn:hover {
            background: rgba(255,255,255,0.1);
        }
        .sidebar-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            overflow: hidden;
            background: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .sidebar-avatar > * {
            width: 100% !important;
            height: 100% !important;
        }
        .sidebar-avatar img, .sidebar-avatar svg {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
        }
        .sidebar-user-info {
            display: flex;
            flex-direction: column;
        }
        .sidebar-user {
            font-size: 15px;
            font-weight: 600;
            color: #ffffff;
        }
        .sidebar-role {
            font-size: 12px;
            color: rgba(255,255,255,0.75);
        }
        .sidebar-menu {
            list-style: none;
            padding: 8px 0;
            margin: 0;
            overflow-y: auto;
            flex: 1;
        }
        .sidebar-menu li {
            margin: 0;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 12px 20px;
            text-decoration: none;
            color: #333333;
            font-weight: 500;
            font-size: 14px;
            transition: background 0.15s;
        }
        .sidebar-menu a:hover {
            background: #f1f5f9;
        }
        .sidebar-menu a.active {
            background: #f0f7fc;
            color: var(--primary);
        }
        .sidebar-menu a i {
            font-size: 16px;
            color: #707579;
            width: 24px;
            text-align: center;
        }

        /* Главная обертка чата */
        .wrap {
            width: 100%;
            max-width: 900px;
            height: 100dvh;
            display: flex;
            flex-direction: column;
            background: var(--bg);
            padding-top: var(--safe-top);
            padding-bottom: var(--safe-bottom);
            position: relative;
            z-index: 1;
            box-shadow: 0 12px 28px rgba(0,0,0,0.05);
        }

        /* Шапка в стиле Telegram */
        .top-header-container {
            display: flex;
            flex-direction: column;
            background: #ffffff;
            border-bottom: 1px solid rgba(0,0,0,0.08);
            z-index: 10;
            flex-shrink: 0;
        }
        .top {
            padding: 8px 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .menu-btn-inline {
            border: none;
            border-radius: 50%;
            background: transparent;
            color: var(--muted);
            font-size: 18px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.15s;
        }
        .menu-btn-inline:hover {
            background: #f1f5f9;
            color: var(--text-dark);
        }
        .top-user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
            cursor: pointer;
            min-width: 0;
            padding: 4px 8px;
            border-radius: 20px;
            transition: background 0.15s;
        }
        .top-user-info:hover {
            background: #f5f6f7;
        }
        .top-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            overflow: hidden;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .top-avatar img, .top-avatar svg {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .top-user-details {
            display: flex;
            flex-direction: column;
            min-width: 0;
            flex: 1;
        }
        .top-user-details h1 {
            margin: 0;
            font-size: 14.5px;
            font-weight: 600;
            color: var(--text-dark);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space:nowrap;
        }
        
        /* Выдвижная панель детальной информации как в Telegram (выезжает справа) */
        .expand-panel {
            position: fixed;
            top: 0;
            right: 0;
            width: 320px;
            height: 100dvh;
            background: #ffffff;
            box-shadow: -4px 0 24px rgba(0,0,0,0.15);
            transform: translateX(100%);
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1200; /* Выше оверлея (950) и бокового меню (1000) */
            display: flex;
            flex-direction: column;
            border-left: 1px solid var(--border);
            padding-bottom: var(--safe-bottom);
        }
        .expand-panel.active {
            transform: translateX(0);
        }
        .expand-panel-header {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px 20px;
            border-bottom: 1px solid rgba(0,0,0,0.06);
        }
        .expand-panel-close {
            background: transparent;
            border: none;
            color: var(--muted);
            font-size: 18px;
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            transition: background 0.15s;
        }
        .expand-panel-close:hover {
            background: #f1f5f9;
            color: var(--text-dark);
        }
        .expand-panel-title {
            font-size: 15px;
            font-weight: 700;
            color: var(--text-dark);
        }
        .expand-panel-content {
            flex: 1;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            padding: 24px 20px;
            gap: 20px;
            align-items: center;
        }
        .expand-avatar-large {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            overflow: hidden;
            border: 2px solid var(--primary);
            box-shadow: 0 4px 12px rgba(51,144,236,0.15);
            margin-bottom: 8px;
        }
        .expand-avatar-large img, .expand-avatar-large svg {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .expand-panel-content h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
            color: var(--text-dark);
            text-align: center;
        }
        .info-rows {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 16px;
            border-top: 1px solid rgba(0,0,0,0.05);
            padding-top: 20px;
        }
        .info-row-item {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .info-row-item i {
            font-size: 16px;
            color: var(--muted);
            width: 24px;
            text-align: center;
        }
        .info-row-details {
            display: flex;
            flex-direction: column;
        }
        .info-row-val {
            font-size: 13.5px;
            font-weight: 600;
            color: var(--text-dark);
        }
        .info-row-lbl {
            font-size: 11px;
            color: var(--muted);
        }

        /* Индикатор набора сообщения в стиле Telegram */
        .typing-status {
            display: flex;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            padding: 0 16px;
            align-items: center;
            gap: 6px;
            color: var(--primary);
            font-size: 12px;
            font-weight: 500;
            flex-shrink: 0;
            transition: opacity 0.2s, max-height 0.2s, padding 0.2s;
            background: #ffffff;
            border-bottom: 1px solid rgba(0,0,0,0.04);
        }
        .typing-status.active {
            opacity: 1;
            max-height: 30px;
            padding: 6px 16px;
        }
        .typing-bubbles {
            display: inline-flex;
            gap: 3px;
            align-items: center;
        }
        .typing-bubbles span {
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: var(--primary);
            opacity: 0.7;
            animation: typingPulse 1.2s infinite ease-in-out;
        }
        .typing-bubbles span:nth-child(2) { animation-delay: 0.15s; }
        .typing-bubbles span:nth-child(3) { animation-delay: 0.3s; }
        @keyframes typingPulse {
            0%, 80%, 100% { transform: translateY(0); opacity: 0.3; }
            40% { transform: translateY(-3px); opacity: 1; }
        }

        /* Окно сообщений с Telegram-сеткой на фоне */
        .dialog-box {
            flex: 1;
            min-height: 0;
            overflow-y: auto;
            padding: 16px 20px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            background-color: var(--bg);
            background-image: radial-gradient(rgba(0,0,0,0.035) 1px, transparent 1.5px);
            background-size: 18px 18px;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior-y: contain;
        }
        .dialog-box::-webkit-scrollbar {
            width: 4px;
        }
        .dialog-box::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.15);
            border-radius: 999px;
        }

        /* Облачка сообщений */
        @keyframes msgSlideIn {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes flashBg {
            0% { background-color: rgba(251,191,36,0.35); }
            100% { background-color: transparent; }
        }
        .msg {
            max-width: 72%;
            padding: 8px 12px 6px;
            font-size: 14px;
            position: relative;
            word-wrap: break-word;
            color: #000000;
            line-height: 1.4;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.08);
            transition: opacity 0.15s ease;
            cursor: pointer;
        }
        .msg.animate-in {
            animation: msgSlideIn 0.2s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
        }
        .msg.highlight-flash {
            animation: flashBg 1.2s ease-out;
        }
        .mine {
            align-self: flex-end;
            background: var(--mine-bg);
            border: 1px solid var(--mine-border);
            border-radius: 12px 12px 4px 12px;
        }
        .other {
            align-self: flex-start;
            background: var(--other-bg);
            border: 1px solid var(--other-border);
            border-radius: 12px 12px 12px 4px;
        }
        .msg .msg-body {
            display: block;
        }

        /* Временная строка внутри сообщений */
        .time-row {
            display: inline-flex;
            align-items: center;
            justify-content: flex-end;
            gap: 4px;
            float: right;
            margin: 4px -4px -3px 8px;
            font-size: 10px;
            color: var(--muted);
            user-select: none;
            pointer-events: none;
        }
        .mine .time-row {
            color: #53a362;
        }
        .time {
            font-weight: 500;
        }
        .edited-mark {
            font-style: italic;
        }
        
        /* Галочки прочтения */
        .ticks {
            display: inline-flex;
            align-items: center;
            width: 14px;
            height: 9px;
        }
        .ticks svg {
            width: 100%;
            height: 100%;
            fill: none;
            stroke-width: 2.2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }
        .ticks.sent svg {
            stroke: #53a362;
        }
        .ticks.read svg {
            stroke: #4faeef;
        }
        .expire-badge {
            font-size: 9px;
            color: var(--gold2);
            background: rgba(216,180,106,0.15);
            padding: 1px 5px;
            border-radius: 4px;
            font-weight: 600;
        }

        /* Изображения в сообщениях */
        .chat-image-container {
            max-width: 320px;
            max-height: 240px;
            overflow: hidden;
            border-radius: 8px;
            margin-top: 5px;
            border: 1px solid rgba(0,0,0,0.04);
            background: rgba(0,0,0,0.02);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .image-placeholder {
            font-size: 11px;
            color: var(--muted);
            padding: 12px;
        }
        .chat-inline-image {
            width: 100%;
            height: auto;
            max-height: 240px;
            object-fit: cover;
            cursor: pointer;
            display: block;
        }

        /* Цитаты ответов в стиле Telegram */
        .reply-quote {
            background: rgba(0,0,0,0.02);
            border-left: 2.5px solid var(--primary);
            padding: 2px 8px;
            margin-bottom: 5px;
            border-radius: 2px;
            font-size: 12px;
            cursor: pointer;
            transition: background 0.1s;
        }
        .mine .reply-quote {
            border-left-color: #53a362;
            background: rgba(0,0,0,0.015);
        }
        .reply-sender {
            font-weight: 600;
            color: var(--primary);
            font-size: 11px;
            margin-bottom: 1px;
        }
        .mine .reply-sender {
            color: #438f4d;
        }
        .reply-body-text {
            color: #4b5563;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Реакции */
        .reactions-wrapper {
            display: flex;
            gap: 4px;
            flex-wrap: wrap;
            margin-top: 5px;
        }
        .reaction-pill {
            display: inline-flex;
            align-items: center;
            gap: 3px;
            background: rgba(0,0,0,0.03);
            border: 1px solid rgba(0,0,0,0.02);
            padding: 1px 5px;
            border-radius: 10px;
            font-size: 11px;
            cursor: pointer;
            transition: background 0.15s;
        }
        .reaction-pill:hover {
            background: rgba(0,0,0,0.06);
        }
        .reaction-pill.active {
            background: #e1f3fc;
            border-color: #b3e5fc;
            color: var(--primary);
            font-weight: 600;
        }

        /* Панель превью отправки файлов */
        #filePreview {
            background: #ffffff;
            padding: 8px 16px;
            display: none;
            border-top: 1px solid var(--border);
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
            font-size: 12px;
        }
        .file-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-dark);
            font-weight: 500;
        }
        .cancel-file {
            color: #ef4444;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
        }

        /* Область ввода — «парящее» поле ввода как в Telegram */
        .input-area {
            background: var(--bg);
            padding: 8px 12px calc(8px + var(--safe-bottom));
            position: relative;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .input-wrapper {
            display: flex;
            gap: 8px;
            align-items: flex-end;
            max-width: 100%;
        }
        
        /* Текстовое поле */
        .input-box-container {
            flex: 1;
            background: #ffffff;
            border-radius: 20px;
            border: 1px solid rgba(0,0,0,0.06);
            display: flex;
            align-items: flex-end;
            padding: 4px 12px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .attach-btn, .emoji-btn {
            color: var(--muted);
            cursor: pointer;
            padding: 8px 4px;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.15s;
        }
        .attach-btn:hover, .emoji-btn:hover {
            color: var(--primary);
        }
        textarea {
            flex: 1;
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 14.5px;
            padding: 8px 6px;
            resize: none;
            max-height: 140px;
            outline: none;
            line-height: 1.35;
            min-height: 34px;
        }
        textarea::placeholder {
            color: #a1aab3;
        }

        /* Круглая Telegram-кнопка отправки */
        .send-btn {
            background: var(--primary);
            border: none;
            width: 42px;
            height: 42px;
            color: #ffffff;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            border-radius: 50%;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            transition: background 0.15s, transform 0.1s;
        }
        .send-btn:hover {
            background: var(--primary-hover);
        }
        .send-btn:active {
            transform: scale(0.95);
        }
        .send-btn:disabled {
            background: #cbd5e1;
            cursor: not-allowed;
            transform: none;
        }
        .send-btn svg {
            width: 18px;
            height: 18px;
            fill: currentColor;
            transform: rotate(0deg);
        }

        .loader {
            text-align: center;
            color: var(--muted);
            font-size: 11px;
            padding: 6px 0;
            display: none;
            font-weight: 500;
        }
        .progress-container {
            height: 2px;
            width: 100%;
            background: rgba(0,0,0,0.05);
            position: absolute;
            top: 0;
            left: 0;
            display: none;
        }
        #formProgress {
            height: 100%;
            width: 0%;
            background: var(--primary);
            transition: width 0.2s;
        }
        .file-link {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
            background: rgba(51,144,236,0.08);
            border: 1px solid rgba(51,144,236,0.15);
            padding: 4px 10px;
            border-radius: 8px;
            margin-top: 4px;
            display: inline-block;
            font-size: 12px;
            transition: background 0.1s;
        }
        .file-link:hover {
            background: rgba(51,144,236,0.12);
        }

        /* Панель эмодзи */
        .emoji-panel {
            display: none;
            gap: 6px;
            flex-wrap: wrap;
            padding: 8px 4px;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid rgba(0,0,0,0.06);
            margin-top: 4px;
        }
        .emoji-panel button {
            border: none;
            background: transparent;
            font-size: 18px;
            cursor: pointer;
            padding: 4px;
            border-radius: 6px;
            transition: background 0.15s;
        }
        .emoji-panel button:hover {
            background: #f1f5f9;
        }

        /* Выбор TTL */
        .ttl-row {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 0 4px;
            color: var(--muted);
            font-size: 11px;
            font-weight: 500;
        }
        .ttl-row select {
            background: #ffffff;
            color: var(--text-dark);
            border: 1px solid rgba(0,0,0,0.06);
            border-radius: 6px;
            padding: 2px 6px;
            outline: none;
            cursor: pointer;
        }

        /* Разделители дат */
        .date-separator {
            align-self: center;
            margin: 12px 0;
            padding: 3px 12px;
            font-size: 11px;
            font-weight: 600;
            color: #ffffff;
            background: rgba(112, 117, 121, 0.45);
            border-radius: 12px;
            user-select: none;
            backdrop-filter: blur(2px);
        }

        /* Контекстное меню */
        .ctx-menu {
            position: fixed;
            display: none;
            background: rgba(255, 255, 255, 0.94);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            box-shadow: 0 4px 18px rgba(0,0,0,0.12);
            z-index: 1500;
            min-width: 170px;
            padding: 4px;
            animation: scaleInMenu 0.12s cubic-bezier(0.1, 0.9, 0.2, 1) forwards;
        }
        @keyframes scaleInMenu {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .ctx-menu button {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            background: transparent;
            border: none;
            color: var(--text-dark);
            padding: 8px 12px;
            font-size: 13px;
            font-weight: 500;
            text-align: left;
            cursor: pointer;
            border-radius: 8px;
            transition: background 0.1s;
        }
        .ctx-menu button:hover {
            background: rgba(0,0,0,0.04);
        }
        .quick-reactions {
            display: flex;
            justify-content: space-around;
            padding: 4px;
        }
        .quick-reactions span {
            font-size: 18px;
            cursor: pointer;
            transition: transform 0.1s;
        }
        .quick-reactions span:hover {
            transform: scale(1.2);
        }

        /* Бары редактирования и ответа */
        .edit-bar {
            display: none;
            align-items: center;
            gap: 10px;
            background: #ffffff;
            border-left: 2.5px solid var(--primary);
            padding: 6px 12px;
            border-radius: 6px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.02);
            margin-bottom: 2px;
        }
        .edit-bar.active {
            display: flex;
        }
        .edit-bar-info {
            flex: 1;
            min-width: 0;
            font-size: 12px;
            color: var(--muted);
        }
        .edit-bar-info b {
            color: var(--primary);
            display: block;
            font-size: 11px;
            font-weight: 600;
            margin-bottom: 1px;
        }
        .edit-bar-cancel {
            color: var(--muted);
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            padding: 2px 6px;
        }
        .edit-bar-cancel:hover {
            color: #ef4444;
        }

        /* Встроенная панель пересылки (Bottom Sheet стиль) */
        .forward-panel {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: #ffffff;
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
            border-top: 1px solid var(--border);
            z-index: 110;
            display: none;
            flex-direction: column;
            max-height: 50dvh;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.08);
            animation: slideUp 0.2s cubic-bezier(0.1, 0.9, 0.2, 1);
            padding-bottom: var(--safe-bottom);
        }
        @keyframes slideUp {
            from { transform: translateY(100%); }
            to { transform: translateY(0); }
        }
        .forward-panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            border-bottom: 1px solid rgba(0,0,0,0.04);
        }
        .forward-panel-title {
            font-size: 13.5px;
            font-weight: 600;
            color: var(--text-dark);
        }
        .forward-panel-close {
            color: #ef4444;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            background: rgba(239,68,68,0.06);
            border: 1px solid rgba(239,68,68,0.15);
            padding: 4px 10px;
            border-radius: 8px;
        }
        .forward-panel-list {
            flex: 1;
            overflow-y: auto;
            padding: 6px;
            background: #ffffff;
        }
        .forward-tabs {
            display: flex;
            gap: 4px;
            padding: 6px 16px;
            background: #ffffff;
            border-bottom: 1px solid rgba(0,0,0,0.04);
        }
        .forward-tab-btn {
            flex: 1;
            border: none;
            padding: 6px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 12px;
            cursor: pointer;
            background: transparent;
            color: var(--muted);
            transition: all 0.1s;
        }
        .forward-tab-btn.active {
            background: rgba(51,144,236,0.08);
            color: var(--primary);
        }
        .forward-contact-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 8px;
            transition: background 0.1s;
        }
        .forward-contact-item:hover {
            background: #f1f5f9;
        }
        .forward-contact-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            overflow: hidden;
            background: #f1f5f9;
        }
        .forward-contact-avatar > * {
            width: 100% !important;
            height: 100% !important;
        }
        .forward-contact-name {
            font-size: 13px;
            font-weight: 500;
            color: var(--text-dark);
        }

        .copy-success {
            position: fixed;
            bottom: 80px;
            left: 50%;
            transform: translate(-50%, 0);
            background: rgba(31, 41, 55, 0.95);
            color: #ffffff;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            z-index: 99999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: toastFadeIn 0.2s ease, toastFadeOut 0.2s ease 1.8s forwards;
        }
        @keyframes toastFadeIn { from { opacity: 0; transform: translate(-50%, 8px); } to { opacity: 1; transform: translate(-50%, 0); } }
        @keyframes toastFadeOut { from { opacity: 1; transform: translate(-50%, 0); } to { opacity: 0; transform: translate(-50%, -8px); } }

        @media (max-width: 600px) {
            .wrap {
                max-width: 100%;
                box-shadow: none;
            }
            .msg {
                max-width: 82%;
            }
            .dialog-box {
                padding: 12px;
            }
        }
    </style>
</head>
<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="wrap">
    
    <div class="top-header-container">
        <div class="top">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="top-user-info" id="topUserInfo">
                <div class="top-avatar">
                    <?= renderAvatar($otherUserAvatarType, $otherUser) ?>
                </div>
                <div class="top-user-details">
                    <h1><?= htmlspecialchars($otherUser) ?></h1>
                    <span style="font-size: 11px; color: var(--muted);" id="onlineBadge">был недавно</span>
                </div>
            </div>
        </div>
    </div>

    <div class="typing-status" id="typingStatus">
        <span class="typing-bubbles"><span></span><span></span><span></span></span>
        <span id="typingText">Собеседник печатает...</span>
    </div>

    <div class="dialog-box" id="dialogBox">
        <div class="loader" id="loaderTop">Загрузка истории...</div>
    </div>

    <div id="filePreview">
        <div class="file-info">
            <span id="previewName">file.dat</span>
            <span id="previewSize" style="opacity: 0.6;">0 KB</span>
        </div>
        <div class="cancel-file" id="cancelFile">×</div>
    </div>

    <!-- ВСТРОЕННАЯ ПАНЕЛЬ ПЕРЕСЫЛКИ (ВНУТРИ ДИАЛОГА) -->
    <div class="forward-panel" id="forwardPanel">
        <div class="forward-panel-header">
            <span class="forward-panel-title">↗️ Переслать сообщение</span>
            <button type="button" class="forward-panel-close" id="forwardCancelBtn">Отмена</button>
        </div>
        
        <div class="forward-tabs">
            <button type="button" class="forward-tab-btn active" id="forwardTabDialogs">💬 Диалоги</button>
            <button type="button" class="forward-tab-btn" id="forwardTabContacts">👥 Контакты</button>
        </div>

        <div class="forward-panel-list" id="forwardContactsList">
            <div style="text-align: center; padding: 20px; color: var(--muted); font-weight: 600;">Загрузка...</div>
        </div>
    </div>

    <!-- ОГРАНИЧЕНИЕ НА ОТПРАВКУ СООБЩЕНИЙ СИСТЕМЕ -->
    <?php if ($otherUser === 'Система'): ?>
        <div style="background: #ffffff; padding: 16px; border-top: 1px solid var(--border); text-align: center; font-size: 13px; font-weight: 500; color: var(--muted); padding-bottom: calc(16px + var(--safe-bottom));">
            📢 Это официальный информационный канал системы. Отвечать на сообщения нельзя.
        </div>
    <?php else: ?>
        <div class="input-area">
            <div class="progress-container" id="progCont">
                <div id="formProgress"></div>
            </div>

            <div class="edit-bar" id="editBar">
                <div class="edit-bar-info">
                    <b>Редактирование сообщения</b>
                    <span id="editBarText"></span>
                </div>
                <div class="edit-bar-cancel" id="editBarCancel">×</div>
            </div>

            <div class="edit-bar" id="replyBar" style="display:none; border-left-color: #22c55e;">
                <div class="edit-bar-info">
                    <b style="color:#22c55e;">Ответ на сообщение</b>
                    <span id="replyBarText" style="color:var(--muted); font-size:12px;"></span>
                </div>
                <div class="edit-bar-cancel" id="replyBarCancel">×</div>
            </div>

            <div class="ttl-row">
                <label for="ttlSelect">Удаление через:</label>
                <select id="ttlSelect">
                    <option value="0" selected>Не удалять</option>
                    <option value="60">1 минуту</option>
                    <option value="300">5 минут</option>
                    <option value="900">15 минут</option>
                    <option value="3600">1 час</option>
                    <option value="86400">24 часа</option>
                </select>
            </div>

            <form id="msgForm">
                <div class="input-wrapper">
                    <div class="input-box-container">
                        <label class="attach-btn">
                            <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.66 1.34 3 3 3s3-1.34 3-3V5c0-2.21-1.79-4-4-4S8 2.79 8 5v12.5c0 3.31 2.69 6 6 6s6-2.69 6-6V6h-1.5z"/></svg>
                            <input type="file" id="mediaInput" style="display:none">
                        </label>
                        <textarea id="msgInput" placeholder="Сообщение..." rows="1"></textarea>
                        <div class="emoji-btn" id="emojiBtn">😊</div>
                    </div>
                    <button type="submit" class="send-btn" id="sendBtn">
                        <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                    </button>
                </div>

                <div class="emoji-panel" id="emojiPanel">
                    <button type="button">😀</button><button type="button">😁</button><button type="button">😂</button><button type="button">🤣</button>
                    <button type="button">😊</button><button type="button">😍</button><button type="button">😘</button><button type="button">😎</button>
                    <button type="button">🤔</button><button type="button">😢</button><button type="button">😡</button><button type="button">❤️</button>
                    <button type="button">👍</button><button type="button">🙏</button><button type="button">🔥</button><button type="button">✨</button>
                </div>
            </form>
        </div>
    <?php endif; ?>
</div>

<!-- ТЕЛЕГРАМ-ПАНЕЛЬ СВЕДЕНИЙ О ПОЛЬЗОВАТЕЛЕ (ВЫНЕСЕНА ИЗ .WRAP ДЛЯ ИСПРАВЛЕНИЯ НАЛОЖЕНИЯ И РАЗМЫТИЯ) -->
<div class="expand-panel" id="expandPanel">
    <div class="expand-panel-header">
        <button class="expand-panel-close" id="expandPanelCloseBtn">
            <i class="fa-solid fa-xmark"></i>
        </button>
        <span class="expand-panel-title">Информация</span>
    </div>
    <div class="expand-panel-content">
        <div class="expand-avatar-large">
            <?= renderAvatar($otherUserAvatarType, $otherUser) ?>
        </div>
        <h3><?= htmlspecialchars($otherUser) ?></h3>
        
        <div class="info-rows">
            <div class="info-row-item">
                <i class="fa-solid fa-at"></i>
                <div class="info-row-details">
                    <span class="info-row-val">@<?= htmlspecialchars($otherUser) ?></span>
                    <span class="info-row-lbl">Имя пользователя</span>
                </div>
            </div>
            
            <div class="info-row-item">
                <i class="fa-solid fa-venus-mars"></i>
                <div class="info-row-details">
                    <span class="info-row-val"><?= htmlspecialchars($genderName) ?></span>
                    <span class="info-row-lbl">Пол</span>
                </div>
            </div>

            <div class="info-row-item">
                <i class="fa-solid fa-shield-halved"></i>
                <div class="info-row-details">
                    <span class="info-row-val"><?= htmlspecialchars($otherRoleName) ?></span>
                    <span class="info-row-lbl">Роль</span>
                </div>
            </div>
        </div>

        <div class="expand-actions" style="margin-top: 20px; display: flex; flex-direction: column; width: 100%; gap: 10px;">
            <button id="toggleContactBtn" class="<?= $isContact ? 'badge-status' : 'btn-action' ?>" style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 8px; border: 1px solid <?= $isContact ? '#bbdefb' : 'transparent' ?>; width: 100%; border-radius: 10px; padding: 11px 16px; font-size: 13.5px; font-weight: 600; text-decoration: none; outline: none;">
                <?php if (!$isContact): ?>
                    <i class="fa-solid fa-user-plus"></i> Добавить в контакты
                <?php else: ?>
                    <i class="fa-solid fa-user-check"></i> В контактах
                <?php endif; ?>
            </button>
            <a href="messages.php" class="btn-action btn-secondary" style="display: inline-flex; align-items: center; justify-content: center; gap: 8px; width: 100%; border-radius: 10px; padding: 11px 16px; font-size: 13.5px; font-weight: 600; text-decoration: none; color: #3390ec !important; background: rgba(51,144,236,0.08); border: 1px solid rgba(51,144,236,0.15); transition: background 0.1s;">
                <i class="fa-solid fa-comments"></i> Все чаты
            </a>
        </div>
    </div>
</div>

<div class="ctx-menu" id="ctxMenu">
    <div class="quick-reactions">
        <span onclick="sendQuickReaction('👍')">👍</span>
        <span onclick="sendQuickReaction('❤️')">❤️</span>
        <span onclick="sendQuickReaction('🔥')">🔥</span>
        <span onclick="sendQuickReaction('😂')">😂</span>
        <span onclick="sendQuickReaction('😮')">😮</span>
        <span onclick="sendQuickReaction('😢')">😢</span>
    </div>
    <hr style="margin: 4px 0; border: none; border-top: 1px solid var(--border);">
    <button type="button" id="ctxReply">↩️ Ответить</button>
    <button type="button" id="ctxCopy">📋 Копировать</button>
    <button type="button" id="ctxForward">↗️ Переслать</button>
    <?php if ($otherUser !== 'Система'): ?>
        <button type="button" id="ctxEdit">✏️ Редактировать</button>
        <button type="button" id="ctxDelete" style="color:#ef4444;">🗑️ Удалить</button>
    <?php endif; ?>
</div>

<script>
    // === КОНФИГУРАЦИЯ ДВУХСТОРОННЕГО СКВОЗНОГО ШИФРОВАНИЯ (E2EE/ECDH) ===
    const otherUserPublicKeyJWK = <?= json_encode($otherUserPublicKey) ?>;
    const currentUsername = <?= json_encode($currentUser) ?>;
    const otherUser = <?= json_encode($otherUser) ?>;
    const otherUserGender = <?= json_encode($otherUserGender) ?>;
    let otherUserLastSeen = <?= json_encode($otherUserLastSeen ? strtotime($otherUserLastSeen) : null) ?>;

    const DB_E2EE_NAME = 'E2EE_Keys_DB_System';
    const DB_E2EE_VERSION = 1;
    const STORE_E2EE_NAME = 'key_store';

    // Объявление DOM-элементов
    const loaderTop = document.getElementById('loaderTop');
    const progCont = document.getElementById('progCont');
    const formProgress = document.getElementById('formProgress');
    const filePreview = document.getElementById('filePreview');
    const previewName = document.getElementById('previewName');
    const previewSize = document.getElementById('previewSize');
    const cancelFile = document.getElementById('cancelFile');
    const mediaInput = document.getElementById('mediaInput');
    const ttlSelect = document.getElementById('ttlSelect');
    const msgInput = document.getElementById('msgInput');
    const sendBtn = document.getElementById('sendBtn');
    const emojiBtn = document.getElementById('emojiBtn');
    const emojiPanel = document.getElementById('emojiPanel');
    const editBar = document.getElementById('editBar');
    const editBarText = document.getElementById('editBarText');
    const editBarCancel = document.getElementById('editBarCancel');
    const replyBar = document.getElementById('replyBar');
    const replyBarText = document.getElementById('replyBarText');
    const replyBarCancel = document.getElementById('replyBarCancel');
    const ctxMenu = document.getElementById('ctxMenu');
    
    // Элементы пересылки сообщений
    const forwardPanel = document.getElementById('forwardPanel');
    const forwardCancelBtn = document.getElementById('forwardCancelBtn');
    const forwardContactsList = document.getElementById('forwardContactsList');
    const forwardTabDialogs = document.getElementById('forwardTabDialogs');
    const forwardTabContacts = document.getElementById('forwardTabContacts');

    let activeCtxMsgId = null;
    let activeCtxMsgText = '';
    let activeCtxMsgIsMine = false;
    let activeCtxMsgHasFile = false;

    let forwardTargetsData = { contacts: [], dialogs: [] };
    let activeForwardTab = 'dialogs';
    let forwardMessageId = null;

    // Хранилище всех загруженных сообщений для перешифрования при пересылке
    const loadedMessagesMap = new Map();

    // Встроенный Web Audio синтезатор звуков
    const AudioSynth = {
        ctx: null,
        init() {
            if (!this.ctx) {
                this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            }
        },
        playSend() {
            try {
                this.init();
                if (this.ctx.state === 'suspended') this.ctx.resume();
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                
                osc.type = 'sine';
                osc.frequency.setValueAtTime(450, this.ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(1100, this.ctx.currentTime + 0.12);
                
                gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.12);
                
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                
                osc.start();
                osc.stop(this.ctx.currentTime + 0.12);
            } catch (e) { console.warn(e); }
        },
        playReceive() {
            try {
                this.init();
                if (this.ctx.state === 'suspended') this.ctx.resume();
                const osc1 = this.ctx.createOscillator();
                const osc2 = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                
                osc1.type = 'sine';
                osc1.frequency.setValueAtTime(880, this.ctx.currentTime); 
                osc1.frequency.exponentialRampToValueAtTime(1320, this.ctx.currentTime + 0.08);
                
                osc2.type = 'sine';
                osc2.frequency.setValueAtTime(1109, this.ctx.currentTime); 
                
                gain.gain.setValueAtTime(0.10, this.ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.25);
                
                osc1.connect(gain);
                osc2.connect(gain);
                gain.connect(this.ctx.destination);
                
                osc1.start();
                osc2.start();
                
                osc1.stop(this.ctx.currentTime + 0.25);
                osc2.stop(this.ctx.currentTime + 0.25);
            } catch (e) { console.warn(e); }
        }
    };

    function getE2EEDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_E2EE_NAME, DB_E2EE_VERSION);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(STORE_E2EE_NAME)) {
                    db.createObjectStore(STORE_E2EE_NAME);
                }
            };
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e.target.error);
        });
    }

    function getStoredKeys() {
        return new Promise(async (resolve) => {
            try {
                const db = await getE2EEDB();
                const transaction = db.transaction(STORE_E2EE_NAME, 'readonly');
                const store = transaction.objectStore(STORE_E2EE_NAME);
                const request = store.get('my_key_pair_' + currentUsername);
                request.onsuccess = () => resolve(request.result || null);
                request.onerror = () => resolve(null);
            } catch (e) { resolve(null); }
        });
    }

    function saveStoredKeys(keyPairJWK) {
        return new Promise(async (resolve) => {
            try {
                const db = await getE2EEDB();
                const transaction = db.transaction(STORE_E2EE_NAME, 'readwrite');
                const store = transaction.objectStore(STORE_E2EE_NAME);
                const request = store.put(keyPairJWK, 'my_key_pair_' + currentUsername);
                request.onsuccess = () => resolve(true);
                request.onerror = () => resolve(false);
            } catch (e) { resolve(false); }
        });
    }

    function arrayBufferToBase64(buffer) {
        let binary = '';
        const bytes = new Uint8Array(buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary);
    }

    function base64ToArrayBuffer(base64) {
        const binary_string = window.atob(base64);
        const len = binary_string.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    }

    const E2EE = {
        async encryptText(plainText, key) {
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const encoded = new TextEncoder().encode(plainText);
            const ciphertextBuffer = await window.crypto.subtle.encrypt(
                {
                    name: "AES-GCM",
                    iv: iv
                },
                key,
                encoded
            );

            return {
                ciphertext_b64: arrayBufferToBase64(ciphertextBuffer),
                iv_b64: arrayBufferToBase64(iv)
            };
        },

        async decryptText(encData, key) {
            const ciphertextBuffer = base64ToArrayBuffer(encData.ciphertext_b64);
            const iv = base64ToArrayBuffer(encData.iv_b64);
            const decryptedBuffer = await window.crypto.subtle.decrypt(
                {
                    name: "AES-GCM",
                    iv: iv
                },
                key,
                ciphertextBuffer
            );

            return new TextDecoder().decode(decryptedBuffer);
        },

        async encryptFile(file, key) {
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const arrayBuffer = await file.arrayBuffer();
            const ciphertextBuffer = await window.crypto.subtle.encrypt(
                {
                    name: "AES-GCM",
                    iv: iv
                },
                key,
                arrayBuffer
            );

            const encBlob = new Blob([ciphertextBuffer], { type: 'application/octet-stream' });
            return {
                blob: encBlob,
                meta: {
                    iv_b64: arrayBufferToBase64(iv),
                    original_mime: file.type,
                    original_name: file.name
                }
            };
        },

        async decryptFile(encryptedBuffer, meta, key) {
            const iv = base64ToArrayBuffer(meta.iv_b64);
            const decryptedBuffer = await window.crypto.subtle.decrypt(
                {
                    name: "AES-GCM",
                    iv: iv
                },
                key,
                encryptedBuffer
            );

            return new Blob([decryptedBuffer], { type: meta.original_mime || 'application/octet-stream' });
        }
    };

    let localCryptoKeyPair = null;
    let sharedDialogKey = null;

    async function initE2EE() {
        if (otherUser === 'Система') {
            return;
        }

        try {
            let keys = await getStoredKeys();
            
            if (!keys) {
                const keyPair = await window.crypto.subtle.generateKey(
                    {
                        name: "ECDH",
                        namedCurve: "P-256",
                    },
                    true,
                    ["deriveKey", "deriveBits"]
                );

                const publicKeyJwk = await window.crypto.subtle.exportKey("jwk", keyPair.publicKey);
                const privateKeyJwk = await window.crypto.subtle.exportKey("jwk", keyPair.privateKey);

                keys = {
                    publicKey: publicKeyJwk,
                    privateKey: privateKeyJwk
                };

                await saveStoredKeys(keys);
            }

            try {
                const formData = new FormData();
                formData.append('public_key', JSON.stringify(keys.publicKey));
                await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&save_public_key=1`, {
                    method: 'POST',
                    body: formData,
                    cache: 'no-store'
                });
            } catch (netErr) {
                console.warn("Сбой сети при синхронизации ключа:", netErr);
            }

            const importedPublicKey = await window.crypto.subtle.importKey(
                "jwk",
                keys.publicKey,
                { name: "ECDH", namedCurve: "P-256" },
                true,
                []
            );

            const importedPrivateKey = await window.crypto.subtle.importKey(
                "jwk",
                keys.privateKey,
                { name: "ECDH", namedCurve: "P-256" },
                true,
                ["deriveKey"]
            );

            localCryptoKeyPair = {
                publicKey: importedPublicKey,
                privateKey: importedPrivateKey
            };

            if (otherUserPublicKeyJWK) {
                try {
                    const otherPublicJwkParsed = JSON.parse(otherUserPublicKeyJWK);
                    const importedOtherPublicKey = await window.crypto.subtle.importKey(
                        "jwk",
                        otherPublicJwkParsed,
                        { name: "ECDH", namedCurve: "P-256" },
                        true,
                        []
                    );

                    sharedDialogKey = await window.crypto.subtle.deriveKey(
                        {
                            name: "ECDH",
                            public: importedOtherPublicKey
                        },
                        localCryptoKeyPair.privateKey,
                        {
                            name: "AES-GCM",
                            length: 256
                        },
                        false,
                        ["encrypt", "decrypt"]
                    );
                } catch (e) {
                    console.error("Ошибка импорта публичного ключа собеседника:", e);
                }
            }
        } catch (cryptoErr) {
            console.error("Сбой инициализации криптографии:", cryptoErr);
        }

        if (msgInput && sendBtn) {
            if (!sharedDialogKey) {
                msgInput.disabled = true;
                msgInput.placeholder = "🔐 Ожидание генерации ключей собеседником...";
                sendBtn.disabled = true;
            } else {
                msgInput.disabled = false;
                msgInput.placeholder = "Сообщение...";
                sendBtn.disabled = false;
            }
        }
    }

    let loadingOlder = false;
    let hasMoreOlder = true;
    let oldestMsgId = null;
    let newestMsgId = 0;
    let typingPollTimer = null;
    let typingState = false;
    let typingHideTimer = null;
    let typingSendTimer = null;
    let typingLastSent = 0;
    let lastHeartbeatSent = 0;
    let isTabActive = true; 

    let editingMessageId = null;
    let editingOriginalText = '';
    let replyingToId = null;

    let isFetchingNew = false;
    let needsRefetch = false;

    const decryptedCache = new Map();
    const imageBlobCache = new Map();

    const DB_NAME = 'ChatImageCache';
    const DB_VERSION = 1;
    const STORE_NAME = 'images';

    function getDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    db.createObjectStore(STORE_NAME);
                }
            };
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e.target.error);
        });
    }

    async function getCachedImage(id) {
        try {
            const db = await getDB();
            return new Promise((resolve) => {
                const transaction = db.transaction(STORE_NAME, 'readonly');
                const store = transaction.objectStore(STORE_NAME);
                const request = store.get(parseInt(id));
                request.onsuccess = () => resolve(request.result || null);
                request.onerror = () => resolve(null);
            });
        } catch (e) { return null; }
    }

    async function cacheImage(id, blob) {
        try {
            const db = await getDB();
            return new Promise((resolve) => {
                const transaction = db.transaction(STORE_NAME, 'readwrite');
                const store = transaction.objectStore(STORE_NAME);
                const request = store.put(blob, parseInt(id));
                request.onsuccess = () => resolve(true);
                request.onerror = () => resolve(false);
            });
        } catch (e) { return false; }
    }

    const dialogBox = document.getElementById('dialogBox');
    
    function scrollToBottom(smooth = false) {
        if (smooth) {
            dialogBox.scrollTo({ top: dialogBox.scrollHeight, behavior: 'smooth' });
        } else {
            setTimeout(() => {
                dialogBox.scrollTop = dialogBox.scrollHeight;
            }, 50);
        }
        markAsRead();
    }

    window.addEventListener('focus', () => {
        isTabActive = true;
        markAsRead();
        loadNewMessages();
    });
    window.addEventListener('blur', () => { isTabActive = false; });

    function tickHtml(read) {
        return read
            ? `<span class="ticks read"><svg viewBox="0 0 18 12"><path d="M1 6.5l3.2 3.2L8.5 4.4"/><path d="M7 6.5l3.2 3.2L17 1"/></svg></span>`
            : `<span class="ticks sent"><svg viewBox="0 0 18 12"><path d="M1 6.5l3.2 3.2L8.5 4.4"/></svg></span>`;
    }

    function escapeHtml(s) {
        s = String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\r\n|\r|\n/g, '<br>');

        s = s.replace(/&lt;b&gt;/gi, '<strong>').replace(/&lt;\/b&gt;/gi, '</strong>');
        s = s.replace(/&lt;div&gt;/gi, '<div>').replace(/&lt;\/div&gt;/gi, '</div>');

        s = s.replace(/&lt;font color=(?:&quot;|&#039;|'|")#ef4444(?:&quot;|&#039;|'|")&gt;/gi, '<span style="color:#ef4444;">');
        s = s.replace(/&lt;font color=(?:&quot;|&#039;|'|")#22c55e(?:&quot;|&#039;|'|")&gt;/gi, '<span style="color:#22c55e;">');
        s = s.replace(/&lt;font color=(?:&quot;|&#039;|'|")#5aa7ff(?:&quot;|&#039;|'|")&gt;/gi, '<span style="color:#5aa7ff;">');
        s = s.replace(/&lt;font color=(?:&quot;|&#039;|'|")#ffffff(?:&quot;|&#039;|'|")&gt;/gi, '<span style="color:#ffffff;">');
        s = s.replace(/&lt;font color=(?:&quot;|&#039;|'|")#2aabee(?:&quot;|&#039;|'|")&gt;/gi, '<span style="color:#2AABEE;">');
        s = s.replace(/&lt;\/font&gt;/gi, '</span>');

        return s;
    }

    async function autoDecryptInlineImage(messageId, filePath, salt_b64, iv_b64, mime, name) {
        const mId = parseInt(messageId);

        if (imageBlobCache.has(mId)) {
            insertDecryptedImage(mId, imageBlobCache.get(mId), name);
            return;
        }

        const cachedBlob = await getCachedImage(mId);
        if (cachedBlob) {
            const url = URL.createObjectURL(cachedBlob);
            imageBlobCache.set(mId, url);
            insertDecryptedImage(mId, url, name);
            return;
        }

        if (!sharedDialogKey) return;

        try {
            const response = await fetch(`decrypt_file.php?id=${mId}`, { cache: 'no-store' });
            if (!response.ok) throw new Error();

            const encryptedBuffer = await response.arrayBuffer();
            const blob = await E2EE.decryptFile(encryptedBuffer, {
                iv_b64: iv_b64,
                original_mime: mime || 'application/octet-stream'
            }, sharedDialogKey);

            await cacheImage(mId, blob);

            const url = URL.createObjectURL(blob);
            imageBlobCache.set(mId, url);
            insertDecryptedImage(mId, url, name);
        } catch (e) {
            const container = document.getElementById(`img-container-${mId}`);
            if (container) {
                container.innerHTML = `<span style="color:#ef4444; font-size:11px; padding:10px;">⚠️ Ошибка расшифровки</span>`;
            }
        }
    }

    function insertDecryptedImage(messageId, url, name) {
        const container = document.getElementById(`img-container-${messageId}`);
        if (container) {
            const wasNearBottom = (dialogBox.scrollHeight - dialogBox.scrollTop - dialogBox.clientHeight) < 250;
            
            const img = new Image();
            img.onload = () => {
                container.innerHTML = '';
                img.className = 'chat-inline-image';
                img.alt = name;
                img.onclick = () => viewFullscreenImage(url);
                container.appendChild(img);
                
                if (wasNearBottom) {
                    scrollToBottom(false);
                }
            };
            img.src = url;
        }
    }

    function viewFullscreenImage(url) {
        const w = window.open('', '_blank');
        if (w) {
            w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Изображение</title><meta name="viewport" content="width=device-width, initial-scale=1.0"></head><body style="margin:0;display:flex;justify-content:center;align-items:center;background:#000;"><img src="' + url + '" style="max-width:100vw;max-height:100vh;object-fit:contain;"></body></html>');
            w.document.close();
        }
    }

    function scrollToMessage(id) {
        const el = document.getElementById('msg-' + id);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.classList.add('highlight-flash');
            setTimeout(() => el.classList.remove('highlight-flash'), 1200);
        }
    }

    function getTtlSecondsFromExpiresAt(expiresAt, createdAt) {
        if (!expiresAt) return 0;
        const exp = new Date(expiresAt.replace(' ', 'T')).getTime();
        const cre = new Date(createdAt.replace(' ', 'T')).getTime();
        const diff = Math.round((exp - cre) / 1000);
        return diff > 0 ? diff : 0;
    }

    function formatTtlLabel(seconds) {
        if (seconds <= 0) return '';
        if (seconds <= 60) return '1м';
        if (seconds <= 300) return '5м';
        if (seconds <= 900) return '15м';
        if (seconds <= 3600) return '1ч';
        if (seconds <= 86400) return '24ч';
        return '';
    }

    async function buildMsgHtml(msg, animate = false) {
        let text = msg.message || '';
        
        if (msg.sender !== 'Система' && msg.is_encrypted == 1 && msg.message_iv) {
            try {
                if (sharedDialogKey) {
                    text = await E2EE.decryptText({
                        ciphertext_b64: msg.message,
                        iv_b64: msg.message_iv
                    }, sharedDialogKey);
                } else {
                    text = '🔐 Ошибка: Ключ шифрования собеседника не найден. Обновите страницу, когда он зайдет.';
                }
            } catch(e) {
                text = '🔐 Ошибка расшифровки';
            }
        }

        decryptedCache.set(parseInt(msg.id), text);

        let replyHtml = '';
        if (msg.reply_to_msg) {
            let replyText = msg.reply_to_msg.message || '';
            if (parseInt(msg.reply_to_msg.is_encrypted) === 1 && msg.reply_to_msg.message_iv) {
                try {
                    if (sharedDialogKey) {
                        replyText = await E2EE.decryptText({
                            ciphertext_b64: msg.reply_to_msg.message,
                            iv_b64: msg.reply_to_msg.message_iv
                        }, sharedDialogKey);
                    } else { replyText = '🔐 Зашифровано'; }
                } catch (e) { replyText = '🔐 Вложение'; }
            }
            const parentSender = msg.reply_to_msg.sender;
            replyHtml = `<div class="reply-quote" onclick="scrollToMessage(${msg.reply_to_id})">
                <div class="reply-sender">${escapeHtml(parentSender)}</div>
                <div class="reply-body-text">${escapeHtml(replyText.length > 50 ? replyText.substring(0, 50) + '...' : replyText)}</div>
            </div>`;
        }

        let forwardHtml = '';
        if (msg.forwarded_from) {
            forwardHtml = `<div style="font-size: 11px; color: var(--primary); font-weight: 600; margin-bottom: 4px; display: flex; align-items: center; gap: 4px; user-select: none;">
                <i class="fa-solid fa-share" style="transform: scaleX(-1); font-size: 10px;"></i> Переслано от ${escapeHtml(msg.forwarded_from)}
            </div>`;
        }

        const time = msg.created_at.split(' ')[1].substr(0, 5);
        const isMine = msg.sender === <?= json_encode($currentUser) ?>;
        const isRead = parseInt(msg.is_read || 0) === 1;
        const isEdited = parseInt(msg.is_edited || 0) === 1;
        
        let attachment = '';
        if (msg.file_path) {
            const isImage = (msg.original_mime || '').startsWith('image/');
            if (isImage) {
                attachment = `<div class="chat-image-container" id="img-container-${msg.id}">
                    <div class="image-placeholder">🔐 Загрузка изображения...</div>
                </div>`;
            } else {
                attachment = `<br><button class="file-link" onclick="openEncryptedFile(${msg.id})">📎 ${msg.original_name || 'Файл'}</button>`;
            }
        }

        let reactionsHtml = '';
        if (msg.reactions && msg.reactions.length > 0) {
            const counts = {};
            const userReacted = {};
            for (const r of msg.reactions) {
                counts[r.reaction] = (counts[r.reaction] || 0) + 1;
                if (r.username === <?= json_encode($currentUser) ?>) { userReacted[r.reaction] = true; }
            }
            reactionsHtml = `<div class="reactions-wrapper">`;
            for (const emoji in counts) {
                const activeClass = userReacted[emoji] ? ' active' : '';
                reactionsHtml += `<div class="reaction-pill${activeClass}" onclick="toggleReaction(${msg.id}, '${emoji}'); event.stopPropagation();">
                    <span class="emoji">${emoji}</span>
                    <span class="count">${counts[emoji]}</span>
                </div>`;
            }
            reactionsHtml += `</div>`;
        }

        const ttlSeconds = getTtlSecondsFromExpiresAt(msg.expires_at, msg.created_at);
        const expireBadge = ttlSeconds ? `<span class="expire-badge">${formatTtlLabel(ttlSeconds)}</span>` : '';
        const editedMark = isEdited ? `<span class="edited-mark">изм.</span>` : '';

        const status = isMine
            ? `<div class="time-row">${expireBadge}${editedMark}<span class="time">${time}</span>${tickHtml(isRead)}</div>`
            : `<div class="time-row">${expireBadge}${editedMark}<span class="time">${time}</span></div>`;

        const animationClass = animate ? ' animate-in' : '';

        return `<div class="msg ${isMine ? 'mine' : 'other'}${animationClass}" id="msg-${msg.id}" data-msg-id="${msg.id}" data-is-mine="${isMine ? 1 : 0}" data-has-file="${msg.file_path ? 1 : 0}">
            ${forwardHtml}
            ${replyHtml}
            <div class="msg-body">${escapeHtml(text)}</div>
            ${attachment}
            ${reactionsHtml}
            ${status}
        </div>`;
    }

    async function appendMessages(messages, toTop = false, animate = false) {
        const normalizedMessages = messages.map(m => ({
            ...m,
            _id: parseInt(m.id),
            _dateKey: getDateKey(m.created_at)
        }));

        if (normalizedMessages.length === 0) return;

        let html = '';
        const imagesToDecrypt = [];

        for (const msg of normalizedMessages) {
            loadedMessagesMap.set(parseInt(msg.id), msg);
        }

        if (toTop) {
            let nextDateKey = null;
            const firstExistingMsg = dialogBox.querySelector('[data-msg-id]');
            if (firstExistingMsg) {
                const firstId = parseInt(firstExistingMsg.dataset.msgId);
                const firstMsg = normalizedMessages.find(m => m._id === firstId);
                if (!firstMsg) {
                    const existingDateSep = dialogBox.querySelector('.date-separator');
                    if (existingDateSep && existingDateSep.dataset.dateKey) {
                        nextDateKey = existingDateSep.dataset.dateKey;
                    }
                }
            }

            for (let i = normalizedMessages.length - 1; i >= 0; i--) {
                const msg = normalizedMessages[i];
                if (document.getElementById('msg-' + msg.id)) continue;

                const prevMsg = i > 0 ? normalizedMessages[i - 1] : null;
                const needDate = !prevMsg || prevMsg._dateKey !== msg._dateKey;

                let part = await buildMsgHtml(msg, animate);

                if (nextDateKey !== msg._dateKey && needDate) {
                    part = `<div class="date-separator" data-date-key="${msg._dateKey}">${formatMessageDate(msg.created_at)}</div>` + part;
                }

                html = part + html;

                newestMsgId = Math.max(newestMsgId, msg._id);
                if (oldestMsgId === null || msg._id < oldestMsgId) {
                    oldestMsgId = msg._id;
                }

                if (msg.file_path && (msg.original_mime || '').startsWith('image/')) {
                    imagesToDecrypt.push(msg);
                }
            }

            if (!html) return;

            const prevHeight = dialogBox.scrollHeight;
            dialogBox.insertAdjacentHTML('afterbegin', html);
            dialogBox.scrollTop += (dialogBox.scrollHeight - prevHeight);
        } else {
            let lastRenderedDateKey = null;
            const existingMsgs = dialogBox.querySelectorAll('[data-msg-id]');
            if (existingMsgs.length > 0) {
                const lastExistingMsg = existingMsgs[existingMsgs.length - 1];
                const lastId = parseInt(lastExistingMsg.dataset.msgId);
                const lastIncoming = normalizedMessages.find(m => m._id === lastId);
                if (lastIncoming) {
                    lastRenderedDateKey = lastIncoming._dateKey;
                } else {
                    const dateSeparators = dialogBox.querySelectorAll('.date-separator');
                    const lastSeparator = dateSeparators[dateSeparators.length - 1];
                    if (lastSeparator) { lastRenderedDateKey = lastSeparator.dataset.dateKey || null; }
                }
            }

            for (const msg of normalizedMessages) {
                if (document.getElementById('msg-' + msg.id)) continue;

                if (lastRenderedDateKey !== msg._dateKey) {
                    html += `<div class="date-separator" data-date-key="${msg._dateKey}">${formatMessageDate(msg.created_at)}</div>`;
                    lastRenderedDateKey = msg._dateKey;
                }

                html += await buildMsgHtml(msg, animate);

                newestMsgId = Math.max(newestMsgId, msg._id);
                if (oldestMsgId === null || msg._id < oldestMsgId) {
                    oldestMsgId = msg._id;
                }

                if (msg.file_path && (msg.original_mime || '').startsWith('image/')) {
                    imagesToDecrypt.push(msg);
                }
            }

            if (!html) return;
            dialogBox.insertAdjacentHTML('beforeend', html);
            scrollToBottom(animate);
        }

        if (otherUser !== 'Система' && !otherUserPublicKeyJWK) {
            dialogBox.insertAdjacentHTML('beforeend', `
                <div style="align-self: center; margin: 15px; padding: 10px 18px; font-size: 12px; font-weight: 500; color: var(--gold2); background: rgba(216,180,106,0.1); border: 1px solid rgba(216,180,106,0.25); border-radius: 12px; text-align: center; max-width: 80%;">
                    🔐 Собеседник ещё не создал ключи шифрования. Напишите ему вне этого чата, чтобы он вошел в сеть для автоматического обмена ключами.
                </div>
            `);
        }

        imagesToDecrypt.forEach(function(msg) {
            autoDecryptInlineImage(msg.id, msg.file_path, msg.file_salt, msg.file_iv, msg.original_mime, msg.original_name);
        });
    }

    function formatMessageDate(dateString) {
        const date = new Date(dateString.replace(' ', 'T'));
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const target = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        const diffDays = Math.round((today - target) / 86400000);

        if (diffDays === 0) return 'Сегодня';
        if (diffDays === 1) return 'Вчера';

        return date.toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: today.getFullYear() !== target.getFullYear() ? 'numeric' : undefined
        });
    }

    function getDateKey(dateString) {
        const date = new Date(dateString.replace(' ', 'T'));
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    async function loadInitialMessages() {
        if (isFetchingNew) return;
        isFetchingNew = true;
        loaderTop.style.display = 'block';
        try {
            const res = await fetch(`dialog.php?user=<?= urlencode($otherUser) ?>&fetch=1`, { cache: 'no-store' });
            if (!res.ok) throw new Error('server');
            const messages = await res.json();
            if (messages.length === 0) {
                loaderTop.textContent = 'Сообщений пока нет';
                await markAsRead();
                return;
            }
            await appendMessages(messages, false, false);
            if (messages.length < 30) hasMoreOlder = false;
            scrollToBottom(false);
        } catch (e) {
            loaderTop.textContent = 'Ошибка загрузки';
        } finally {
            loaderTop.style.display = 'none';
            isFetchingNew = false;
            markAsRead();
            if (needsRefetch) {
                needsRefetch = false;
                await loadNewMessages();
            }
        }
    }

    async function loadOlderMessages() {
        if (loadingOlder || !hasMoreOlder || !oldestMsgId || isFetchingNew) return;
        loadingOlder = true;
        loaderTop.style.display = 'block';
        try {
            const prevScrollHeight = dialogBox.scrollHeight;
            const prevScrollTop = dialogBox.scrollTop;

            const res = await fetch(`dialog.php?user=<?= urlencode($otherUser) ?>&fetch=1&before_id=${oldestMsgId}`, { cache: 'no-store' });
            if (!res.ok) throw new Error('server');
            const messages = await res.json();

            if (messages.length === 0) {
                hasMoreOlder = false;
                loaderTop.textContent = 'Старых сообщений больше нет';
                setTimeout(() => loaderTop.style.display = 'none', 1000);
                return;
            }

            await appendMessages(messages, true, false);
            if (messages.length < 30) hasMoreOlder = false;

            dialogBox.scrollTop = prevScrollTop + (dialogBox.scrollHeight - prevScrollHeight);
        } catch (e) {
            loaderTop.textContent = 'Ошибка соединения';
        } finally {
            loadingOlder = false;
            loaderTop.style.display = 'none';
            markAsRead();
            if (needsRefetch) {
                needsRefetch = false;
                await loadNewMessages();
            }
        }
    }

    dialogBox.addEventListener('scroll', () => {
        hideCtxMenu();
        if (dialogBox.scrollTop < 120) { loadOlderMessages(); }
        if ((dialogBox.scrollHeight - dialogBox.scrollTop - dialogBox.clientHeight) < 120) { markAsRead(); }
    });

    async function loadNewMessages() {
        if (isFetchingNew || loadingOlder) {
            needsRefetch = true;
            return;
        }
        isFetchingNew = true;
        needsRefetch = false;
        try {
            const res = await fetch(`dialog.php?user=<?= urlencode($otherUser) ?>&fetch=1`, { cache: 'no-store' });
            if (!res.ok) throw new Error('server');
            const messages = await res.json();

            const existingIds = new Set(
                Array.from(dialogBox.querySelectorAll('[data-msg-id]')).map(el => parseInt(el.dataset.msgId))
            );
            const fetchedIds = new Set(messages.map(m => parseInt(m.id)));

            Array.from(dialogBox.querySelectorAll('[data-msg-id]')).forEach(el => {
                const id = parseInt(el.dataset.msgId);
                if (!fetchedIds.has(id)) {
                    el.remove();
                    decryptedCache.delete(id);
                }
            });

            const newMessages = messages.filter(m => !existingIds.has(parseInt(m.id)));
            if (newMessages.length > 0) {
                const wasNearBottom = (dialogBox.scrollHeight - dialogBox.scrollTop - dialogBox.clientHeight) < 120;
                await appendMessages(newMessages, false, true);
                if (wasNearBottom) { scrollToBottom(true); }
                
                // Проигрываем звук получения входящих сообщений
                const hasIncoming = newMessages.some(m => m.sender !== currentUsername);
                if (hasIncoming) {
                    AudioSynth.playReceive();
                }
            }

            for (const msg of messages) {
                const id = parseInt(msg.id);
                if (existingIds.has(id)) { await updateExistingMessage(msg); }
            }

            const allIds = messages.map(m => parseInt(m.id));
            newestMsgId = allIds.length ? Math.max(...allIds) : 0;
            oldestMsgId = allIds.length ? Math.min(...allIds) : null;

            if (messages.length === 0) { hasMoreOlder = false; }

            if (isTabActive && messages.length > 0) {
                const hasUnreadIncoming = messages.some(m => m.sender !== currentUser && parseInt(m.is_read || 0) === 0);
                if (hasUnreadIncoming) { markAsRead(); }
            }
        } catch (e) {} finally {
            isFetchingNew = false;
            if (needsRefetch) {
                needsRefetch = false;
                await loadNewMessages();
            }
        }
    }

    async function updateExistingMessage(msg) {
        const id = parseInt(msg.id);
        const el = document.getElementById('msg-' + id);
        if (!el) return;

        let text = msg.message || '';
        if (msg.is_encrypted == 1 && msg.message_iv) {
            try {
                if (sharedDialogKey) {
                    text = await E2EE.decryptText({
                        ciphertext_b64: msg.message,
                        iv_b64: msg.message_iv
                    }, sharedDialogKey);
                } else { text = '🔐 Ошибка: Ключ шифрования собеседника не найден. Обновите страницу, когда он зайдет.'; }
            } catch(e) { text = '🔐 Ошибка расшифровки'; }
        }

        const prevText = decryptedCache.get(id);
        const isEdited = parseInt(msg.is_edited || 0) === 1;
        const isMine = parseInt(el.dataset.isMine || 0) === 1;
        const isRead = parseInt(msg.is_read || 0) === 1;

        if (prevText !== text) {
            const bodyEl = el.querySelector('.msg-body');
            if (bodyEl) { bodyEl.innerHTML = escapeHtml(text); }
            decryptedCache.set(id, text);
        }

        let rectWrapper = el.querySelector('.reactions-wrapper');
        if (msg.reactions && msg.reactions.length > 0) {
            const counts = {};
            const userReacted = {};
            for (const r of msg.reactions) {
                counts[r.reaction] = (counts[r.reaction] || 0) + 1;
                if (r.username === <?= json_encode($currentUser) ?>) { userReacted[r.reaction] = true; }
            }
            let newReactHtml = '';
            for (const emoji in counts) {
                const activeClass = userReacted[emoji] ? ' active' : '';
                newReactHtml += `<div class="reaction-pill${activeClass}" onclick="toggleReaction(${msg.id}, '${emoji}'); event.stopPropagation();">
                    <span class="emoji">${emoji}</span>
                    <span class="count">${counts[emoji]}</span>
                </div>`;
            }
            if (!rectWrapper) {
                rectWrapper = document.createElement('div');
                rectWrapper.className = 'reactions-wrapper';
                el.insertBefore(rectWrapper, el.querySelector('.time-row'));
            }
            rectWrapper.innerHTML = newReactHtml;
        } else if (rectWrapper) { rectWrapper.remove(); }

        const timeRow = el.querySelector('.time-row');
        if (timeRow) {
            const time = msg.created_at.split(' ')[1].substr(0, 5);
            const ttlSeconds = getTtlSecondsFromExpiresAt(msg.expires_at, msg.created_at);
            const expireBadge = ttlSeconds ? `<span class="expire-badge">${formatTtlLabel(ttlSeconds)}</span>` : '';
            const editedMark = isEdited ? `<span class="edited-mark">изм.</span>` : '';
            const ticks = isMine ? tickHtml(isRead) : '';
            timeRow.innerHTML = `${expireBadge}${editedMark}<span class="time">${time}</span>${ticks}`;
        }
    }

    function formatLastSeen(timestamp, gender) {
        if (!timestamp) return 'был(а) недавно';
        const now = Math.floor(Date.now() / 1000);
        const diff = now - timestamp;
        
        const wasWord = (gender === 'female' || gender === 'f' || gender === 'женский' || gender === 'жен') ? 'была' : 'был';
        
        if (diff < 25) {
            return '<span style="color: #3390ec; font-weight: 600;">в сети</span>';
        }
        if (diff < 60) {
            return `${wasWord} в сети только что`;
        }
        if (diff < 3600) {
            const mins = Math.floor(diff / 60);
            let minsWord = 'минут';
            if (mins % 10 === 1 && mins % 100 !== 11) minsWord = 'минуту';
            else if ([2, 3, 4].includes(mins % 10) && ![12, 13, 14].includes(mins % 100)) minsWord = 'минуты';
            return `${wasWord} в сети ${mins} ${minsWord} назад`;
        }
        
        const date = new Date(timestamp * 1000);
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        
        const timeStr = date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
        
        if (date.toDateString() === today.toDateString()) {
            return `${wasWord} в сети сегодня в ${timeStr}`;
        }
        if (date.toDateString() === yesterday.toDateString()) {
            return `${wasWord} в сети вчера в ${timeStr}`;
        }
        
        return `${wasWord} в сети ${date.toLocaleDateString('ru-RU')} в ${timeStr}`;
    }

    function updateHeaderStatus() {
        const badge = document.getElementById('onlineBadge');
        if (!badge) return;
        if (typingState) {
            badge.innerHTML = `<span style="color:var(--primary); font-weight:600;">печатает...</span>`;
        } else {
            badge.innerHTML = formatLastSeen(otherUserLastSeen, otherUserGender);
        }
    }

    async function pollTypingStatus() {
        try {
            const res = await fetch(`dialog.php?user=<?= urlencode($otherUser) ?>&typing=1`, { cache: 'no-store' });
            if (!res.ok) throw new Error('server');
            const data = await res.json();
            setTypingState(!!data.typing);
            
            if (data.updated_at && data.updated_at > 0) {
                otherUserLastSeen = data.updated_at;
            }
            updateHeaderStatus();
        } catch (e) {}
    }

    function setTypingState(isTyping) {
        const ts = document.getElementById('typingStatus');
        typingState = isTyping;
        if (isTyping) {
            ts.classList.add('active');
        } else {
            ts.classList.remove('active');
        }
        updateHeaderStatus();
    }

    async function sendTypingState(isTyping, forceHeartbeat = false) {
        if (otherUser === 'Система') return;
        const now = Date.now();
        if (!isTyping && !forceHeartbeat && typingLastSent === 0) return;
        if (isTyping && now - typingLastSent < 3000) return;
        if (forceHeartbeat && now - lastHeartbeatSent < 10000) return;
        
        if (isTyping) {
            typingLastSent = now;
        }
        if (forceHeartbeat) {
            lastHeartbeatSent = now;
        }
        
        try {
            const formData = new FormData();
            formData.append('typing', isTyping ? '1' : '0');
            await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&set_typing=1`, {
                method: 'POST',
                body: formData
            });
        } catch (e) {
            console.error(e);
        }
    }

    async function toggleReaction(messageId, reaction) {
        try {
            const formData = new FormData();
            formData.append('message_id', messageId);
            formData.append('reaction', reaction);
            const res = await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&toggle_reaction=1`, {
                method: 'POST',
                body: formData
            });
            if (res.ok) {
                await loadNewMessages();
            }
        } catch (e) {
            console.error(e);
        }
    }

    function sendQuickReaction(emoji) {
        if (activeCtxMsgId) {
            toggleReaction(activeCtxMsgId, emoji);
            hideCtxMenu();
        }
    }

    async function deleteMessage(id) {
        if (!confirm('Удалить это сообщение у себя?')) return;
        try {
            const formData = new FormData();
            formData.append('message_id', id);
            const res = await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&delete=1`, {
                method: 'POST',
                body: formData
            });
            if (res.ok) {
                const el = document.getElementById('msg-' + id);
                if (el) el.remove();
                await loadNewMessages();
            }
        } catch (e) {
            console.error(e);
        }
    }

    async function markAsRead() {
        if (!isTabActive) return;
        try {
            await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&mark_read=1`, {
                method: 'POST'
            });
        } catch (e) {
            console.error("Ошибка при пометке прочтения:", e);
        }
    }

    function triggerReply(id, text) {
        replyingToId = id;
        replyBarText.textContent = text;
        replyBar.style.display = 'flex';
        msgInput.focus();
    }

    function cancelReplying() {
        replyingToId = null;
        replyBar.style.display = 'none';
        replyBarText.textContent = '';
    }

    function triggerEdit(id, text) {
        editingMessageId = id;
        editingOriginalText = text;
        editBarText.textContent = text;
        editBar.classList.add('active');
        msgInput.value = text;
        msgInput.focus();
    }

    function cancelEditing() {
        editingMessageId = null;
        editingOriginalText = '';
        editBar.classList.remove('active');
        editBarText.textContent = '';
        msgInput.value = '';
    }

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showCopySuccess('📋 Текст скопирован');
        }).catch(() => {
            const t = document.createElement('textarea');
            t.value = text;
            document.body.appendChild(t);
            t.select();
            document.execCommand('copy');
            document.body.removeChild(t);
            showCopySuccess('📋 Текст скопирован');
        });
    }

    const msgForm = document.getElementById('msgForm');
    if (msgForm) {
        msgForm.onsubmit = async (e) => {
            e.preventDefault();
            const text = msgInput.value.trim();
            const file = mediaInput.files[0];

            if (editingMessageId) {
                if (!text) { alert('Текст не может быть пустым'); return; }
                if (!sharedDialogKey) { alert('Ключ шифрования не настроен.'); return; }
                if (text === editingOriginalText) { cancelEditing(); return; }

                sendBtn.disabled = true;
                try {
                    const enc = await E2EE.encryptText(text, sharedDialogKey);
                    const formData = new FormData();
                    formData.append('message_id', String(editingMessageId));
                    formData.append('message_cipher', enc.ciphertext_b64);
                    formData.append('message_iv', enc.iv_b64);

                    const resp = await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&edit=1`, {
                        method: 'POST',
                        body: formData,
                        cache: 'no-store'
                    });

                    if (!resp.ok) {
                        const errData = await resp.json().catch(() => ({}));
                        throw new Error(errData.message || 'Ошибка сервера');
                    }

                    cancelEditing();
                    sendTypingState(false);
                    await loadNewMessages();
                } catch (err) { alert('Не удалось сохранить изменения: ' + err.message); }
                finally { sendBtn.disabled = false; }
                return;
            }

            if (!sharedDialogKey) {
                alert('Общий секретный ключ шифрования еще не согласован. Дождитесь входа собеседника.');
                return;
            }

            if (!text && !file) return;

            const formData = new FormData();
            sendBtn.disabled = true;
            progCont.style.display = 'block';

            if (text) {
                const enc = await E2EE.encryptText(text, sharedDialogKey);
                formData.append('message_cipher', enc.ciphertext_b64);
                formData.append('message_iv', enc.iv_b64);
            }

            if (file) {
                const encFile = await E2EE.encryptFile(file, sharedDialogKey);
                formData.append('media', encFile.blob);
                formData.append('file_iv', encFile.meta.iv_b64);
                formData.append('original_mime', encFile.meta.original_mime);
                formData.append('original_name', encFile.meta.original_name);
            }

            formData.append('ttl_seconds', ttlSelect.value);
            formData.append('ajax', '1');

            if (replyingToId) {
                formData.append('reply_to_id', String(replyingToId));
                cancelReplying();
            }

            const xhr = new XMLHttpRequest();
            xhr.upload.onprogress = (e) => {
                if (e.lengthComputable) {
                    formProgress.style.width = ((e.loaded / e.total) * 100) + '%';
                }
            };

            xhr.onload = async () => {
                if (xhr.status < 200 || xhr.status >= 300) {
                    alert('Ошибка сервера');
                    progCont.style.display = 'none';
                    formProgress.style.width = '0%';
                    sendBtn.disabled = false;
                    return;
                }
                
                // Проигрываем приятный синтезированный звук отправки сообщения
                AudioSynth.playSend();
                
                msgInput.value = '';
                msgInput.style.height = 'auto';
                mediaInput.value = '';
                filePreview.style.display = 'none';
                progCont.style.display = 'none';
                formProgress.style.width = '0%';
                sendBtn.disabled = false;
                sendTypingState(false);
                await loadNewMessages();
                await markAsRead();
            };

            xhr.onerror = () => {
                progCont.style.display = 'none';
                formProgress.style.width = '0%';
                sendBtn.disabled = false;
                alert('Ошибка сети');
            };

            xhr.open('POST', `dialog.php?user=<?= urlencode($otherUser) ?>`, true);
            xhr.send(formData);
        };
    }

    async function openEncryptedFile(messageId) {
        if (!sharedDialogKey) {
            alert('Общий ключ не согласован. Расшифровка невозможна.');
            return;
        }

        try {
            const response = await fetch(`decrypt_file.php?id=${messageId}`, { cache: 'no-store' });
            if (!response.ok) throw new Error();

            const encryptedBuffer = await response.arrayBuffer();

            const res = await fetch(`dialog.php?user=<?= urlencode($otherUser) ?>&fetch=1`, { cache: 'no-store' });
            if (!res.ok) throw new Error();
            const messages = await res.json();
            const msg = messages.find(x => x.id == messageId);

            if (!msg) {
                alert('Файл уже удалён по таймеру');
                return;
            }

            const blob = await E2EE.decryptFile(encryptedBuffer, {
                iv_b64: msg.file_iv,
                original_mime: msg.original_mime || 'application/octet-stream'
            }, sharedDialogKey);

            const url = URL.createObjectURL(blob);

            if ((msg.original_mime || '').startsWith('image/')) {
                const img = new Image();
                img.onload = () => {
                    const w = window.open('', '_blank');
                    if (w) {
                        w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Изображение</title><meta name="viewport" content="width=device-width, initial-scale=1.0"></head><body style="margin:0;display:flex;justify-content:center;align-items:center;background:#000;"><img src="' + url + '" style="max-width:100vw;max-height:100vh;object-fit:contain;"></body></html>');
                        w.document.close();
                    } else { window.open(url, '_blank'); }
                };
                img.src = url;
                return;
            }

            const a = document.createElement('a');
            a.href = url;
            a.download = msg.original_name || 'file';
            a.click();
        } catch (e) { alert('Не удалось расшифровать файл'); }
    }

    function showCopySuccess(text='📋 Текст скопирован') {
        const toast = document.createElement('div');
        toast.className = 'copy-success';
        toast.innerText = text;
        document.body.appendChild(toast);
        setTimeout(() => { toast.remove(); }, 2000);
    }

    if (msgInput) {
        msgInput.addEventListener('input', () => {
            msgInput.style.height = 'auto';
            msgInput.style.height = (msgInput.scrollHeight) + 'px';

            if (msgInput.value.trim().length > 0) {
                sendTypingState(true);
                clearTimeout(typingSendTimer);
                typingSendTimer = setTimeout(() => sendTypingState(false), 5000);
            } else {
                sendTypingState(false);
            }
        });
    }

    if (mediaInput) {
        mediaInput.addEventListener('change', () => {
            const file = mediaInput.files[0];
            if (file) {
                previewName.textContent = file.name;
                previewSize.textContent = (file.size / 1024).toFixed(1) + ' KB';
                filePreview.style.display = 'flex';
            } else {
                filePreview.style.display = 'none';
            }
        });
    }

    if (cancelFile) {
        cancelFile.addEventListener('click', () => {
            mediaInput.value = '';
            filePreview.style.display = 'none';
        });
    }

    if (emojiBtn && emojiPanel) {
        emojiBtn.addEventListener('click', () => {
            emojiPanel.style.display = (emojiPanel.style.display === 'flex') ? 'none' : 'flex';
        });

        emojiPanel.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                msgInput.value += btn.textContent;
                emojiPanel.style.display = 'none';
                msgInput.focus();
            });
        });
    }

    if (editBarCancel) {
        editBarCancel.addEventListener('click', () => {
            cancelEditing();
        });
    }

    if (replyBarCancel) {
        replyBarCancel.addEventListener('click', () => {
            cancelReplying();
        });
    }

    dialogBox.addEventListener('click', (e) => {
        if (e.target.closest('.reply-quote, .reaction-pill, .file-link, .chat-inline-image, .quick-reactions, .ctx-menu')) {
            return;
        }

        const msgEl = e.target.closest('.msg');
        if (!msgEl) return;
        
        e.preventDefault();
        
        const msgId = parseInt(msgEl.dataset.msgId);
        const isMine = parseInt(msgEl.dataset.isMine) === 1;
        const hasFile = parseInt(msgEl.dataset.hasFile) === 1;
        const text = decryptedCache.get(msgId) || '';
        
        activeCtxMsgId = msgId;
        activeCtxMsgText = text;
        activeCtxMsgIsMine = isMine;
        activeCtxMsgHasFile = hasFile;
        
        const ctxEdit = document.getElementById('ctxEdit');
        if (ctxEdit) {
            ctxEdit.style.display = (isMine && !hasFile) ? 'flex' : 'none';
        }
        
        ctxMenu.style.display = 'block';
        
        let x = e.clientX;
        let y = e.clientY;
        
        const menuWidth = ctxMenu.offsetWidth;
        const menuHeight = ctxMenu.offsetHeight;
        
        if (x + menuWidth > window.innerWidth) {
            x -= menuWidth;
        }
        if (y + menuHeight > window.innerHeight) {
            y -= menuHeight;
        }
        
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';
    });

    document.addEventListener('click', (e) => {
        if (!ctxMenu.contains(e.target) && !e.target.closest('.msg')) {
            hideCtxMenu();
        }
    });

    function hideCtxMenu() {
        ctxMenu.style.display = 'none';
    }

    document.getElementById('ctxReply').addEventListener('click', () => {
        if (activeCtxMsgId) {
            triggerReply(activeCtxMsgId, activeCtxMsgText);
            hideCtxMenu();
        }
    });

    document.getElementById('ctxCopy').addEventListener('click', () => {
        if (activeCtxMsgText) {
            copyToClipboard(activeCtxMsgText);
            hideCtxMenu();
        }
    });

    document.getElementById('ctxForward').addEventListener('click', () => {
        if (activeCtxMsgId) {
            openForwardPanel(activeCtxMsgId);
            hideCtxMenu();
        }
    });

    const ctxEdit = document.getElementById('ctxEdit');
    if (ctxEdit) {
        ctxEdit.addEventListener('click', () => {
            if (activeCtxMsgId && activeCtxMsgIsMine && !activeCtxMsgHasFile) {
                triggerEdit(activeCtxMsgId, activeCtxMsgText);
                hideCtxMenu();
            }
        });
    }

    const ctxDelete = document.getElementById('ctxDelete');
    if (ctxDelete) {
        ctxDelete.addEventListener('click', () => {
            if (activeCtxMsgId) {
                deleteMessage(activeCtxMsgId);
                hideCtxMenu();
            }
        });
    }

    if (forwardCancelBtn) {
        forwardCancelBtn.addEventListener('click', () => {
            forwardPanel.style.display = 'none';
            forwardMessageId = null;
        });
    }

    async function openForwardPanel(msgId) {
        forwardMessageId = msgId;
        forwardPanel.style.display = 'flex';
        forwardContactsList.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted); font-weight: 600;">Загрузка...</div>';
        
        try {
            const res = await fetch(`dialog.php?get_forward_targets=1`, { cache: 'no-store' });
            if (res.ok) {
                forwardTargetsData = await res.json();
                renderForwardTargets();
            } else {
                forwardContactsList.innerHTML = '<div style="text-align: center; padding: 20px; color: #ef4444;">Ошибка загрузки</div>';
            }
        } catch (e) {
            console.error(e);
            forwardContactsList.innerHTML = '<div style="text-align: center; padding: 20px; color: #ef4444;">Ошибка соединения</div>';
        }
    }

    function renderForwardTargets() {
        const list = activeForwardTab === 'dialogs' ? forwardTargetsData.dialogs : forwardTargetsData.contacts;
        forwardContactsList.innerHTML = '';
        
        if (!list || list.length === 0) {
            forwardContactsList.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted); font-weight: 500;">Список пуст</div>';
            return;
        }
        
        list.forEach(target => {
            const item = document.createElement('div');
            item.className = 'forward-contact-item';
            item.innerHTML = `
                <div class="forward-contact-avatar">${target.avatar_html}</div>
                <div class="forward-contact-name">${target.username}</div>
            `;
            item.addEventListener('click', () => {
                executeForward(forwardMessageId, target.username);
            });
            forwardContactsList.appendChild(item);
        });
    }

    // БЕЗОПАСНАЯ КЛИЕНТСКАЯ ПЕРЕСЫЛКА СООБЩЕНИЙ С ПЕРЕШИФРОВАНИЕМ
    async function executeForward(msgId, targetUser) {
        if (!msgId || !targetUser) return;
        
        const msg = loadedMessagesMap.get(parseInt(msgId));
        if (!msg) {
            alert('Сообщение не найдено');
            return;
        }

        try {
            showCopySuccess('⏳ Перешифрование и пересылка...');
            
            const plainText = decryptedCache.get(parseInt(msgId)) || '';
            const originalSender = msg.forwarded_from ? msg.forwarded_from : msg.sender;
            
            const keyRes = await fetch(`dialog.php?get_room_key=1&target=${encodeURIComponent(targetUser)}`, { cache: 'no-store' });
            if (!keyRes.ok) throw new Error('Не удалось получить ключ получателя');
            const keyData = await keyRes.json();
            
            let formData = new FormData();
            formData.append('ajax', '1');
            formData.append('forwarded_from', originalSender);
            formData.append('ttl_seconds', '0');

            let targetSharedKey = null;
            if (keyData.public_key) {
                const otherPublicJwkParsed = JSON.parse(keyData.public_key);
                const importedOtherPublicKey = await window.crypto.subtle.importKey(
                    "jwk",
                    otherPublicJwkParsed,
                    { name: "ECDH", namedCurve: "P-256" },
                    true,
                    []
                );

                let keys = await getStoredKeys();
                if (!keys) throw new Error('У вас нет ключей шифрования');
                
                const importedPrivateKey = await window.crypto.subtle.importKey(
                    "jwk",
                    keys.privateKey,
                    { name: "ECDH", namedCurve: "P-256" },
                    true,
                    ["deriveKey"]
                );

                targetSharedKey = await window.crypto.subtle.deriveKey(
                    {
                        name: "ECDH",
                        public: importedOtherPublicKey
                    },
                    importedPrivateKey,
                    {
                        name: "AES-GCM",
                        length: 256
                    },
                    false,
                    ["encrypt", "decrypt"]
                );
            }

            if (plainText) {
                if (targetSharedKey) {
                    const enc = await E2EE.encryptText(plainText, targetSharedKey);
                    formData.append('message_cipher', enc.ciphertext_b64);
                    formData.append('message_iv', enc.iv_b64);
                } else {
                    formData.append('message', plainText);
                }
            }

            if (msg.file_path) {
                if (!sharedDialogKey) {
                    throw new Error('Невозможно расшифровать исходный файл для пересылки');
                }
                
                const fileRes = await fetch(`decrypt_file.php?id=${msg.id}`, { cache: 'no-store' });
                if (!fileRes.ok) throw new Error('Не удалось получить исходный файл');
                const encryptedBuffer = await fileRes.arrayBuffer();
                
                const decryptedBlob = await E2EE.decryptFile(encryptedBuffer, {
                    iv_b64: msg.file_iv,
                    original_mime: msg.original_mime || 'application/octet-stream'
                }, sharedDialogKey);
                
                const fileObj = new File([decryptedBlob], msg.original_name || 'file', { type: decryptedBlob.type });

                if (targetSharedKey) {
                    const encFile = await E2EE.encryptFile(fileObj, targetSharedKey);
                    formData.append('media', encFile.blob);
                    formData.append('file_iv', encFile.meta.iv_b64);
                    formData.append('original_mime', encFile.meta.original_mime);
                    formData.append('original_name', encFile.meta.original_name);
                } else {
                    formData.append('media', fileObj);
                    formData.append('original_mime', fileObj.type);
                    formData.append('original_name', fileObj.name);
                }
            }

            const sendRes = await fetch(`dialog.php?user=${encodeURIComponent(targetUser)}`, {
                method: 'POST',
                body: formData
            });
            
            if (sendRes.ok) {
                forwardPanel.style.display = 'none';
                forwardMessageId = null;
                showCopySuccess('↗️ Переслано!');
            } else {
                throw new Error('Сбой отправки');
            }
        } catch (e) {
            console.error(e);
            alert('Ошибка при пересылке: ' + e.message);
        }
    }

    if (forwardTabDialogs) {
        forwardTabDialogs.addEventListener('click', () => {
            forwardTabDialogs.classList.add('active');
            forwardTabContacts.classList.remove('active');
            activeForwardTab = 'dialogs';
            renderForwardTargets();
        });
    }

    if (forwardTabContacts) {
        forwardTabContacts.addEventListener('click', () => {
            forwardTabContacts.classList.add('active');
            forwardTabDialogs.classList.remove('active');
            activeForwardTab = 'contacts';
            renderForwardTargets();
        });
    }

    // Обработчик вызова и закрытия Telegram-панели сведений о пользователе
    const topUserInfo = document.getElementById('topUserInfo');
    const expandPanel = document.getElementById('expandPanel');
    const expandPanelCloseBtn = document.getElementById('expandPanelCloseBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    if (topUserInfo && expandPanel && overlay) {
        topUserInfo.addEventListener('click', () => {
            expandPanel.classList.add('active');
            overlay.classList.add('active');
        });
    }
    
    if (expandPanelCloseBtn && overlay) {
        expandPanelCloseBtn.addEventListener('click', () => {
            expandPanel.classList.remove('active');
            overlay.classList.remove('active');
        });
    }

    const toggleContactBtn = document.getElementById('toggleContactBtn');
    if (toggleContactBtn) {
        toggleContactBtn.addEventListener('click', async () => {
            const isInContacts = toggleContactBtn.classList.contains('badge-status');
            const action = isInContacts ? 'remove_contact=1' : 'add_contact=1';
            
            try {
                const res = await fetch(`dialog.php?user=${encodeURIComponent(otherUser)}&${action}`, {
                    method: 'POST'
                });
                
                if (res.ok) {
                    if (isInContacts) {
                        toggleContactBtn.className = 'btn-action';
                        toggleContactBtn.style.borderColor = 'transparent';
                        toggleContactBtn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Добавить в контакты';
                    } else {
                        toggleContactBtn.className = 'badge-status';
                        toggleContactBtn.style.borderColor = '#bae6fd';
                        toggleContactBtn.innerHTML = '<i class="fa-solid fa-user-check"></i> В контактах';
                    }
                }
            } catch (e) {
                console.error(e);
            }
        });
    }

    document.getElementById('menuBtn').onclick = () => {
        sidebar.classList.add('active');
        overlay.classList.add('active');
    };

    document.getElementById('closeBtn').onclick = closeSidebar;
    if (overlay) {
        overlay.onclick = closeSidebar;
    }

    function closeSidebar(){
        sidebar.classList.remove('active');
        if (expandPanel) {
            expandPanel.classList.remove('active');
        }
        overlay.classList.remove('active');
    }

    // Фоновый периодический heartbeat-опрос, чтобы держать текущего пользователя в режиме "Онлайн"
    setInterval(() => {
        if (isTabActive) {
            sendTypingState(false, true);
        }
    }, 10000);

    // Запуск инициализации и фонового опроса
    initE2EE()
        .catch(err => console.error("Ошибка инициализации E2EE:", err))
        .finally(() => {
            loadInitialMessages();
            markAsRead();
            updateHeaderStatus();
            setInterval(loadNewMessages, 3000);
            setInterval(pollTypingStatus, 2000);
        });
</script>

</body>
</html>