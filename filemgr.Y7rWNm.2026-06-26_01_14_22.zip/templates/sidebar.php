<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username'])) {
    return;
}

$currentUser = $_SESSION['username'];
$currentPage = basename($_SERVER['PHP_SELF']);

$currentUserAvatarType = 0;
$currentUserRole = 'user';

try {
    $userStmt = $pdo->prepare("SELECT avatar_type, role FROM users WHERE username = :u LIMIT 1");
    $userStmt->execute(['u' => $currentUser]);
    $userRow = $userStmt->fetch(PDO::FETCH_ASSOC);
    if ($userRow) {
        $currentUserAvatarType = (int)($userRow['avatar_type'] ?? 0);
        $currentUserRole = $userRow['role'] ?? 'user';
    }
} catch (PDOException $e) {
    // Безопасный откат
}

$isAdmin = ($currentUserRole === 'admin');
$isInAiFolder = (strpos($_SERVER['PHP_SELF'], '/ai/') !== false);

// Проверяем, находится ли пользователь на одной из игровых страниц, для авто-раскрытия меню
$isGamePage = (strpos($currentPage, 'game_') !== false || $currentPage === 'games.php');
?>

<!-- Собственные встроенные стили единого бокового меню (Telegram-Style) -->
<style>
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 300px;
    height: 100%;
    background: #ffffff;
    box-shadow: 4px 0 24px rgba(0,0,0,.15);
    transform: translateX(-100%);
    transition: transform .25s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1050;
    display: flex;
    flex-direction: column;
}
.sidebar.active { transform: translateX(0); }
.overlay {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.45);
    opacity: 0;
    visibility: hidden;
    transition: .25s ease-in-out;
    z-index: 1000;
    backdrop-filter: blur(2px);
}
.overlay.active { opacity: 1; visibility: visible; }
.sidebar-profile { background: linear-gradient(135deg, #2AABEE, #229ED9); padding: 24px 20px 18px 20px; color: #ffffff; display: flex; flex-direction: column; gap: 12px; position: relative; text-align: left; }
.sidebar-close-btn { position: absolute; top: 16px; right: 16px; background: transparent; border: none; color: rgba(255,255,255,0.85); font-size: 16px; cursor: pointer; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: background 0.15s, color 0.15s; }
.sidebar-close-btn:hover { background: rgba(255,255,255,0.15); color: #ffffff; }
.sidebar-avatar { width: 64px; height: 64px; min-width: 64px; min-height: 64px; border-radius: 50%; overflow: hidden; position: relative; background: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; border: 2px solid rgba(255, 255, 255, 0.25); box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
.sidebar-avatar > * { width: 100% !important; height: 100% !important; display: flex !important; align-items: center !important; justify-content: center !important; }
.sidebar-avatar img, .sidebar-avatar svg { width: 100% !important; height: 100% !important; object-fit: cover !important; border-radius: 50% !important; }
.sidebar-user-info { display: flex; flex-direction: column; gap: 2px; }
.sidebar-user { font-size: 16px; font-weight: 700; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sidebar-role { font-size: 13px; color: rgba(255, 255, 255, 0.85); display: flex; flex-direction: column; gap: 2px; }
.sidebar-menu { list-style: none; padding: 8px 0; overflow-y: auto; scrollbar-width: none; flex: 1; text-align: left; }
.sidebar-menu::-webkit-scrollbar { display: none; }
.sidebar-menu li { margin: 2px 8px; }
.sidebar-menu a { display: flex; align-items: center; gap: 20px; padding: 12px 16px; text-decoration: none; color: #212121; font-weight: 500; font-size: 14px; border-radius: 8px; transition: background 0.15s ease-in-out, color 0.15s; }
.sidebar-menu a:hover { background: #f4f4f5; }
.sidebar-menu a.active { background: #f0f7fc; color: #2AABEE; font-weight: 600; }
.sidebar-menu a i { font-size: 18px; color: #707579; width: 24px; display: flex; justify-content: center; align-items: center; transition: color 0.15s; }
.sidebar-menu a:hover i { color: #2AABEE; }
.sidebar-menu a.active i { color: #2AABEE; }
.sidebar-unread-badge { min-width: 18px; height: 18px; padding: 0 5px; border-radius: 999px; background: linear-gradient(135deg, #ff5b7a, #ef4444); color: white; font-size: 10px; font-weight: 800; display: inline-flex; align-items: center; justify-content: center; margin-left: auto; box-shadow: 0 4px 10px rgba(239, 68, 68, 0.25); }

/* Анимация и оформление подразделов и блоков меню */
.sidebar-submenu { list-style: none !important; padding-left: 20px !important; max-height: 0; overflow: hidden; transition: max-height 0.25s cubic-bezier(0.4, 0, 0.2, 1); margin-top: 2px; }
.sidebar-submenu.open { max-height: 160px; }
.sidebar-submenu a { padding: 10px 16px !important; font-size: 13px !important; font-weight: 500 !important; background: transparent !important; }
.sidebar-submenu a.active { color: #2AABEE !important; font-weight: 700 !important; }
.sidebar-submenu a i { font-size: 14px !important; width: 20px !important; }
.submenu-arrow { margin-left: auto; font-size: 11px !important; transition: transform 0.25s ease-in-out; color: #707579; }
.menu-item-has-submenu.active-submenu .submenu-arrow { transform: rotate(180deg); }

/* Оформление раскрывающегося блока "О нас" */
.sidebar-about-content {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.25s cubic-bezier(0.4, 0, 0.2, 1), padding 0.25s, border-color 0.25s;
    padding: 0 16px;
    font-size: 12px;
    color: #4b5563;
    line-height: 1.5;
    background: #f8fafc;
    border-radius: 8px;
    margin: 2px 8px;
    text-align: left;
    border: 1px solid transparent;
}
.sidebar-about-content.open {
    max-height: 250px;
    padding: 12px 16px;
    border-color: #e2e8f0;
}
.sidebar-about-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    width: 100%;
    padding: 10px;
    background: linear-gradient(135deg, #2AABEE, #229ED9);
    color: #ffffff !important;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 700;
    font-size: 12px;
    margin-top: 10px;
    box-shadow: 0 4px 10px rgba(42, 171, 238, 0.15);
    transition: transform 0.15s, background 0.15s;
}
.sidebar-about-btn:hover {
    transform: translateY(-1px);
    background: linear-gradient(135deg, #229ed9, #1d88bc);
}

@media(max-width:480px){ .sidebar{ width: 280px; } }
</style>

<div class="overlay" id="overlay"></div>

<!-- Скрытый элемент аудио для воспроизведения звука уведомлений -->
<audio id="sidebarNotifSound" src="https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3" preload="auto"></audio>

<nav class="sidebar" id="sidebar">
    <div class="sidebar-profile">
        <button id="closeBtn" class="sidebar-close-btn">
            <i class="fa-solid fa-arrow-left"></i>
        </button>

        <div class="sidebar-avatar">
            <?php if (function_exists('renderAvatar')): ?>
                <?= renderAvatar($currentUserAvatarType, $currentUser) ?>
            <?php else: ?>
                <div class="avatar" style="background:#f1f5f9; border-radius:50%; width:100%; height:100%; display:flex; align-items:center; justify-content:center;">
                    <i class="fa-solid fa-user" style="color:#707579;"></i>
                </div>
            <?php endif; ?>
        </div>

        <div class="sidebar-user-info">
            <div class="sidebar-user">
                <?= htmlspecialchars($currentUser, ENT_QUOTES, 'UTF-8') ?>
            </div>
            <div class="sidebar-role">
                <span><?= htmlspecialchars($isAdmin ? 'Администратор' : 'Участник', ENT_QUOTES, 'UTF-8') ?></span>
                <span id="osDebugStatus" style="font-size: 9px; color: rgba(255,255,255,0.55); font-weight: 500; display: none;">[OS: Ожидание...]</span>
            </div>
        </div>
    </div>

    <ul class="sidebar-menu">
        <li>
            <a href="<?= $isInAiFolder ? '../messages.php' : 'messages.php' ?>" class="<?= ($currentPage === 'messages.php' || $currentPage === 'dialog.php') ? 'active' : '' ?>" style="display: flex; align-items: center; width: 100%;">
                <i class="fa-regular fa-comment"></i>Чаты
                <!-- Контейнер для динамического счетчика непрочитанных сообщений -->
                <span id="sidebarChatsBadge" class="sidebar-unread-badge" style="display: none;"></span>
            </a>
        </li>
        <li>
            <a href="<?= $isInAiFolder ? '../users.php' : 'users.php' ?>" class="<?= $currentPage === 'users.php' ? 'active' : '' ?>">
                <i class="fa-solid fa-magnifying-glass"></i>Поиск контактов
            </a>
        </li>
        <li>
            <a href="<?= $isInAiFolder ? '../contacts.php' : 'contacts.php' ?>" class="<?= $currentPage === 'contacts.php' ? 'active' : '' ?>">
                <i class="fa-solid fa-user-group"></i>Контакты
            </a>
        </li>
        
        <!-- Раздвижной пункт меню "Игры" (аккордеон) -->
        <li class="menu-item-has-submenu <?= $isGamePage ? 'active-submenu' : '' ?>">
            <a href="javascript:void(0)" onclick="toggleSubmenu(event, this)" style="display: flex; align-items: center; width: 100%;">
                <i class="fa-solid fa-gamepad"></i>Игры
                <i class="fa-solid fa-chevron-down submenu-arrow"></i>
            </a>
            <ul class="sidebar-submenu <?= $isGamePage ? 'open' : '' ?>" id="gamesSubmenu">
                <li>
                    <a href="<?= $isInAiFolder ? '../game_match3.php' : 'game_match3.php' ?>" class="<?= $currentPage === 'game_match3.php' ? 'active' : '' ?>">
                        <i class="fa-solid fa-shapes"></i>Три в ряд
                    </a>
                </li>
                <li>
                    <a href="<?= $isInAiFolder ? '../game_clicker.php' : 'game_clicker.php' ?>" class="<?= $currentPage === 'game_clicker.php' ? 'active' : '' ?>">
                        <i class="fa-solid fa-arrow-pointer"></i>Кликер
                    </a>
                </li>
                <li>
                    <a href="<?= $isInAiFolder ? '../games.php' : 'games.php' ?>" class="<?= $currentPage === 'games.php' ? 'active' : '' ?>">
                        <i class="fa-solid fa-gamepad"></i>Игротека (Все)
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="<?= $isInAiFolder ? 'ai.php' : 'ai/ai.php' ?>" class="<?= (strpos($currentPage, 'ai.php') !== false) ? 'active' : '' ?>">
                <i class="fa-solid fa-robot"></i>AI Помощник
            </a>
        </li>
        <li>
            <a href="<?= $isInAiFolder ? '../settings.php' : 'settings.php' ?>" class="<?= $currentPage === 'settings.php' ? 'active' : '' ?>">
                <i class="fa-solid fa-gear"></i>Настройки
            </a>
        </li>
        <?php if($isAdmin): ?>
        <li>
            <a href="<?= $isInAiFolder ? '../admin.php' : 'admin.php' ?>" class="<?= $currentPage === 'admin.php' ? 'active' : '' ?>">
                <i class="fa-solid fa-shield-halved"></i>Админка
            </a>
        </li>
        <?php endif; ?>

        <!-- Раскрывающийся пункт меню "О нас" (аккордеон) -->
        <li class="menu-item-has-submenu" id="aboutMenuItem">
            <a href="javascript:void(0)" onclick="toggleAboutMenu(event, this)" style="display: flex; align-items: center; width: 100%;">
                <i class="fa-solid fa-circle-info"></i>О нас
                <i class="fa-solid fa-chevron-down submenu-arrow"></i>
            </a>
            <div class="sidebar-about-content" id="aboutSubmenu">
                <div style="font-weight: 700; color: #1e293b; margin-bottom: 4px;">Neiro-Bitva</div>
                <div>Защищенная игровая социальная сеть. Общайтесь в зашифрованных чатах, играйте в увлекательные игры и используйте встроенного AI-помощника прямо в приложении!</div>
                <a href="<?= $isInAiFolder ? 'download/neiro.apk' : 'download/neiro.apk' ?>" class="sidebar-about-btn">
                    <i class="fa-brands fa-android" style="color: #ffffff; font-size: 14px; width: auto; justify-content: center; display: flex; align-items: center;"></i> Скачать Android App
                </a>
            </div>
        </li>

        <li>
            <a href="<?= $isInAiFolder ? 'download/logout.php' : 'logout.php' ?>" onclick="handleLogoutClick(event, this)">
                <i class="fa-solid fa-right-from-bracket"></i>Выход
            </a>
        </li>
    </ul>
</nav>

<!-- Полная адаптация под старые устройства Android (Синтаксис ES5) -->
<script>
function toggleSubmenu(e, element) {
    e.preventDefault();
    var submenu = document.getElementById('gamesSubmenu');
    var parentLi = element.closest('.menu-item-has-submenu');
    
    if (submenu.classList.contains('open')) {
        submenu.classList.remove('open');
        parentLi.classList.remove('active-submenu');
    } else {
        submenu.classList.add('open');
        parentLi.classList.add('active-submenu');
    }
}

function toggleAboutMenu(e, element) {
    e.preventDefault();
    var submenu = document.getElementById('aboutSubmenu');
    var parentLi = element.closest('.menu-item-has-submenu');
    
    if (submenu.classList.contains('open')) {
        submenu.classList.remove('open');
        parentLi.classList.remove('active-submenu');
    } else {
        submenu.classList.add('open');
        parentLi.classList.add('active-submenu');
    }
}

function runOneSignalBinding() {
    var username = <?= json_encode($currentUser) ?>;
    if (!username) return;

    var bridge = window.Median || window.median || window.gonative;
    if (!bridge) return;

    try {
        if (bridge.onesignal && typeof bridge.onesignal.register === 'function') {
            bridge.onesignal.register();
        }

        var bound = false;

        if (bridge.onesignal && typeof bridge.onesignal.login === 'function') {
            bridge.onesignal.login(username);
            bound = true;
        } else if (window.Median && window.Median.onesignal && typeof window.Median.onesignal.login === 'function') {
            window.Median.onesignal.login(username);
            bound = true;
        }
        
        if (bridge.onesignal && bridge.onesignal.externalUserId && typeof bridge.onesignal.externalUserId.set === 'function') {
            bridge.onesignal.externalUserId.set({ externalId: username });
            bound = true;
        }
    } catch (e) {
        console.error("[OneSignal Exception]", e);
    }
}

function runOneSignalBindingViaUrlScheme(username) {
    if (!username) return;
    try {
        var iframe1 = document.createElement('iframe');
        iframe1.style.display = 'none';
        iframe1.src = "gonative://onesignal/login?externalId=" + encodeURIComponent(username);
        document.body.appendChild(iframe1);
        
        setTimeout(function() {
            var iframe2 = document.createElement('iframe');
            iframe2.style.display = 'none';
            iframe2.src = "gonative://onesignal/externalUserId/set?externalId=" + encodeURIComponent(username);
            document.body.appendChild(iframe2);
            
            setTimeout(function() {
                iframe1.remove();
                iframe2.remove();
            }, 1000);
        }, 300);
    } catch (e) {
        console.error("[OneSignal URL Scheme Exception]", e);
    }
}

function handleLogoutClick(e, element) {
    var bridge = window.Median || window.median || window.gonative;
    
    if (bridge && bridge.onesignal) {
        e.preventDefault();
        console.log("[OneSignal] Запрос на нативный логаут...");
        
        try {
            if (typeof bridge.onesignal.logout === 'function') {
                bridge.onesignal.logout();
            } else if (window.Median && window.Median.onesignal && typeof window.Median.onesignal.logout === 'function') {
                window.Median.onesignal.logout();
            } else if (bridge.onesignal.externalUserId && typeof bridge.onesignal.externalUserId.remove === 'function') {
                bridge.onesignal.externalUserId.remove();
            }
        } catch (err) {
            console.error("Ошибка при выполнении нативного логаута:", err);
        }

        setTimeout(function() {
            window.location.href = element.href;
        }, 300);
    }
}

// === ФОНОВЫЙ ОПРОСЧИК НЕПРОЧИТАННЫХ СООБЩЕНИЙ ===
var lastSidebarUnreadCount = 0;
var isFirstLoad = true;

function updateSidebarUnreadCount() {
    var unreadUrl = <?= json_encode($isInAiFolder ? '../unread_count.php' : 'unread_count.php') ?>;

    fetch(unreadUrl, { cache: 'no-store' })
        .then(function(res) { return res.text(); })
        .then(function(countStr) {
            var count = parseInt(countStr, 10) || 0;
            var badge = document.getElementById('sidebarChatsBadge');
            if (!badge) return;

            if (!isFirstLoad && count > lastSidebarUnreadCount) {
                var sound = document.getElementById('sidebarNotifSound');
                if (sound) {
                    sound.play().catch(function(e) { console.log("Звук ожидает клика."); });
                }
            }

            lastSidebarUnreadCount = count;
            isFirstLoad = false;

            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'inline-flex';
            } else {
                badge.style.display = 'none';
            }
        })
        .catch(function(e) { console.error("Ошибка обновления счетчика меню:", e); });
}

setInterval(updateSidebarUnreadCount, 4000);
updateSidebarUnreadCount();

// === ГЛОБАЛЬНЫЕ ТРИГГЕРЫ ГОТОВНОСТИ ПРИЛОЖЕНИЯ ===
window.median_library_ready = function() {
    runOneSignalBinding();
};

window.gonative_library_ready = function() {
    runOneSignalBinding();
};

if (window.Median && typeof window.Median.onReady === 'function') {
    window.Median.onReady(function() {
        runOneSignalBinding();
    });
}

if (window.Median || window.median || window.gonative) {
    runOneSignalBinding();
}

var osAttempts = 0;
var osInterval = setInterval(function() {
    osAttempts++;
    if (window.Median || window.median || window.gonative) {
        clearInterval(osInterval);
        runOneSignalBinding();
    } else if (osAttempts > 30) {
        clearInterval(osInterval);
        var username = <?= json_encode($currentUser) ?>;
        if (username) {
            runOneSignalBindingViaUrlScheme(username);
        }
    }
}, 250);
</script>