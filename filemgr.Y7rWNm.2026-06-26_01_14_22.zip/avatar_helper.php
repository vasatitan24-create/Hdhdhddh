<?php
if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit();
}

function getAvatarList(): array
{
    return [
        ['icon' => 'fa-user', 'bg' => 'linear-gradient(135deg, #7c3aed, #2563eb)'],
        ['icon' => 'fa-fire', 'bg' => 'linear-gradient(135deg, #f59e0b, #ef4444)'],
        ['icon' => 'fa-ghost', 'bg' => 'linear-gradient(135deg, #6366f1, #a855f7)'],
        ['icon' => 'fa-robot', 'bg' => 'linear-gradient(135deg, #06b6d4, #3b82f6)'],
        ['icon' => 'fa-cat', 'bg' => 'linear-gradient(135deg, #ec4899, #8b5cf6)'],
        ['icon' => 'fa-dragon', 'bg' => 'linear-gradient(135deg, #10b981, #059669)'],
        ['icon' => 'fa-ninja', 'bg' => 'linear-gradient(135deg, #475569, #1e293b)'],
        ['icon' => 'fa-star', 'bg' => 'linear-gradient(135deg, #fbbf24, #f59e0b)'],
        ['icon' => 'fa-masks-theater', 'bg' => 'linear-gradient(135deg, #334155, #0f172a)'],
        ['icon' => 'fa-user-secret', 'bg' => 'linear-gradient(135deg, #4b5563, #111827)'],  
        ['icon' => 'fa-otter', 'bg' => 'linear-gradient(135deg, #fda4af, #f0abfc)'],
        ['icon' => 'fa-ice-cream', 'bg' => 'linear-gradient(135deg, #fef08a, #fdba74)'],
        ['icon' => 'fa-cloud-meatball', 'bg' => 'linear-gradient(135deg, #bfdbfe, #818cf8)'],
        ['icon' => 'fa-microchip', 'bg' => 'linear-gradient(135deg, #06b6d4, #4f46e5)'],
        ['icon' => 'fa-headset', 'bg' => 'linear-gradient(135deg, #ec4899, #8b5cf6)'],
        ['icon' => 'fa-terminal', 'bg' => 'linear-gradient(135deg, #22c55e, #111827)'],
        ['icon' => 'fa-gem', 'bg' => 'linear-gradient(135deg, #1e1b4b, #312e81)'],
        ['icon' => 'fa-chess-knight', 'bg' => 'linear-gradient(135deg, #451a03, #1e1b4b)'],
        ['icon' => 'fa-award', 'bg' => 'linear-gradient(135deg, #171717, #404040)']
    ];
}

function getAvatarByType(?int $type): array
{
    $avatars = getAvatarList();
    $type = (int)$type;

    if (!isset($avatars[$type])) {
        $type = 0;
    }

    return [
        'type' => $type,
        'icon' => $avatars[$type]['icon'],
        'bg' => $avatars[$type]['bg']
    ];
}

function renderAvatar(?int $type, ?string $username = null): string
{
    $avatar = getAvatarByType($type);
    
    // Внедряем инлайновые CSS стили для идеального отображения и масштабирования
    $style = 'background: ' . htmlspecialchars($avatar['bg']) . '; ' .
             'width: 100%; ' .
             'height: 100%; ' .
             'border-radius: 50%; ' .
             'display: inline-flex; ' .
             'align-items: center; ' .
             'justify-content: center; ' .
             'color: #ffffff; ' .
             'font-size: 1.4em;'; // Относительный размер иконки (масштабируется под родителя)

    // Используем fa-solid и fas для совместимости с Font Awesome версий 5 и 6
    return '<div class="avatar" style="' . $style . '">' .
           '<i class="fa-solid fas ' . htmlspecialchars($avatar['icon']) . '"></i>' .
           '</div>';
}