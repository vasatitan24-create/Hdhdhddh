<?php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Валидация CSRF-токена безопасности
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        header("Location: index.php?error=" . urlencode("Ошибка безопасности: неверный CSRF-токен."));
        exit();
    }

    // Проверка капчи входа
    $user_captcha = strtolower(trim($_POST['captcha'] ?? ''));
    $session_captcha = $_SESSION['captcha_code_login'] ?? '';

    // Сразу очищаем капчу в сессии во избежание повторного использования
    unset($_SESSION['captcha_code_login']);

    if ($user_captcha === '' || $user_captcha !== $session_captcha) {
        header("Location: index.php?error=" . urlencode("Неверно введен проверочный код капчи."));
        exit();
    }

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            // === ОТПРАВКА СИСТЕМНОГО ОПОВЕЩЕНИЯ О ВХОДЕ (БЕЗОПАСНОСТЬ) ===
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'Неизвестно';
            $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Неизвестно';
            $time = date('d.m.Y H:i:s');
            
            // Парсинг дружественного имени устройства
            $browser = 'Неизвестное устройство';
            if (strpos($ua, 'MSIE') !== false || strpos($ua, 'Trident') !== false) {
                $browser = 'Internet Explorer';
            } elseif (strpos($ua, 'Firefox') !== false) {
                $browser = 'Firefox';
            } elseif (strpos($ua, 'Chrome') !== false) {
                $browser = 'Chrome';
            } elseif (strpos($ua, 'Safari') !== false) {
                $browser = 'Safari';
            } elseif (strpos($ua, 'Opera') !== false || strpos($ua, 'OPR') !== false) {
                $browser = 'Opera';
            } elseif (strpos($ua, 'Mobile') !== false) {
                $browser = 'Мобильное устройство';
            }

            // Формируем красивое системное предупреждение
            $alertMsg = "<b><font color=\"#ef4444\">⚠️ Оповещение о безопасности</font></b>" .
                        "<div>Обнаружен новый вход в ваш аккаунт.</div>" .
                        "<div></div>" .
                        "<div><b>Время:</b> " . $time . "</div>" .
                        "<div><b>IP-адрес:</b> " . $ip . "</div>" .
                        "<div><b>Устройство:</b> " . $browser . "</div>" .
                        "<div></div>" .
                        "<div>Если это действие совершили не вы, рекомендуется немедленно сменить пароль в настройках профиля!</div>";

            $stmtMsg = $pdo->prepare("
                INSERT INTO private_messages (sender, receiver, message, is_system, is_read)
                VALUES ('Система', :receiver, :message, 1, 0)
            ");
            $stmtMsg->execute([
                'receiver' => $user['username'],
                'message' => $alertMsg
            ]);

            header("Location: messages.php");
            exit();
        } else {
            header("Location: index.php?error=" . urlencode("Неверный email или пароль."));
            exit();
        }
    } catch (PDOException $e) {
        header("Location: index.php?error=" . urlencode("Ошибка базы данных при авторизации."));
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}

