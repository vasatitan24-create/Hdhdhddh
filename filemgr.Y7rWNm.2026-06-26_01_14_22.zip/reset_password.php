<?php
// Подключаем базу данных и конфигурацию сессий
require_once 'db.php';

$error = null;
$success = null;
$tokenValid = false;

// Получаем токен и email из параметров URL
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$email = trim($_GET['email'] ?? $_POST['email'] ?? '');

if ($token === '' || $email === '') {
    $error = "Некорректная или поврежденная ссылка восстановления.";
} else {
    try {
        // Проверяем наличие токена в таблице сбросов
        $stmt = $pdo->prepare("
            SELECT id, expires_at 
            FROM password_resets 
            WHERE email = ? AND token = ? 
            LIMIT 1
        ");
        $stmt->execute([$email, $token]);
        $resetData = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$resetData) {
            $error = "Эта ссылка недействительна или уже была использована ранее.";
        } else {
            $expiresAt = strtotime($resetData['expires_at']);
            // Проверка срока годности (1 час с момента создания)
            if (time() > $expiresAt) {
                $error = "Срок действия этой ссылки истек. Пожалуйста, запросите восстановление заново.";
            } else {
                $tokenValid = true;
            }
        }
    } catch (PDOException $e) {
        $error = "Ошибка сервера во время верификации токена.";
    }
}

// Обработка отправки формы с новым паролем
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tokenValid) {
    // Валидация CSRF-токена безопасности формы
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        $error = "Ошибка безопасности: неверный CSRF-токен.";
        $tokenValid = false; // Блокируем форму при нарушении
    } else {
        $password = $_POST['password'] ?? '';

        // Проверка сложности пароля на стороне сервера (латиница, длина >= 8, строчные и заглавные)
        $hasLowercase = preg_match('/[a-z]/', $password);
        $hasUppercase = preg_match('/[A-Z]/', $password);
        $onlyEnglish = preg_match('/^[a-zA-Z0-9_!@#$%^&*()+\-=\[\]{};\':"\\\\|,.<>\/?]+$/', $password);

        if (strlen($password) < 8 || !$hasLowercase || !$hasUppercase || !$onlyEnglish) {
            $error = "Пароль не соответствует установленным требованиям безопасности.";
        } else {
            try {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                $pdo->beginTransaction();

                // 1. Обновляем пароль пользователя в таблице users
                $upd = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
                $upd->execute([$passwordHash, $email]);

                // 2. Безвозвратно удаляем использованный одноразовый токен из базы
                $del = $pdo->prepare("DELETE FROM password_resets WHERE email = ?");
                $del->execute([$email]);

                $pdo->commit();

                // Перенаправляем на главную с красивым сообщением об успехе
                header("Location: index.php?success=" . urlencode("Пароль успешно изменен! Теперь вы можете войти в систему."));
                exit();
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = "Произошла ошибка при перезаписи пароля в базе данных.";
            }
        }
    }
}

// Генерация CSRF-токена безопасности формы
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Установка нового пароля</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{
            --bg:#f4f7fb;
            --card:#ffffff;
            --border:#e7edf5;
            --primary:#2AABEE;
            --text:#1f2937;
            --muted:#6b7280;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
            --radius:24px;
        }
        * { box-sizing: border-box; font-family: 'Inter', sans-serif; margin: 0; padding: 0; }
        body { min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 22px; background: var(--bg); }
        .auth-container { width: 100%; max-width: 420px; padding: 40px 30px; border-radius: var(--radius); background: var(--card); border: 1px solid var(--border); box-shadow: var(--shadow); text-align: center; }
        h2 { margin-bottom: 24px; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; }
        p { font-size: 14px; color: var(--muted); margin-bottom: 20px; line-height: 1.45; }
        .alert { padding: 14px 16px; border-radius: 14px; font-size: 14px; margin-bottom: 24px; text-align: center; font-weight: 500; }
        .alert-error { background: #fef2f2; border: 1px solid #fee2e2; color: #b91c1c; }
        .input-group { margin-bottom: 16px; text-align: left; }
        .input-group input { width: 100%; padding: 16px 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 14px; color: var(--text); font-size: 15px; outline: none; }
        .input-group input:focus { background: #ffffff; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(42, 171, 238, 0.12); }
        .main-btn { width: 100%; padding: 16px; border: none; border-radius: 14px; background: linear-gradient(135deg, #2AABEE, #229ED9); color: white; font-size: 16px; font-weight: 700; cursor: pointer; transition: 0.2s; box-shadow: 0 6px 20px rgba(42, 171, 238, 0.15); }
        .main-btn:hover { transform: translateY(-1px); filter: brightness(1.05); }
        .main-btn:disabled { background: #cbd5e1; box-shadow: none; cursor: not-allowed; filter: none; }
        .input-feedback { font-size: 11px; margin-top: 5px; display: none; font-weight: 600; line-height: 1.35; padding: 0 6px; }
        .input-feedback.error { color: #ef4444; display: block; }
        .input-feedback.success { color: #22c55e; display: block; }
        .back-link { display: inline-block; margin-top: 20px; color: var(--muted); text-decoration: none; font-size: 14px; font-weight: 600; }
        .back-link:hover { color: var(--primary); }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2>Новый пароль</h2>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($tokenValid): ?>
            <p>Придумайте новый надежный пароль для вашего аккаунта.</p>
            <form method="POST">
                <!-- Защита CSRF -->
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <!-- Скрытые параметры идентификации, пришедшие из URL -->
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">

                <div class="input-group">
                    <input type="password" name="password" id="regPassword" placeholder="Новый пароль" required autocomplete="new-password">
                    <div class="input-feedback" id="passwordFeedback"></div>
                </div>
                <button type="submit" class="main-btn" id="regSubmitBtn" disabled>Сменить пароль</button>
            </form>
        <?php else: ?>
            <a href="forgot_password.php" class="main-btn" style="display: block; text-decoration: none; line-height: 20px;">Запросить ссылку заново</a>
        <?php endif; ?>

        <a href="index.php" class="back-link">Отмена</a>
    </div>

    <script>
        const regPassword = document.getElementById('regPassword');
        const regSubmitBtn = document.getElementById('regSubmitBtn');
        const passwordFeedback = document.getElementById('passwordFeedback');

        if (regPassword) {
            regPassword.addEventListener('input', () => {
                const value = regPassword.value;
                
                if (value === "") {
                    showFeedback(passwordFeedback, "", "hide");
                    regSubmitBtn.setAttribute('disabled', 'true');
                    return;
                }

                const hasLowercase = /[a-z]/.test(value);
                const hasUppercase = /[A-Z]/.test(value);
                const onlyEnglish = /^[a-zA-Z0-9_!@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?]+$/.test(value);

                if (value.length < 8) {
                    showFeedback(passwordFeedback, "Пароль должен содержать не менее 8 символов.", "error");
                    regSubmitBtn.setAttribute('disabled', 'true');
                } else if (!hasLowercase || !hasUppercase) {
                    showFeedback(passwordFeedback, "Пароль должен содержать как строчные (a-z), так и заглавные (A-Z) английские буквы.", "error");
                    regSubmitBtn.setAttribute('disabled', 'true');
                } else if (!onlyEnglish) {
                    showFeedback(passwordFeedback, "Пароль должен состоять исключительно из английских букв, цифр и спецсимволов.", "error");
                    regSubmitBtn.setAttribute('disabled', 'true');
                } else {
                    showFeedback(passwordFeedback, "✓ Пароль соответствует всем требованиям безопасности", "success");
                    regSubmitBtn.removeAttribute('disabled');
                }
            });
        }

        function showFeedback(element, text, status) {
            element.textContent = text;
            element.className = "input-feedback";
            if (status === "error") {
                element.classList.add("error");
            } else if (status === "success") {
                element.classList.add("success");
            }
        }
    </script>
</body>
</html>