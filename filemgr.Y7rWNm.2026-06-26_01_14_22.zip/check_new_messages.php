<?php
session_start();
require_once 'db.php';

$currentUser = $_SESSION['username'] ?? null;
$otherUser = $_GET['user'] ?? null;
$lastKnownId = (int)($_GET['last_id'] ?? 0);

if (!$currentUser || !$otherUser) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

try {
    $stmt = $pdo->prepare("
        SELECT MAX(id) as last_id, COUNT(id) as total 
        FROM private_messages 
        WHERE (sender = :currentUser AND receiver = :otherUser)
           OR (sender = :otherUser AND receiver = :currentUser)
    ");
    $stmt->execute([
        'currentUser' => $currentUser,
        'otherUser' => $otherUser
    ]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    $currentMaxId = (int)($result['last_id'] ?? 0);
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'has_new' => ($currentMaxId > $lastKnownId),
        'last_id' => $currentMaxId
    ]);
} catch (Exception $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $e->getMessage()]);
}
exit();