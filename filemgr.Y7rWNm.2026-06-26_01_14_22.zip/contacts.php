<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require_once 'db.php';
require_once 'avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: error.php");
    exit;
}

$currentUser = $_SESSION['username'];

// Генерация токена для защиты от CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

try {
    $stmtMe = $pdo->prepare("
        SELECT avatar_type, gender, role
        FROM users
        WHERE username = ?
        LIMIT 1
    ");
    $stmtMe->execute([$currentUser]);
    $me = $stmtMe->fetch();
} catch (PDOException $e) {
    die("Ошибка при запросе профиля: " . $e->getMessage());
}

$isAdmin = ($me['role'] ?? '') === 'admin';

$myGender = [
    'male' => 'Мужской',
    'female' => 'Женский'
][$me['gender'] ?? 'male'] ?? 'Не указан';

// Удаление контакта
if (isset($_GET['remove'])) {
    $remove = trim($_GET['remove']);
    $token = $_GET['token'] ?? '';

    if (hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        try {
            $delete = $pdo->prepare("
                DELETE FROM contacts
                WHERE owner = ?
                AND contact_user = ?
            ");
            $delete->execute([
                $currentUser,
                $remove
            ]);
        } catch (PDOException $e) {
            die("Ошибка при удалении контакта: " . $e->getMessage());
        }
    }

    header("Location: contacts.php");
    exit;
}

// Получение контактов
try {
    $getContacts = $pdo->prepare("
        SELECT u.username, u.avatar_type, u.last_seen
        FROM contacts c
        INNER JOIN users u ON c.contact_user = u.username
        WHERE c.owner = ?
        ORDER BY c.id DESC
    ");
    $getContacts->execute([$currentUser]);
    $contacts = $getContacts->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении списка контактов: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Контакты</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
    --bg:#f4f7fb;
    --card:#ffffff;
    --border:#e7edf5;
    --primary:#2AABEE;
    --text:#1f2937;
    --muted:#6b7280;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
}

body{
    background:var(--bg);
    color:var(--text);
    overflow-x:hidden;
}

/* SIDEBAR (TELEGRAM STYLE) */
.sidebar{
    position:fixed;
    top:0;
    left:0;
    width:300px;
    height:100%;
    background:#ffffff;
    box-shadow:4px 0 24px rgba(0,0,0,.15);
    transform:translateX(-100%);
    transition: transform .25s cubic-bezier(0.4, 0, 0.2, 1);
    z-index:1000;
    display: flex;
    flex-direction: column;
}

.sidebar.active{
    transform:translateX(0);
}

.overlay{
    position:fixed;
    inset:0;
    background:rgba(15, 23, 42, 0.45);
    opacity:0;
    visibility:hidden;
    transition:.25s ease-in-out;
    z-index:950;
    backdrop-filter: blur(2px);
}

.overlay.active{
    opacity:1;
    visibility:visible;
}

.sidebar-profile {
    background: linear-gradient(135deg, #2AABEE, #229ED9);
    padding: 24px 20px 18px 20px;
    color: #ffffff;
    display: flex;
    flex-direction: column;
    gap: 12px;
    position: relative;
}

.sidebar-close-btn {
    position: absolute;
    top: 16px;
    right: 16px;
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.85);
    font-size: 16px;
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: background 0.15s, color 0.15s;
}

.sidebar-close-btn:hover {
    background: rgba(255,255,255,0.15);
    color: #ffffff;
}

.sidebar-avatar{
    width:64px;
    height:64px;
    min-width:64px;
    min-height:64px;
    border-radius:50%;
    overflow:hidden;
    position:relative;
    background:#ffffff;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
    border: 2px solid rgba(255, 255, 255, 0.25);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.sidebar-avatar > * {
    width:100% !important;
    height:100% !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
}

.sidebar-avatar img,
.sidebar-avatar svg {
    width:100% !important;
    height:100% !important;
    object-fit:cover !important;
    object-position:center !important;
    display:block !important;
    border-radius:50% !important;
}

.sidebar-user-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.sidebar-user{
    font-size: 16px;
    font-weight:700;
    color: #ffffff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-role{
    font-size:13px;
    color: rgba(255, 255, 255, 0.85);
}

.sidebar-menu{
    list-style:none;
    padding: 8px 0;
    overflow-y:auto;
    scrollbar-width:none;
    flex: 1;
}

.sidebar-menu::-webkit-scrollbar{
    display:none;
}

.sidebar-menu li {
    margin: 2px 8px;
}

.sidebar-menu a{
    display:flex;
    align-items:center;
    gap:20px;
    padding:12px 16px;
    text-decoration:none;
    color: #212121;
    font-weight:500;
    font-size: 14px;
    border-radius: 8px;
    transition: background 0.15s ease-in-out, color 0.15s;
}

.sidebar-menu a:hover{
    background: #f4f4f5;
}

.sidebar-menu a.active {
    background: #f0f7fc;
    color: #2AABEE;
    font-weight: 600;
}

.sidebar-menu a i {
    font-size: 18px;
    color: #707579;
    width: 24px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: color 0.15s;
}

.sidebar-menu a:hover i {
    color: #2AABEE;
}

.sidebar-menu a.active i {
    color: #2AABEE;
}

.container{
    max-width:920px;
    margin:0 auto;
    padding:0;
    background:#ffffff;
    min-height:100vh;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:16px;
    margin-bottom:0;
    background: white;
    border-bottom: 1px solid var(--border);
    padding: 14px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.menu-btn-inline {
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #2AABEE;
    font-size: 20px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
}

.menu-btn-inline:hover {
    background: #f1f5f9;
}

.title{
    font-size:22px;
    font-weight:800;
    display: flex;
    align-items: center;
    gap: 8px;
}

.header-action-btn {
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #2AABEE;
    font-size: 18px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-decoration: none;
    transition: background 0.15s ease-in-out;
}

.header-action-btn:hover {
    background: #f1f5f9;
}

.list {
    display: flex;
    flex-direction: column;
    background: #ffffff;
}

.card{
    background:#ffffff;
    border-bottom:1px solid #edf1f5;
    padding:12px 16px;
    display:flex;
    align-items:center;
    gap:14px;
    transition: background 0.1s ease-in-out;
}

.card:hover {
    background: #f8fafc;
}

.card:last-child {
    border-bottom: none;
}

.avatar {
    width: 52px;
    height: 52px;
    min-width: 52px;
    min-height: 52px;
    border-radius: 50%;
    overflow: hidden;
    background: #f3f4f6;
    position: relative;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.avatar > * {
    width: 100% !important;
    height: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}

.avatar img,
.avatar svg {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    object-position: center !important;
    display: block !important;
    border-radius: 50% !important;
}

.online-dot{
    position:absolute;
    right: 0px;
    bottom: 0px;
    width:13px;
    height:13px;
    border-radius:50%;
    background:#22c55e;
    border:2px solid white;
    z-index:20;
}

.info{
    flex:1;
    min-width: 0;
}

.username{
    font-size:15px;
    font-weight:700;
    color: var(--text);
}

.actions{
    display:flex;
    gap:8px;
}

.btn {
    width: 36px;
    height: 36px;
    border: none;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-decoration: none;
    font-size: 14px;
    transition: transform 0.1s ease-in-out, background-color 0.15s;
}

.btn:active{
    transform:scale(0.95);
}

.chat{
    background:#eef6ff;
    color:#2AABEE;
}

.chat:hover {
    background: #e0f0ff;
}

.remove{
    background:#fee2e2;
    color:#dc2626;
}

.remove:hover {
    background: #fecaca;
}

.empty{
    text-align:center;
    padding:80px 20px;
    color:var(--muted);
    background: white;
    border: none;
    font-size: 15px;
}

.custom-modal {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s ease-in-out;
    z-index: 2000;
    backdrop-filter: blur(4px);
}

.custom-modal.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    border-radius: 20px;
    padding: 24px;
    width: 90%;
    max-width: 360px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    transform: scale(0.95);
    transition: all 0.2s ease-in-out;
    text-align: center;
}

.custom-modal.active .modal-content {
    transform: scale(1);
}

.modal-title {
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 8px;
    color: var(--text);
}

.modal-text {
    font-size: 14px;
    color: var(--muted);
    margin-bottom: 22px;
    line-height: 1.5;
}

.modal-actions {
    display: flex;
    gap: 12px;
    justify-content: center;
}

.modal-btn {
    flex: 1;
    border: none;
    padding: 11px 16px;
    border-radius: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.15s ease-in-out;
    font-size: 14px;
}

.modal-btn.cancel {
    background: #f3f4f6;
    color: var(--text);
}

.modal-btn.cancel:hover {
    background: #e5e7eb;
}

.modal-btn.confirm {
    background: #ef4444;
    color: white;
}

.modal-btn.confirm:hover {
    background: #dc2626;
}

@media(max-width:480px){
    .sidebar{
        width: 280px;
    }
    .title{
        font-size:18px;
    }
    .header {
        padding: 12px 12px;
    }
}
</style>
</head>

<body>

<?php require_once 'templates/sidebar.php'; ?>

<div class="custom-modal" id="confirmModal">
    <div class="modal-content">
        <h3 class="modal-title" id="modalTitle">Удалить?</h3>
        <p class="modal-text" id="modalText">Вы действительно хотите удалить контакт?</p>
        <div class="modal-actions">
            <button class="modal-btn cancel" id="modalCancelBtn">Отмена</button>
            <button class="modal-btn confirm" id="modalConfirmBtn">Удалить</button>
        </div>
    </div>
</div>

<div class="container">
    <div class="header">
        <div class="header-left">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="title">Контакты</h1>
        </div>
        <a href="users.php" class="header-action-btn" title="Глобальный поиск">
            <i class="fa-solid fa-magnifying-glass"></i>
        </a>
    </div>

    <div class="list">
        <?php if(empty($contacts)): ?>
        <div class="empty">
            У вас пока нет контактов
        </div>
        <?php endif; ?>

        <?php foreach($contacts as $user): ?>
        <?php
        $isOnline = $user['last_seen'] && (time() - strtotime($user['last_seen'])) <= 60;
        ?>

        <div class="card">
            <div class="avatar">
                <?= renderAvatar(
                    (int)$user['avatar_type'],
                    $user['username']
                ) ?>
                <?php if($isOnline): ?>
                    <div class="online-dot"></div>
                <?php endif; ?>
            </div>

            <div class="info">
                <div class="username">
                    <?= htmlspecialchars($user['username']) ?>
                </div>
            </div>

            <div class="actions">
                <a
                href="dialog.php?user=<?= urlencode($user['username']) ?>"
                class="btn chat"
                title="Написать сообщение"
                >
                    <i class="fas fa-paper-plane"></i>
                </a>

                <button
                type="button"
                class="btn remove"
                onclick="confirmDeleteContact('<?= htmlspecialchars($user['username'], ENT_QUOTES) ?>')"
                title="Удалить контакт"
                >
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

document.getElementById('menuBtn').onclick = () => {
    sidebar.classList.add('active');
    overlay.classList.add('active');
};

document.getElementById('closeBtn').onclick = closeSidebar;
overlay.onclick = closeSidebar;

function closeSidebar(){
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
}

let userToDelete = '';

function confirmDeleteContact(username) {
    userToDelete = username;
    document.getElementById('modalText').innerHTML = `Вы действительно хотите удалить пользователя <strong>${username}</strong> из вашего списка контактов?`;
    document.getElementById('confirmModal').classList.add('active');
}

document.getElementById('modalCancelBtn').onclick = closeModal;

document.getElementById('confirmModal').onclick = (e) => {
    if (e.target === document.getElementById('confirmModal')) {
        closeModal();
    }
};

function closeModal() {
    document.getElementById('confirmModal').classList.remove('active');
    userToDelete = '';
}

document.getElementById('modalConfirmBtn').onclick = () => {
    if (userToDelete) {
        window.location.href = '?remove=' + encodeURIComponent(userToDelete) + '&token=<?= $_SESSION['csrf_token'] ?>';
    }
};
</script>
</body>
</html>