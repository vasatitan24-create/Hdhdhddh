<?php
// Подключаем db.php для работы с сессиями по безопасному пути /sessions
require_once 'db.php';

// Определяем, для какой формы генерируется капча
$type = $_GET['type'] ?? 'login';
if (!in_array($type, ['login', 'register'])) {
    $type = 'login';
}

// Случайный набор символов (без похожих друг на друга знаков)
$permitted_chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$string_length = 5;
$captcha_string = '';

for ($i = 0; $i < $string_length; $i++) {
    $captcha_string .= $permitted_chars[rand(0, strlen($permitted_chars) - 1)];
}

// Записываем код капчи в сессию под конкретным ключом формы (login или register)
$_SESSION['captcha_code_' . $type] = strtolower($captcha_string);

// Создаем изображение
$image = imagecreatetruecolor(150, 48);

// Устанавливаем светло-серый фон
$background_color = imagecolorallocate($image, 241, 245, 249);
imagefill($image, 0, 0, $background_color);

// Рисуем линии (помехи)
for ($i = 0; $i < 4; $i++) {
    $line_color = imagecolorallocate($image, rand(100, 180), rand(100, 180), rand(100, 180));
    imageline($image, rand(0, 150), rand(0, 48), rand(0, 150), rand(0, 48), $line_color);
}

// Рисуем точки (шум)
for ($i = 0; $i < 100; $i++) {
    $pixel_color = imagecolorallocate($image, rand(120, 200), rand(120, 200), rand(120, 200));
    imagesetpixel($image, rand(0, 150), rand(0, 48), $pixel_color);
}

// Выводим текст капчи
$text_color = imagecolorallocate($image, 42, 171, 238); // Telegram-Blue
$x = 22;

for ($i = 0; $i < $string_length; $i++) {
    $y = rand(12, 20);
    $char = $captcha_string[$i];
    imagechar($image, 5, $x, $y, $char, $text_color);
    $x += 23;
}

// Выводим изображение PNG
header('Content-Type: image/png');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
imagepng($image);
imagedestroy($image);
exit();