<?php

session_start();

require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['username'])) {
    exit;
}

$stmt = $pdo->prepare("
DELETE FROM ai_chats
WHERE username = ?
");

$stmt->execute([
    $_SESSION['username']
]);

echo 'ok';