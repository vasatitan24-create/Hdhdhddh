<?php
// === ИИ-ПОМОЩНИК: ОБРАБОТКА ДИАЛОГОВ, СИНХРОНИЗАЦИЯ И ИНТЕРФЕЙС ===

require_once '../db.php';
require_once '../avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../error.php");
    exit();
}

$currentUser = $_SESSION['username'];
$currentPage = basename($_SERVER['PHP_SELF']);

// Генерация защищенного CSRF-токена
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// === АВТОМАТИЧЕСКАЯ ГАРАНТИРОВАННАЯ МИГРАЦИЯ СТРУКТУРЫ И КОДИРОВКИ БД ===
try {
    $pdo->exec("ALTER TABLE settings MODIFY COLUMN setting_value TEXT NULL");
} catch (PDOException $e) {}

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_cache (
            id INT AUTO_INCREMENT PRIMARY KEY,
            question_hash VARCHAR(64) UNIQUE NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            is_custom TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (PDOException $e) {}

// Обеспечиваем гарантированное наличие полей в ai_cache на случай устаревшей структуры
try {
    $pdo->exec("ALTER TABLE ai_cache MODIFY COLUMN question_hash VARCHAR(64) NOT NULL");
} catch (PDOException $e) {}

try {
    $pdo->exec("ALTER TABLE ai_cache ADD COLUMN question TEXT NOT NULL AFTER question_hash");
} catch (PDOException $e) {}

try {
    $pdo->exec("ALTER TABLE ai_cache ADD COLUMN is_custom TINYINT(1) DEFAULT 0 AFTER answer");
} catch (PDOException $e) {}

// Создание и адаптация таблицы ai_chats для сохранения истории переписки
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_chats (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(255) NOT NULL,
            message TEXT NULL,
            response TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
} catch (PDOException $e) {}

// Добавляем отсутствующие колонки в ai_chats, если таблица была создана ранее без них
try {
    $pdo->exec("ALTER TABLE ai_chats ADD COLUMN message TEXT NULL AFTER username");
} catch (PDOException $e) {}

try {
    $pdo->exec("ALTER TABLE ai_chats ADD COLUMN response TEXT NULL AFTER message");
} catch (PDOException $e) {}

// Принудительное обновление таблиц до кодировки UTF8MB4 (Решает проблему сохранения эмодзи)
try {
    $pdo->exec("ALTER TABLE ai_chats CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch (PDOException $e) {}

try {
    $pdo->exec("ALTER TABLE ai_cache CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch (PDOException $e) {}

// Функция умной конвертации кодировок (избегаем кракозябр при импорте ANSI-файлов)
function convertToUtf8($content) {
    if (mb_check_encoding($content, 'UTF-8')) {
        return $content;
    }
    $converted = @mb_convert_encoding($content, 'UTF-8', 'Windows-1251');
    if ($converted !== false && mb_check_encoding($converted, 'UTF-8')) {
        return $converted;
    }
    return $content;
}

// Функция сохранения записей в базу знаний с нормализованным хэшированием
function saveToDbCache($pdo, $question, $answer) {
    $question = trim($question);
    $answer = trim($answer);
    if ($question === '' || $answer === '') return;
    
    // Удаляем знаки препинания и нормализуем пробелы для безошибочного поиска
    $clean_q = preg_replace('/[^\w\s]/u', '', $question);
    $clean_q = preg_replace('/\s+/', ' ', mb_strtolower($clean_q, 'UTF-8'));
    $hash = hash('sha256', $clean_q);
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO ai_cache (question_hash, question, answer, is_custom)
            VALUES (?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE question = VALUES(question), answer = VALUES(answer), is_custom = 1
        ");
        $stmt->execute([$hash, $question, $answer]);
    } catch (PDOException $e) {}
}

// Автоматический парсер локальных файлов памяти
function importMemoryFiles($pdo) {
    $directories = [
        __DIR__ . '/ai_memory',
        __DIR__ . '/1',
        __DIR__ . '/../ai/ai_memory',
        __DIR__ . '/../ai/1'
    ];
    
    foreach ($directories as $dir) {
        if (!is_dir($dir)) continue;
        
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $filePath = $dir . '/' . $file;
            if (is_file($filePath)) {
                $content = file_get_contents($filePath);
                $content = convertToUtf8($content);
                
                // Кроссплатформенный сплит строк
                $lines = preg_split('/\r\n|\r|\n/', $content);
                $currentQ = '';
                $currentA = '';
                
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (strpos($line, 'Q:') === 0) {
                        if ($currentQ !== '' && $currentA !== '') {
                            saveToDbCache($pdo, $currentQ, $currentA);
                        }
                        $currentQ = trim(substr($line, 2));
                        $currentA = '';
                    } elseif (strpos($line, 'A:') === 0) {
                        $currentA = trim(substr($line, 2));
                    } elseif (strpos($line, 'Ответ:') === 0) {
                        $currentA = trim(substr($line, 6));
                    } else {
                        if ($currentA !== '') {
                            $currentA .= "\n" . $line;
                        } elseif ($currentQ !== '') {
                            $currentQ .= "\n" . $line;
                        }
                    }
                }
                if ($currentQ !== '' && $currentA !== '') {
                    saveToDbCache($pdo, $currentQ, $currentA);
                }
            }
        }
    }
}

// Импортируем файлы памяти только один раз, если локальная база кэша пуста (защита от зависаний)
if (!isset($_GET['action'])) {
    try {
        $countCache = (int)$pdo->query("SELECT COUNT(*) FROM ai_cache")->fetchColumn();
        if ($countCache === 0) {
            importMemoryFiles($pdo);
        }
    } catch (PDOException $e) {}
}

// Включаем буферизацию вывода для AJAX-действий, чтобы защититься от мусорных предупреждений PHP
if (isset($_GET['action'])) {
    ob_start();
}

// === 1. AJAX ОБРАБОТЧИК: СБРОС И ОЧИСТКА ДИАЛОГА ===
if (isset($_GET['action']) && $_GET['action'] === 'clear') {
    $_SESSION['ai_chat_history'] = [];
    try {
        $stmt = $pdo->prepare("DELETE FROM ai_chats WHERE username = ?");
        $stmt->execute([$currentUser]);
    } catch (PDOException $e) {}
    
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success']);
    exit;
}

// === 2. AJAX ОБРАБОТЧИК: ОТПРАВКА СООБЩЕНИЯ И ОБРАБОТКА ИИ ===
if (isset($_GET['action']) && $_GET['action'] === 'send') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Ошибка безопасности: неверный CSRF-токен']);
        exit;
    }
    
    $message = trim($_POST['message'] ?? '');
    if ($message === '') {
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Сообщение не может быть пустым']);
        exit;
    }
    
    // Подготовка вариантов нормализации строки для максимальной совместимости поиска
    $msg_lower = mb_strtolower(trim($message), 'UTF-8');
    $msg_clean = preg_replace('/[^\w\s]/u', '', $message);
    $msg_clean = preg_replace('/\s+/', ' ', mb_strtolower(trim($msg_clean), 'UTF-8'));
    
    $reply = '';
    $source = 'cache';
    
    // Рассчитываем все варианты хэшей (MD5 и SHA-256 с пунктуацией и без) для совместимости со всей вашей базой знаний
    $hashes = [
        md5($msg_lower),
        md5($msg_clean),
        hash('sha256', $msg_lower),
        hash('sha256', $msg_clean)
    ];
    
    // ШАГ A1. Первоочередной поиск точного совпадения по хэшам в локальной базе знаний
    try {
        $placeholders = implode(',', array_fill(0, count($hashes), '?'));
        $stmt = $pdo->prepare("SELECT answer, is_custom FROM ai_cache WHERE question_hash IN ($placeholders) LIMIT 1");
        $stmt->execute($hashes);
        $cached = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($cached) {
            $reply = $cached['answer'];
            $source = $cached['is_custom'] ? 'custom' : 'cache';
        }
    } catch (PDOException $e) {}
    
    // ШАГ A2. Прямое сравнение строк (если хэш не совпал из-за разницы алгоритмов хэширования)
    if (!$reply) {
        try {
            $stmt = $pdo->prepare("
                SELECT answer, is_custom 
                FROM ai_cache 
                WHERE LOWER(question) = ? 
                   OR LOWER(question) = ? 
                LIMIT 1
            ");
            $stmt->execute([$msg_lower, $msg_clean]);
            $cached = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cached) {
                $reply = $cached['answer'];
                $source = $cached['is_custom'] ? 'custom' : 'cache';
            }
        } catch (PDOException $e) {}
    }
    
    // ШАГ A3. Нечёткий поиск (LIKE) — активируется только для длинных фраз (защита от ложных совпадений)
    if (!$reply && mb_strlen($msg_clean, 'UTF-8') >= 3) {
        try {
            $stmt = $pdo->prepare("
                SELECT answer, is_custom 
                FROM ai_cache 
                WHERE LOWER(question) LIKE ? 
                LIMIT 1
            ");
            $stmt->execute(['%' . $msg_clean . '%']);
            $cached = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cached) {
                $reply = $cached['answer'];
                $source = $cached['is_custom'] ? 'custom' : 'cache';
            }
        } catch (PDOException $e) {}
    }
    
    // Если локальный ответ успешно найден — отдаем его и пропускаем API
    if ($reply) {
        if (!isset($_SESSION['ai_chat_history'])) {
            $_SESSION['ai_chat_history'] = [];
        }
        $_SESSION['ai_chat_history'][] = ['role' => 'user', 'content' => $message];
        $_SESSION['ai_chat_history'][] = ['role' => 'assistant', 'content' => $reply];
        
        if (count($_SESSION['ai_chat_history']) > 12) {
            $_SESSION['ai_chat_history'] = array_slice($_SESSION['ai_chat_history'], -12);
        }
        
        // Регистрация диалога в базе чатов
        try {
            $chatLog = $pdo->prepare("INSERT INTO ai_chats (username, message, response) VALUES (?, ?, ?)");
            $chatLog->execute([$currentUser, $message, $reply]);
        } catch (PDOException $e) {}
        
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'reply' => $reply,
            'source' => $source
        ]);
        exit;
    }
    
    // ШАГ B. Обращение к API OpenRouter (нейросеть)
    try {
        $keyStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'gemini_api_key' LIMIT 1");
        $apiKey = $keyStmt->fetchColumn();
    } catch (PDOException $e) {
        $apiKey = '';
    }
    
    if (!$apiKey) {
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Интеграция с нейросетью временно не настроена. Укажите API-ключ OpenRouter в Админке.']);
        exit;
    }

    try {
        $modelStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'ai_model_name' LIMIT 1");
        $aiModel = trim($modelStmt->fetchColumn() ?: 'qwen/qwen-2.5-72b-instruct:free');
    } catch (PDOException $e) {
        $aiModel = 'qwen/qwen-2.5-72b-instruct:free';
    }
    
    try {
        $promptStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'ai_system_instruction' LIMIT 1");
        $systemInstruction = $promptStmt->fetchColumn() ?: "Ты — приветливый ИИ-помощник на игровой платформе Neiro-Bitva. Отвечай кратко, грамотно, с умеренным использованием эмодзи.";
    } catch (PDOException $e) {
        $systemInstruction = "Ты — приветливый ИИ-помощник на игровой платформе Neiro-Bitva. Отвечай кратко, грамотно, с умеренным использованием эмодзи.";
    }
    
    if (!isset($_SESSION['ai_chat_history'])) {
        $_SESSION['ai_chat_history'] = [];
    }
    
    $messages = [];
    $messages[] = ['role' => 'system', 'content' => $systemInstruction];
    
    foreach ($_SESSION['ai_chat_history'] as $hist) {
        $messages[] = [
            'role' => $hist['role'],
            'content' => $hist['content']
        ];
    }
    
    $messages[] = ['role' => 'user', 'content' => $message];
    
    $payload = [
        'model' => $aiModel,
        'messages' => $messages
    ];
    
    $url = "https://openrouter.ai/api/v1/chat/completions";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
        'HTTP-Referer: https://neiro-bitva.ru',
        'X-Title: Neiro-Bitva'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        $errorMsg = 'Не удалось получить ответ от ИИ.';
        if (!empty($curlError)) {
            $errorMsg .= ' [Детали cURL: ' . $curlError . ']';
        } else {
            $resErr = json_decode($response, true);
            if (isset($resErr['error']['message'])) {
                $errorMsg .= ' [API Error: ' . $resErr['error']['message'] . ']';
            } else {
                $errorMsg .= ' [HTTP Code: ' . $httpCode . ']';
            }
        }
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => $errorMsg]);
        exit;
    }
    
    $resArr = json_decode($response, true);
    $reply = $resArr['choices'][0]['message']['content'] ?? '';
    
    if ($reply === '') {
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Получен пустой ответ от ИИ.']);
        exit;
    }
    
    // ОЧИСТКА ОТ ТЕХНИЧЕСКИХ ТЕГОВ, КОТОРЫЕ ИНОГДА УТЕКАЮТ ИЗ БЕСПЛАТНЫХ МОДЕЛЕЙ (убирает </assistant>)
    $reply = preg_replace('/<\/?assistant>/i', '', $reply);
    $reply = preg_replace('/<\/?system>/i', '', $reply);
    $reply = preg_replace('/<\/?user>/i', '', $reply);
    $reply = trim($reply);
    
    $_SESSION['ai_chat_history'][] = ['role' => 'user', 'content' => $message];
    $_SESSION['ai_chat_history'][] = ['role' => 'assistant', 'content' => $reply];
    
    if (count($_SESSION['ai_chat_history']) > 12) {
        $_SESSION['ai_chat_history'] = array_slice($_SESSION['ai_chat_history'], -12);
    }
    
    // ГАРАНТИРОВАННОЕ СОХРАНЕНИЕ ОТВЕТА В ЛОКАЛЬНУЮ БАЗУ ДАННЫХ (КЭШ) ДЛЯ ПОСЛЕДУЮЩИХ ОПЕРАТИВНЫХ ЗАПРОСОВ
    try {
        $hash_to_save = hash('sha256', $msg_clean);
        $ins = $pdo->prepare("
            INSERT INTO ai_cache (question_hash, question, answer, is_custom)
            VALUES (?, ?, ?, 0)
            ON DUPLICATE KEY UPDATE answer = VALUES(answer)
        ");
        $ins->execute([$hash_to_save, $message, $reply]);
    } catch (PDOException $e) {}
    
    // Логирование в таблицу чатов (для сохранения истории)
    try {
        $chatLog = $pdo->prepare("INSERT INTO ai_chats (username, message, response) VALUES (?, ?, ?)");
        $chatLog->execute([$currentUser, $message, $reply]);
    } catch (PDOException $e) {}
    
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'reply' => $reply,
        'source' => 'api'
    ]);
    exit;
}

// === 3. ИНИЦИАЛИЗАЦИЯ И СТРАНИЦА ИНТЕРФЕЙСА ===
$currentUserAvatarType = 0;
try {
    $meStmt = $pdo->prepare("SELECT avatar_type FROM users WHERE username = ? LIMIT 1");
    $meStmt->execute([$currentUser]);
    $currentUserAvatarType = (int)($meStmt->fetchColumn() ?: 0);
} catch (PDOException $e) {}

// Загрузка истории переписки из базы данных
$chatHistory = [];
try {
    $historyStmt = $pdo->prepare("
        SELECT message, response 
        FROM ai_chats 
        WHERE username = ? 
        ORDER BY id ASC 
        LIMIT 100
    ");
    $historyStmt->execute([$currentUser]);
    $chatHistory = $historyStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>AI Помощник</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root{
            --bg:#f4f7fb;
            --card:#ffffff;
            --border:#e7edf5;
            --primary:#2AABEE;
            --text:#1f2937;
            --muted:#6b7280;
            --blue-gradient: linear-gradient(135deg, #2AABEE, #229ED9);
            --safe-bottom: env(safe-area-inset-bottom);
        }
        
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overscroll-behavior-y: contain;
            overscroll-behavior: none;
        }

        * {
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: stretch;
            background: var(--bg);
            color: var(--text);
            overflow: hidden;
        }

        .wrap {
            width: 100%;
            max-width: 920px;
            height: 100dvh;
            display: flex;
            flex-direction: column;
            background: #ffffff;
            border-left: 1px solid var(--border);
            border-right: 1px solid var(--border);
            position: relative;
            padding-bottom: var(--safe-bottom);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 14px 16px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .menu-btn-inline {
            border: none;
            border-radius: 50%;
            background: transparent;
            color: var(--primary);
            font-size: 20px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.15s ease-in-out;
        }
        .menu-btn-inline:hover {
            background: #f1f5f9;
        }

        .title {
            font-size: 18px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .clear-context-btn {
            border: 1px solid var(--border);
            background: #f8fafc;
            color: var(--muted);
            padding: 8px 14px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.15s ease-in-out;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .clear-context-btn:hover {
            background: #fee2e2;
            color: #ef4444;
            border-color: #fecaca;
        }

        .chat-box {
            flex: 1;
            overflow-y: auto;
            padding: 18px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            background: #f8fafc;
            -webkit-overflow-scrolling: touch;
        }
        .chat-box::-webkit-scrollbar {
            width: 4px;
        }
        .chat-box::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.08);
            border-radius: 99px;
        }

        @keyframes msgSlideIn {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .msg {
            max-width: 80%;
            padding: 12px 16px;
            border-radius: 18px;
            font-size: 14.5px;
            line-height: 1.5;
            position: relative;
            word-wrap: break-word;
            animation: msgSlideIn 0.2s ease forwards;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }
        .msg.user {
            align-self: flex-end;
            background: var(--blue-gradient);
            color: white;
            border-bottom-right-radius: 4px;
        }
        .msg.ai {
            align-self: flex-start;
            background: #ffffff;
            color: var(--text);
            border-bottom-left-radius: 4px;
            border: 1px solid var(--border);
        }

        /* Источники ответов */
        .source-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 9.5px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 2px 6px;
            border-radius: 6px;
            margin-top: 8px;
            user-select: none;
        }
        .source-badge.custom {
            background: #fef3c7;
            color: #d97706;
            border: 1px solid #fde68a;
        }
        .source-badge.cache {
            background: #ecfdf5;
            color: #059669;
            border: 1px solid #a7f3d0;
        }
        .source-badge.api {
            background: #eff6ff;
            color: var(--primary);
            border: 1px solid #bfdbfe;
        }

        /* Индикатор набора текста */
        .typing-indicator {
            display: none;
            align-self: flex-start;
            background: #ffffff;
            border: 1px solid var(--border);
            padding: 12px 20px;
            border-radius: 18px;
            border-bottom-left-radius: 4px;
            align-items: center;
            gap: 6px;
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: var(--primary);
            border-radius: 50%;
            opacity: 0.4;
            animation: bounce 1.2s infinite ease-in-out;
        }
        .typing-indicator span:nth-child(2) { animation-delay: 0.15s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.3s; }
        @keyframes bounce {
            0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
            40% { transform: translateY(-4px); opacity: 1; }
        }

        .input-area {
            background: #ffffff;
            padding: 12px 16px;
            border-top: 1px solid var(--border);
        }
        .input-wrapper {
            display: flex;
            gap: 8px;
            align-items: flex-end;
            background: #f8fafc;
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 4px 8px;
        }
        textarea {
            flex: 1;
            background: transparent;
            border: none;
            color: var(--text);
            font-size: 15px;
            padding: 10px 6px;
            resize: none;
            max-height: 120px;
            outline: none;
            line-height: 1.4;
            min-height: 38px;
            font-family: inherit;
        }
        textarea::placeholder {
            color: #94a3b8;
        }
        .send-btn {
            background: var(--blue-gradient);
            border: none;
            width: 38px;
            height: 38px;
            color: #fff;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            border-radius: 50%;
            box-shadow: 0 4px 10px rgba(42,171,238,0.25);
            transition: transform 0.15s ease-in-out;
        }
        .send-btn:hover {
            transform: scale(1.05);
        }
        .send-btn svg {
            width: 16px;
            height: 16px;
            fill: currentColor;
        }

        @media(max-width:600px){
            .wrap { border: none; }
            .msg { max-width: 90%; }
        }
    </style>
</head>
<body>

<?php require_once '../templates/sidebar.php'; ?>

<div class="wrap">
    <div class="header">
        <div class="header-left">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="title">🤖 AI</h1>
        </div>
        <button class="clear-context-btn" onclick="clearContext()">
            <i class="fa-solid fa-trash-can"></i> Сбросить диалог
        </button>
    </div>

    <div class="chat-box" id="chatBox">
        <div class="msg ai">
            <div>Привет! Я твой персональный ИИ-помощник. Задай мне любой вопрос о нашем сайте, играх или просто пообщайся со мной!</div>
        </div>

        <!-- Вывод сохраненной истории из базы данных -->
        <?php foreach ($chatHistory as $chat): ?>
            <div class="msg user">
                <div><?= nl2br(htmlspecialchars($chat['message'], ENT_QUOTES, 'UTF-8')) ?></div>
            </div>
            <div class="msg ai">
                <div><?= nl2br(htmlspecialchars($chat['response'], ENT_QUOTES, 'UTF-8')) ?></div>
            </div>
        <?php endforeach; ?>
        
        <!-- Индикатор размышления -->
        <div class="typing-indicator" id="typingIndicator">
            <span></span><span></span><span></span>
        </div>
    </div>

    <div class="input-area">
        <form id="aiForm" onsubmit="sendMessage(event)">
            <div class="input-wrapper">
                <textarea id="aiInput" placeholder="Спросите о чем-нибудь..." rows="1" required></textarea>
                <button type="submit" class="send-btn" id="sendBtn">
                    <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const csrf_token = '<?= $_SESSION['csrf_token'] ?>';
    const chatBox = document.getElementById('chatBox');
    const aiInput = document.getElementById('aiInput');
    const sendBtn = document.getElementById('sendBtn');
    let typingIndicator = document.getElementById('typingIndicator');

    // Авто-высота текстового поля
    aiInput.addEventListener('input', () => {
        aiInput.style.height = 'auto';
        aiInput.style.height = (aiInput.scrollHeight) + 'px';
    });

    function scrollToBottom() {
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    // Безопасное экранирование вывода и замена переносов строк
    function escapeHtml(string) {
        return String(string)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\n/g, '<br>');
    }

    // Функция вывода сообщений с эффектом постепенной печати (Typewriter) с защитой Юникода
    function addMessageWithEffect(text, role, source = '') {
        const msg = document.createElement('div');
        msg.className = 'msg ' + role;
        
        let badge = '';
        if (role === 'ai') {
            if (source === 'custom') {
                badge = '<br><span class="source-badge custom"><i class="fa-solid fa-bolt"></i> Локальное правило</span>';
            } else if (source === 'cache') {
                badge = '<br><span class="source-badge cache"><i class="fa-solid fa-bolt"></i> Локальная память</span>';
            } else if (source === 'api') {
                badge = '<br><span class="source-badge api"><i class="fa-solid fa-brain"></i> Нейросеть</span>';
            }
        }

        // Если пишет пользователь — выводим мгновенно
        if (role === 'user') {
            msg.innerHTML = `<div>${escapeHtml(text)}</div>`;
            chatBox.insertBefore(msg, typingIndicator);
            scrollToBottom();
            return;
        }

        // Постепенный вывод текста ИИ (Typewriter) с безопасной работой над массивом суррогатных пар
        const textContainer = document.createElement('div');
        msg.appendChild(textContainer);
        chatBox.insertBefore(msg, typingIndicator);
        scrollToBottom();

        const charsArray = Array.from(text);
        let index = 0;
        const speed = 12; // скорость печати в миллисекундах на символ

        aiInput.disabled = true;
        sendBtn.disabled = true;

        function typeChar() {
            if (index < charsArray.length) {
                const substring = charsArray.slice(0, index + 1).join('');
                textContainer.innerHTML = escapeHtml(substring);
                index++;
                scrollToBottom();
                setTimeout(typeChar, speed);
            } else {
                textContainer.innerHTML = escapeHtml(text);
                if (badge) {
                    msg.insertAdjacentHTML('beforeend', badge);
                }
                aiInput.disabled = false;
                sendBtn.disabled = false;
                scrollToBottom();
            }
        }
        typeChar();
    }

    function sendMessage(e) {
        e.preventDefault();
        const text = aiInput.value.trim();
        if (text === '') return;

        addMessageWithEffect(text, 'user');
        aiInput.value = '';
        aiInput.style.height = 'auto';

        aiInput.disabled = true;
        sendBtn.disabled = true;
        typingIndicator.style.display = 'flex';
        scrollToBottom();

        const formData = new FormData();
        formData.append('message', text);
        formData.append('csrf_token', csrf_token);

        fetch('?action=send', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            typingIndicator.style.display = 'none';
            if (data.error) {
                aiInput.disabled = false;
                sendBtn.disabled = false;
                addMessageWithEffect('⚠️ ' + data.error, 'ai');
            } else {
                addMessageWithEffect(data.reply, 'ai', data.source);
            }
        })
        .catch(err => {
            typingIndicator.style.display = 'none';
            aiInput.disabled = false;
            sendBtn.disabled = false;
            addMessageWithEffect('⚠️ Не удалось связаться с сервером.', 'ai');
        });
    }

    function clearContext() {
        if (!confirm('Вы действительно хотите очистить контекст диалога? ИИ забудет предыдущие реплики, а переписка будет удалена.')) {
            return;
        }
        
        fetch('?action=clear')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                chatBox.innerHTML = `
                    <div class="msg ai">
                        <div>Привет! Я твой персональный ИИ-помощник. Задай мне любой вопрос о нашем сайте, играх или просто пообщайся со мной!</div>
                    </div>
                    <div class="typing-indicator" id="typingIndicator" style="display: none;">
                        <span></span><span></span><span></span>
                    </div>
                `;
                typingIndicator = document.getElementById('typingIndicator');
                scrollToBottom();
            }
        });
    }

    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    document.getElementById('menuBtn').onclick = () => {
        sidebar.classList.add('active');
        overlay.classList.add('active');
    };

    document.getElementById('closeBtn').onclick = closeSidebar;
    overlay.onclick = closeSidebar;

    function closeSidebar(){
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }

    // Скролл вниз при загрузке страницы
    window.onload = () => {
        scrollToBottom();
    };
</script>
</body>
</html>