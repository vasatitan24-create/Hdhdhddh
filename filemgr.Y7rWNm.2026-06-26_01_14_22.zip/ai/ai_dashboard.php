<?php



require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['username'])) {
    exit('Ошибка авторизации');
}

$username = $_SESSION['username'];

/* ===== ROLE ===== */

$stmt = $pdo->prepare("
SELECT role
FROM users
WHERE username = ?
LIMIT 1
");

$stmt->execute([$username]);

$user =
$stmt->fetch(PDO::FETCH_ASSOC);

if (
    !isset($user['role']) ||
    $user['role'] !== 'admin'
) {

    exit('Доступ запрещён');
}

/* ===== STATS ===== */

$totalMemory =
$pdo->query("
SELECT COUNT(*)
FROM ai_memory
")->fetchColumn();

$totalChats =
$pdo->query("
SELECT COUNT(*)
FROM ai_chats
")->fetchColumn();

$totalLikes =
$pdo->query("
SELECT COUNT(*)
FROM ai_feedback
WHERE rating = 1
")->fetchColumn();

$totalDislikes =
$pdo->query("
SELECT COUNT(*)
FROM ai_feedback
WHERE rating = -1
")->fetchColumn();

$totalCache =
$pdo->query("
SELECT COUNT(*)
FROM ai_cache
")->fetchColumn();

/* ===== MEMORY SIZE ===== */

$memorySize =
$pdo->query("
SELECT SUM(LENGTH(content))
FROM ai_memory
")->fetchColumn();

if (!$memorySize) {
    $memorySize = 0;
}

$memoryMB =
round(
    $memorySize / 1024 / 1024,
    2
);

/* ===== SUCCESS RATE ===== */

$totalFeedback =
$totalLikes + $totalDislikes;

$successRate = 0;

if ($totalFeedback > 0) {

    $successRate =
    round(
        ($totalLikes / $totalFeedback) * 100
    );
}

/* ===== AI IQ ===== */

$iq = 0;

/* ===== MEMORY ===== */

$iq += min(
    20,
    $totalMemory * 2
);

/* ===== CHAT EXPERIENCE ===== */

$iq += min(
    20,
    floor($totalChats / 20)
);

/* ===== FEEDBACK ===== */

$iq += floor($successRate / 2);

/* ===== CACHE ===== */

$iq += min(
    10,
    floor($totalCache / 10)
);

/* ===== LIMIT ===== */

if ($iq > 100) {
    $iq = 100;
}

/* ===== LEVEL ===== */

$level =
'🧠 Новичок';

if ($iq >= 20) {
    $level = '🤖 Базовый AI';
}

if ($iq >= 40) {
    $level = '⚡ Умный AI';
}

if ($iq >= 60) {
    $level = '🚀 Продвинутый AI';
}

if ($iq >= 80) {
    $level = '👑 Супер AI';
}

/* ===== COLOR ===== */

$barColor = '#2563eb';

if ($iq >= 40) {
    $barColor = '#16a34a';
}

if ($iq >= 70) {
    $barColor = '#f59e0b';
}

if ($iq >= 90) {
    $barColor = '#dc2626';
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>AI Intelligence</title>

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#07111f;
color:white;
padding:20px;
}

.title{
font-size:28px;
font-weight:bold;
margin-bottom:25px;
display:flex;
align-items:center;
gap:12px;
}

.title i{
color:#4ea1ff;
}

.card{
background:#0b1627;
border-radius:24px;
padding:22px;
margin-bottom:20px;
border:1px solid rgba(255,255,255,.08);
}

.card-title{
font-size:18px;
margin-bottom:18px;
font-weight:bold;
}

.progress{
width:100%;
height:26px;
background:#132238;
border-radius:999px;
overflow:hidden;
margin-bottom:14px;
}

.progress-bar{
height:100%;
width:<?= $iq ?>%;
background:<?= $barColor ?>;
border-radius:999px;
transition:.4s;
}

.iq-text{
font-size:26px;
font-weight:bold;
margin-bottom:8px;
}

.level{
font-size:18px;
opacity:.9;
}

.stats{
display:grid;
grid-template-columns:repeat(
auto-fit,
minmax(180px,1fr)
);
gap:16px;
}

.stat{
background:#132238;
border-radius:18px;
padding:18px;
}

.stat-value{
font-size:28px;
font-weight:bold;
margin-bottom:6px;
}

.stat-label{
opacity:.7;
font-size:14px;
}

.live{
margin-top:10px;
font-size:14px;
opacity:.7;
display:flex;
align-items:center;
gap:8px;
}

.dot{
width:10px;
height:10px;
border-radius:50%;
background:#16a34a;
animation:pulse 1s infinite;
}

@keyframes pulse{

0%{
opacity:1;
transform:scale(1);
}

50%{
opacity:.4;
transform:scale(1.3);
}

100%{
opacity:1;
transform:scale(1);
}

}

.footer{
margin-top:25px;
text-align:center;
opacity:.6;
font-size:13px;
}

</style>
</head>
<body>

<div class="title">

<i class="fas fa-brain"></i>

<div>AI Intelligence Panel</div>

</div>

<div class="card">

<div class="card-title">

Уровень интеллекта AI

</div>

<div class="progress">

<div class="progress-bar"></div>

</div>

<div class="iq-text">

<?= $iq ?> / 100 IQ

</div>

<div class="level">

<?= $level ?>

</div>

<div class="live">

<div class="dot"></div>

LIVE AI SYSTEM

</div>

</div>

<div class="stats">

<div class="stat">

<div class="stat-value">

<?= $totalMemory ?>

</div>

<div class="stat-label">

Файлов памяти

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= $totalChats ?>

</div>

<div class="stat-label">

Сообщений обработано

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= $totalLikes ?>

</div>

<div class="stat-label">

Хороших ответов 👍

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= $totalDislikes ?>

</div>

<div class="stat-label">

Плохих ответов 👎

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= $successRate ?>%

</div>

<div class="stat-label">

Успешность AI

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= $memoryMB ?> MB

</div>

<div class="stat-label">

Размер памяти

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= $totalCache ?>

</div>

<div class="stat-label">

Кэш ответов

</div>

</div>

<div class="stat">

<div class="stat-value">

<?= date('H:i:s') ?>

</div>

<div class="stat-label">

Время системы

</div>

</div>

</div>

<div class="footer">

AI EVOLUTION SYSTEM v1.0

</div>

<script>

setInterval(()=>{

location.reload();

},10000);

</script>

</body>
</html>