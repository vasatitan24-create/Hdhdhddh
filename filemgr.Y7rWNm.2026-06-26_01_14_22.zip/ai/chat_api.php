<?php
// === ФРОНТЕНД: /ai/ai.php ===

require_once '../db.php';
require_once '../avatar_helper.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../error.php");
    exit();
}

$currentUser = $_SESSION['username'];
$currentPage = basename($_SERVER['PHP_SELF']);

// Загрузка типа аватара текущего пользователя для бокового меню
$currentUserAvatarType = 0;
try {
    $meStmt = $pdo->prepare("SELECT avatar_type FROM users WHERE username = ? LIMIT 1");
    $meStmt->execute([$currentUser]);
    $currentUserAvatarType = (int)($meStmt->fetchColumn() ?: 0);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>AI Помощник</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root{
            --bg:#f4f7fb;
            --card:#ffffff;
            --border:#e7edf5;
            --primary:#2AABEE;
            --text:#1f2937;
            --muted:#6b7280;
            --blue-gradient: linear-gradient(135deg, #2AABEE, #229ED9);
            --safe-bottom: env(safe-area-inset-bottom);
        }
        
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overscroll-behavior-y: contain;
            overscroll-behavior: none;
        }

        * {
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: stretch;
            background: var(--bg);
            color: var(--text);
            overflow: hidden;
        }

        .wrap {
            width: 100%;
            max-width: 920px;
            height: 100dvh;
            display: flex;
            flex-direction: column;
            background: #ffffff;
            border-left: 1px solid var(--border);
            border-right: 1px solid var(--border);
            position: relative;
            padding-bottom: var(--safe-bottom);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 14px 16px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .menu-btn-inline {
            border: none;
            border-radius: 50%;
            background: transparent;
            color: var(--primary);
            font-size: 20px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.15s ease-in-out;
        }
        .menu-btn-inline:hover {
            background: #f1f5f9;
        }

        .title {
            font-size: 18px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .clear-context-btn {
            border: 1px solid var(--border);
            background: #f8fafc;
            color: var(--muted);
            padding: 8px 14px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.15s ease-in-out;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .clear-context-btn:hover {
            background: #fee2e2;
            color: #ef4444;
            border-color: #fecaca;
        }

        .chat-box {
            flex: 1;
            overflow-y: auto;
            padding: 18px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            background: #f8fafc;
            -webkit-overflow-scrolling: touch;
        }
        .chat-box::-webkit-scrollbar {
            width: 4px;
        }
        .chat-box::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.08);
            border-radius: 99px;
        }

        @keyframes msgSlideIn {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .msg {
            max-width: 80%;
            padding: 12px 16px;
            border-radius: 18px;
            font-size: 14.5px;
            line-height: 1.5;
            position: relative;
            word-wrap: break-word;
            animation: msgSlideIn 0.2s ease forwards;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }
        .msg.user {
            align-self: flex-end;
            background: var(--blue-gradient);
            color: white;
            border-bottom-right-radius: 4px;
        }
        .msg.ai {
            align-self: flex-start;
            background: #ffffff;
            color: var(--text);
            border-bottom-left-radius: 4px;
            border: 1px solid var(--border);
        }

        /* Бейджи источников ответов */
        .source-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 9.5px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 2px 6px;
            border-radius: 6px;
            margin-top: 8px;
            user-select: none;
        }
        .source-badge.custom {
            background: #fef3c7;
            color: #d97706;
            border: 1px solid #fde68a;
        }
        .source-badge.cache {
            background: #ecfdf5;
            color: #059669;
            border: 1px solid #a7f3d0;
        }
        .source-badge.api {
            background: #eff6ff;
            color: var(--primary);
            border: 1px solid #bfdbfe;
        }

        /* Индикатор набора текста ИИ */
        .typing-indicator {
            display: none;
            align-self: flex-start;
            background: #ffffff;
            border: 1px solid var(--border);
            padding: 12px 20px;
            border-radius: 18px;
            border-bottom-left-radius: 4px;
            align-items: center;
            gap: 6px;
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: var(--primary);
            border-radius: 50%;
            opacity: 0.4;
            animation: bounce 1.2s infinite ease-in-out;
        }
        .typing-indicator span:nth-child(2) { animation-delay: 0.15s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.3s; }
        @keyframes bounce {
            0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
            40% { transform: translateY(-4px); opacity: 1; }
        }

        .input-area {
            background: #ffffff;
            padding: 12px 16px;
            border-top: 1px solid var(--border);
        }
        .input-wrapper {
            display: flex;
            gap: 8px;
            align-items: flex-end;
            background: #f8fafc;
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 4px 8px;
        }
        textarea {
            flex: 1;
            background: transparent;
            border: none;
            color: var(--text);
            font-size: 15px;
            padding: 10px 6px;
            resize: none;
            max-height: 120px;
            outline: none;
            line-height: 1.4;
            min-height: 38px;
            font-family: inherit;
        }
        textarea::placeholder {
            color: #94a3b8;
        }
        .send-btn {
            background: var(--blue-gradient);
            border: none;
            width: 38px;
            height: 38px;
            color: #fff;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            border-radius: 50%;
            box-shadow: 0 4px 10px rgba(42,171,238,0.25);
            transition: transform 0.15s ease-in-out;
        }
        .send-btn:hover {
            transform: scale(1.05);
        }
        .send-btn svg {
            width: 16px;
            height: 16px;
            fill: currentColor;
        }

        @media(max-width:600px){
            .wrap { border: none; }
            .msg { max-width: 90%; }
        }
    </style>
</head>
<body>

<?php require_once '../templates/sidebar.php'; ?>

<div class="wrap">
    <div class="header">
        <div class="header-left">
            <button class="menu-btn-inline" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="title">🤖 AI Помощник</h1>
        </div>
        <button class="clear-context-btn" onclick="clearContext()">
            <i class="fa-solid fa-trash-can"></i> Сбросить диалог
        </button>
    </div>

    <div class="chat-box" id="chatBox">
        <div class="msg ai">
            Привет! Я твой персональный ИИ-помощник. Задай мне любой вопрос о нашем сайте, играх или просто пообщайся со мной!
        </div>
    </div>

    <!-- Индикатор размышления ИИ -->
    <div class="typing-indicator" id="typingIndicator">
        <span></span><span></span><span></span>
    </div>

    <div class="input-area">
        <form id="aiForm" onsubmit="sendMessage(event)">
            <div class="input-wrapper">
                <textarea id="aiInput" placeholder="Спросите о чем-нибудь..." rows="1" required></textarea>
                <button type="submit" class="send-btn" id="sendBtn">
                    <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const csrf_token = '<?= $_SESSION['csrf_token'] ?>';
    const chatBox = document.getElementById('chatBox');
    const aiInput = document.getElementById('aiInput');
    const sendBtn = document.getElementById('sendBtn');
    const typingIndicator = document.getElementById('typingIndicator');

    // Авто-высота текстового поля под количество строк
    aiInput.addEventListener('input', () => {
        aiInput.style.height = 'auto';
        aiInput.style.height = (aiInput.scrollHeight) + 'px';
    });

    function scrollToBottom() {
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function addMessage(text, role, source = '') {
        const msg = document.createElement('div');
        msg.className = 'msg ' + role;
        
        // Разбираем переносы строк
        let formattedText = text.replace(/\n/g, '<br>');
        
        let badge = '';
        if (role === 'ai') {
            if (source === 'custom') {
                badge = '<br><span class="source-badge custom">⚡ Локальное правило</span>';
            } else if (source === 'cache') {
                badge = '<br><span class="source-badge cache">⚡ Локальная память</span>';
            } else if (source === 'api') {
                badge = '<br><span class="source-badge api">🧠 Нейросеть Gemini</span>';
            }
        }

        msg.innerHTML = `<div>${formattedText}</div>${badge}`;
        
        // Вставляем новое сообщение перед индикатором ввода
        chatBox.insertBefore(msg, typingIndicator);
        scrollToBottom();
    }

    function sendMessage(e) {
        e.preventDefault();
        const text = aiInput.value.trim();
        if (text === '') return;

        addMessage(text, 'user');
        aiInput.value = '';
        aiInput.style.height = 'auto';

        // Блокируем интерфейс во время ожидания ответа
        aiInput.disabled = true;
        sendBtn.disabled = true;
        typingIndicator.style.display = 'flex';
        scrollToBottom();

        const formData = new FormData();
        formData.append('message', text);
        formData.append('csrf_token', csrf_token);

        // Перенаправляем AJAX-запросы к чат-апи обработчику chat_api.php
        fetch('chat_api.php?action=send', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            typingIndicator.style.display = 'none';
            aiInput.disabled = false;
            sendBtn.disabled = false;
            aiInput.focus();

            if (data.error) {
                addMessage('⚠️ ' + data.error, 'ai');
            } else {
                addMessage(data.reply, 'ai', data.source);
            }
        })
        .catch(err => {
            typingIndicator.style.display = 'none';
            aiInput.disabled = false;
            sendBtn.disabled = false;
            addMessage('⚠️ Не удалось связаться с сервером.', 'ai');
        });
    }

    function clearContext() {
        if (!confirm('Вы действительно хотите очистить контекст диалога? ИИ забудет предыдущие реплики.')) {
            return;
        }
        
        // Перенаправляем запрос сброса к chat_api.php
        fetch('chat_api.php?action=clear')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                chatBox.innerHTML = `
                    <div class="msg ai">
                        Привет! Я твой персональный ИИ-помощник. Задай мне любой вопрос о нашем сайте, играх или просто пообщайся со мной!
                    </div>
                `;
                chatBox.appendChild(typingIndicator);
                scrollToBottom();
            }
        });
    }

    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    document.getElementById('menuBtn').onclick = () => {
        sidebar.classList.add('active');
        overlay.classList.add('active');
    };

    document.getElementById('closeBtn').onclick = closeSidebar;
    overlay.onclick = closeSidebar;

    function closeSidebar(){
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }
</script>
</body>
</html>