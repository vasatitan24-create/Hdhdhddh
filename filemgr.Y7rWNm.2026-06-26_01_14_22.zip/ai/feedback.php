<?php


require_once __DIR__ . '/../db.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['username'])) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Ошибка авторизации'
    ));

    exit;
}

$username = $_SESSION['username'];

$raw = file_get_contents('php://input');

$data = json_decode($raw, true);

if (!isset($data['question'])) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Не передан вопрос'
    ));

    exit;
}

if (!isset($data['answer'])) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Не передан ответ'
    ));

    exit;
}

if (!isset($data['rating'])) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Не передана оценка'
    ));

    exit;
}

$question = trim($data['question']);

$answer = trim($data['answer']);

$rating = (int)$data['rating'];

/*
|--------------------------------------------------------------------------
| ONLY 1 or -1
|--------------------------------------------------------------------------
*/

if (

    $rating != 1 &&
    $rating != -1
) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Неверная оценка'
    ));

    exit;
}

/*
|--------------------------------------------------------------------------
| EMPTY CHECK
|--------------------------------------------------------------------------
*/

if (

    $question == '' ||
    $answer == ''
) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Пустые данные'
    ));

    exit;
}

/*
|--------------------------------------------------------------------------
| SAVE FEEDBACK
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("

INSERT INTO ai_feedback

(
    username,
    question,
    answer,
    rating
)

VALUES (?, ?, ?, ?)

");

$save = $stmt->execute(array(

    $username,
    $question,
    $answer,
    $rating
));

if (!$save) {

    echo json_encode(array(
        'success' => false,
        'message' => 'Ошибка сохранения'
    ));

    exit;
}

/*
|--------------------------------------------------------------------------
| AUTO LEARNING
|--------------------------------------------------------------------------
|
| Если ответ получил лайк —
| добавляем в память AI
|
*/

if ($rating == 1) {

    /*
    |--------------------------------------------------------------------------
    | CHECK EXISTS
    |--------------------------------------------------------------------------
    */

    $check = $pdo->prepare("

    SELECT id
    FROM ai_memory

    WHERE content LIKE ?

    LIMIT 1

    ");

    $searchText =
    '%Q: ' .
    $question .
    '%';

    $check->execute(array(
        $searchText
    ));

    $exists =
    $check->fetch(
        PDO::FETCH_ASSOC
    );

    /*
    |--------------------------------------------------------------------------
    | SAVE TO MEMORY
    |--------------------------------------------------------------------------
    */

    if (!$exists) {

        $memoryText =

        "Q: " .
        $question .

        "\n\nA: " .
        $answer;

        $insert = $pdo->prepare("

        INSERT INTO ai_memory

        (
            username,
            filename,
            content
        )

        VALUES (?, ?, ?)

        ");

        $insert->execute(array(

            $username,
            'feedback_learning',
            $memoryText
        ));
    }
}

/*
|--------------------------------------------------------------------------
| CLEAR BAD CACHE
|--------------------------------------------------------------------------
*/

if ($rating == -1) {

    $hash =
    md5(

        mb_strtolower(
            trim($question),
            'UTF-8'
        )
    );

    $delete = $pdo->prepare("

    DELETE FROM ai_cache

    WHERE question_hash = ?

    ");

    $delete->execute(array(
        $hash
    ));
}

/*
|--------------------------------------------------------------------------
| RESPONSE
|--------------------------------------------------------------------------
*/

echo json_encode(array(

    'success' => true,

    'message' =>

    $rating == 1

    ?

    'Спасибо 👍 AI запомнил хороший ответ'

    :

    'Спасибо 👎 AI учтёт ошибку'
));