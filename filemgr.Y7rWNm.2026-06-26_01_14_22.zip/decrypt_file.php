<?php
// Подключаем db.php — он автоматически настроит пути к сессиям и безопасно запустит сессию
require_once 'db.php';

if (!isset($_SESSION['username'])) {
    http_response_code(403);
    exit('Forbidden');
}

$currentUser = $_SESSION['username'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    http_response_code(400);
    exit('Bad request');
}

$stmt = $pdo->prepare("
    SELECT id, sender, receiver, file_path, original_name
    FROM private_messages
    WHERE id = :id
      AND (sender = :u OR receiver = :u)
    LIMIT 1
");
$stmt->execute([
    'id' => $id,
    'u' => $currentUser
]);

$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || empty($row['file_path'])) {
    http_response_code(404);
    exit('Not found');
}

// Убираем возможные дублирующиеся слеши
$path = __DIR__ . '/' . ltrim($row['file_path'], '/');

if (!is_file($path)) {
    http_response_code(404);
    echo "File not found on disk: " . htmlspecialchars($row['file_path']);
    exit();
}

// Очищаем буфер вывода, чтобы не повредить бинарные данные
if (ob_get_level()) ob_end_clean();

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($row['file_path']) . '"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

readfile($path);
exit();