<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Доступ ограничен</title>
    <style>
        :root{
            --bg1:#050816;
            --bg2:#0b1220;
            --bg3:#121a2f;
            --card:rgba(10, 15, 28, 0.68);
            --card-border:rgba(255,255,255,0.12);
            --text:#f8fafc;
            --muted:rgba(248,250,252,0.62);
            --gold:#d8b46a;
            --gold2:#f5d48a;
            --blue:#5aa7ff;
            --shadow:0 28px 80px rgba(0,0,0,.55);
            --radius:34px;
        }

        * { box-sizing: border-box; font-family: 'Inter', system-ui, -apple-system, sans-serif; }
        html, body { width: 100%; height: 100%; margin: 0; }
        
        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 22px;
            color: var(--text);
            background:
                radial-gradient(circle at top right, rgba(90,167,255,0.16), transparent 28%),
                radial-gradient(circle at bottom left, rgba(216,180,106,0.14), transparent 24%),
                linear-gradient(135deg, var(--bg1), var(--bg2) 42%, var(--bg3));
            overflow: hidden;
        }

        body::before{
            content:"";
            position: fixed;
            inset: 0;
            background:
                linear-gradient(120deg, rgba(255,255,255,0.06), transparent 25%, transparent 75%, rgba(255,255,255,0.03));
            pointer-events:none;
            mix-blend-mode: screen;
        }

        .profile-container {
            width: 100%;
            max-width: 430px;
            position: relative;
            padding: 44px 28px 34px;
            border-radius: var(--radius);
            background: linear-gradient(180deg, rgba(18, 25, 41, 0.76), rgba(7, 10, 18, 0.82));
            border: 1px solid var(--card-border);
            box-shadow: var(--shadow);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            text-align: center;
        }

        .profile-container::before{
            content:"";
            position:absolute;
            inset:0;
            border-radius: var(--radius);
            padding: 1px;
            background: linear-gradient(135deg, rgba(245,212,138,0.32), rgba(90,167,255,0.12), rgba(255,255,255,0.04));
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            pointer-events:none;
        }

        .icon-error {
            font-size: 64px;
            margin-bottom: 24px;
            display: block;
            filter: drop-shadow(0 0 15px rgba(90,167,255,0.4));
        }

        h2 {
            margin: 0 0 14px 0;
            font-size: 26px;
            font-weight: 800;
            letter-spacing: 0.2px;
            color: var(--text);
        }

        .status {
            color: var(--gold2);
            font-size: 12px;
            margin-bottom: 30px;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-weight: 700;
            opacity: 0.8;
        }

        .btn-main {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            max-width: 240px;
            height: 54px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            text-decoration: none;
            border-radius: 16px;
            font-weight: 800;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.25s ease;
            box-shadow: 0 10px 20px rgba(37,99,235,0.28);
            border: 1px solid rgba(255,255,255,0.1);
        }

        .btn-main:hover {
            transform: translateY(-2px);
            filter: brightness(1.1);
            box-shadow: 0 14px 28px rgba(37,99,235,0.35);
        }

        @media (max-width: 480px) {
            .profile-container {
                padding: 40px 20px 30px;
                border-radius: 28px;
            }
            h2 { font-size: 22px; }
        }
    </style>
</head>
<body>

    <div class="profile-container">
        <div class="icon-error">🔒</div>
        <h2>Ошибка доступа</h2>
        <div class="status">Вы не авторизировались!</div>
        
        <div style="margin-top: 20px;">
            <a href="https://neiro-bitva.ru/" class="btn-main">
                На главную
            </a>
        </div>
    </div>

</body>
</html>